# NusantaraMart Laravel — Versi Lengkap

Project ini dibuat untuk Laravel Herd dan mengikuti layout pada screenshot NusantaraMart:
- header + search
- sidebar marketplace
- hero Karya Lokal Rasa Global
- kategori produk
- produk pilihan
- banner makanan/fashion/kerajinan
- panel aplikasi/voucher/UMKM/keunggulan
- footer
- halaman semua produk
- pencarian produk
- filter kategori
- halaman promo
- wishlist menggunakan localStorage
- keranjang sederhana menggunakan localStorage
- database SQLite + migration + seeder

## Cara pasang di Laravel Herd Windows

Folder target yang sesuai screenshot kamu:
`C:\Users\Admin\Herd\nusantaramart-laravel`

### 1. Extract ZIP
Extract isi ZIP menjadi:
`C:\Users\Admin\Herd\nusantaramart-laravel`

Pastikan file ini langsung ada:
`C:\Users\Admin\Herd\nusantaramart-laravel\artisan`

Jangan sampai menjadi:
`C:\Users\Admin\Herd\nusantaramart-laravel\nusantaramart-laravel\artisan`

### 2. Terminal
Buka Terminal dari Herd lalu:

`cd C:\Users\Admin\Herd\nusantaramart-laravel`

### 3. Install dependency
`composer install`

### 4. Buat .env
`copy .env.example .env`

### 5. Generate APP_KEY
`php artisan key:generate`

### 6. Migrasi + data awal
`php artisan migrate --seed`

### 7. Cek
`php artisan --version`

### 8. Buka
`http://nusantaramart-laravel.test`

Jika Herd masih menampilkan 404:
- pastikan `artisan` ada di root folder
- pastikan `public/index.php` ada
- restart Herd
- klik site `nusantaramart-laravel.test` lagi

## Catatan gambar
Gambar produk memakai URL gambar publik sehingga koneksi internet diperlukan untuk menampilkan foto produk. Semua logic Laravel dan data produk sudah ada di project.

## Struktur penting

app/
  Http/Controllers/HomeController.php
  Models/Category.php
  Models/Product.php

database/
  migrations/
  seeders/DatabaseSeeder.php
  database.sqlite

resources/views/
  layouts/app.blade.php
  partials/
  home.blade.php
  products.blade.php
  placeholder.blade.php

public/
  index.php
  assets/css/nusantaramart.css
  assets/js/nusantaramart.js

routes/
  web.php
  console.php

## Pembayaran manual (tahap 1)

Checkout mendukung COD, transfer bank, dan QRIS manual. COD langsung berstatus
`awaiting_confirmation` dan dibayar ketika barang diterima. Pembayaran non-COD
berstatus `awaiting_payment`. Pembeli mengunggah bukti, lalu penjual memeriksa
dan menyetujui atau menolak bukti dari menu **Pesanan Masuk** di Seller Center.
Jika satu pesanan memuat produk dari beberapa toko, semua toko yang terlibat
harus menyetujui bukti sebelum pesanan menjadi lunas dan dapat diproses. Sistem
otomatis membatalkan pembayaran yang kedaluwarsa dan mengembalikan stok.

Atur rekening melalui `.env` (jangan menaruh data rekening di Blade):

```dotenv
PAYMENT_BCA_NUMBER=1234567890
PAYMENT_BCA_NAME="Nama Pemilik Rekening"
PAYMENT_BRI_NUMBER=
PAYMENT_BRI_NAME="Nama Pemilik Rekening"
PAYMENT_MANDIRI_NUMBER=
PAYMENT_MANDIRI_NAME="Nama Pemilik Rekening"
PAYMENT_QRIS_IMAGE=images/payment/qris.png
PAYMENT_EXPIRATION_HOURS=24
```

`PAYMENT_QRIS_IMAGE` adalah path gambar di `public/` atau URL gambar statis.
Transfer bank baru tampil setelah setidaknya satu nomor rekening diisi; QRIS
baru tampil setelah gambar QR dikonfigurasi. Dengan begitu pembeli tidak dapat
membuat pesanan manual tanpa instruksi pembayaran yang dapat dipakai.
Bukti transfer disimpan di disk lokal privat dan hanya bisa diunduh oleh pemilik
pesanan atau penjual dari toko yang terkait. Sistem tidak memverifikasi transfer
secara otomatis; verifikasi otomatis memerlukan integrasi gateway atau sumber
transaksi yang dapat dipercaya.
Pesanan non-COD tanpa pembayaran valid akan dibatalkan setelah batas waktu dan
stok produk/Flash Sale dikembalikan.
Scheduler perlu dijalankan di server secara rutin; pada development gunakan
`php artisan schedule:work`, sedangkan production jalankan `php artisan schedule:run`
setiap menit melalui scheduler/cron. Metode pembayaran manual memakai kontrak
`App\Contracts\PaymentGateway`; implementasi gateway eksternal dapat ditambahkan
kemudian tanpa mengganti alur pembuatan pesanan. Gateway/webhook pada tahap
berikutnya wajib memverifikasi signature provider dan memproses event secara
idempoten sebelum mengubah status pembayaran.
