<?php

namespace Tests\Feature;

use App\Models\Category;
use App\Models\Store;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class TokoPilihanTest extends TestCase
{
    use RefreshDatabase;

    public function test_toko_pilihan_only_shows_gotik_and_wilda_and_handles_empty_products(): void
    {
        $category = Category::create(['name' => 'Makanan & Minuman', 'slug' => 'makanan-minuman']);
        $gotik = $this->makeStore('Toko Gotik', 'toko-gotik');
        $wilda = $this->makeStore('Toko Wilda', 'toko-wilda');
        $this->makeStore('Toko Lain', 'toko-lain');

        $gotik->products()->create([
            'category_id' => $category->id,
            'name' => 'Timphan Gotik',
            'slug' => 'timphan-gotik',
            'seller' => $gotik->store_name,
            'location' => 'Pidie',
            'price' => 25000,
            'rating' => 4.8,
            'review_count' => 12,
            'image' => 'https://example.test/timphan.jpg',
        ]);

        foreach ([route('shop'), route('toko-pilihan')] as $url) {
            $response = $this->get($url);

            $response->assertOk()
                ->assertSee('Toko Gotik')
                ->assertSee('Toko Wilda')
                ->assertSee('Timphan Gotik')
                ->assertSee('Belum ada produk unggulan untuk toko ini.')
                ->assertSee(route('shop.show', $gotik->slug))
                ->assertSee(route('shop.show', $wilda->slug))
                ->assertDontSee('Toko Lain');
            $this->assertSame(2, substr_count($response->getContent(), 'class="toko-pilihan-card"'));
        }
    }

    public function test_moma_mall_only_lists_gotik_wilda_and_their_products(): void
    {
        $category = Category::create(['name' => 'Makanan & Minuman', 'slug' => 'makanan-minuman']);
        $gotik = $this->makeStore('Toko Gotik', 'toko-gotik');
        $wilda = $this->makeStore('Toko Wilda', 'toko-wilda');
        $this->makeStore('Toko Lain', 'toko-lain');

        $product = $gotik->products()->create([
            'category_id' => $category->id,
            'name' => 'Timphan Gotik',
            'slug' => 'timphan-gotik',
            'seller' => $gotik->store_name,
            'location' => 'Pidie',
            'price' => 25000,
            'rating' => 4.8,
            'review_count' => 12,
            'image' => 'https://example.test/timphan.jpg',
        ]);

        $response = $this->get(route('moma-mall'));

        $response->assertOk()
            ->assertSee('Toko Gotik')
            ->assertSee('Toko Wilda')
            ->assertSee('Timphan Gotik')
            ->assertSee(route('shop.show', $gotik->slug))
            ->assertSee(route('shop.show', $wilda->slug))
            ->assertSee(route('products.show', $product->slug))
            ->assertDontSee('Toko Lain')
            ->assertDontSee('Nusantara Craft')
            ->assertDontSee('Dapur Nusantara')
            ->assertSee('2</strong> toko resmi', false)
            ->assertSee('1</strong> produk pilihan', false);

        $this->assertSame(2, substr_count($response->getContent(), 'class="moma-store-card"'));
        $this->assertSame(1, substr_count($response->getContent(), 'class="moma-product-card"'));
    }

    private function makeStore(string $name, string $slug): Store
    {
        return Store::create([
            'user_id' => User::factory()->create()->id,
            'store_name' => $name,
            'slug' => $slug,
            'category' => 'Makanan & Minuman',
            'phone' => '081234567890',
            'address' => 'Banda Aceh',
            'status' => 'approved',
        ]);
    }
}
