<?php

namespace Tests\Feature;

use App\Models\Category;
use App\Models\Banner;
use App\Models\FlashSale;
use App\Models\FlashSaleItem;
use App\Models\Order;
use App\Models\Product;
use App\Models\Store;
use App\Models\User;
use App\Models\Voucher;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class BuyerMarketplaceTest extends TestCase
{
    use RefreshDatabase;

    public function test_homepage_renders_splash_screen(): void
    {
        $response = $this->get('/');

        $response->assertOk();
        $response->assertSee('id="moma-splash"', false);
        $response->assertSee('Belanja Lokal, Bangga Indonesia');
    }

    public function test_product_listing_does_not_render_splash_screen(): void
    {
        $response = $this->get('/produk');

        $response->assertOk();
        $response->assertDontSee('id="moma-splash"', false);
    }

    public function test_guest_header_keeps_wishlist_shortcut_visible_and_links_to_login_protected_route(): void
    {
        $this->get('/')
            ->assertOk()
            ->assertSee('aria-label="Daftar atau masuk untuk melihat wishlist"', false)
            ->assertSee('href="'.route('wishlist').'"', false);

        $this->get(route('wishlist'))
            ->assertRedirect(route('register'));
    }

    public function test_homepage_provides_active_banners_current_flash_sales_and_approved_featured_stores(): void
    {
        $now = now();
        $category = Category::create(['name' => 'Makanan', 'slug' => 'makanan']);
        $user = User::factory()->create();
        $store = Store::create([
            'user_id' => $user->id,
            'store_name' => 'Toko Resmi',
            'slug' => 'toko-resmi',
            'category' => 'Makanan',
            'phone' => '081234567890',
            'address' => 'Alamat toko',
            'status' => 'approved',
            'is_official' => true,
            'is_featured' => true,
        ]);
        $product = $this->makeProduct($category, 'Produk Flash Sale', 25000);
        $product->update(['store_id' => $store->id]);

        $activeBanner = Banner::create([
            'title' => 'Banner Aktif',
            'position' => 'hero',
            'is_active' => true,
            'starts_at' => $now->copy()->subMinute(),
            'ends_at' => $now->copy()->addHour(),
        ]);
        Banner::create([
            'title' => 'Banner Kedaluwarsa',
            'position' => 'hero',
            'is_active' => true,
            'ends_at' => $now->copy()->subSecond(),
        ]);
        $flashSale = FlashSale::create([
            'title' => 'Flash Sale Berjalan',
            'starts_at' => $now->copy()->subMinute(),
            'ends_at' => $now->copy()->addHour(),
            'is_active' => true,
        ]);
        FlashSale::create([
            'title' => 'Flash Sale Belum Mulai',
            'starts_at' => $now->copy()->addHour(),
            'ends_at' => $now->copy()->addHours(2),
            'is_active' => true,
        ]);
        FlashSaleItem::create([
            'flash_sale_id' => $flashSale->id,
            'product_id' => $product->id,
            'sale_price' => 20000,
            'stock_limit' => 10,
        ]);

        $response = $this->get('/');

        $response->assertOk();
        $this->assertSame([$activeBanner->id], $response->viewData('banners')->modelKeys());
        $this->assertSame(['Flash Sale Berjalan'], $response->viewData('flashSales')->pluck('title')->all());
        $this->assertEqualsWithDelta(3600, $response->viewData('flashSales')->first()->remaining_seconds, 1);
        $this->assertSame([$store->id], $response->viewData('officialStores')->modelKeys());
        $this->assertSame([$store->id], $response->viewData('featuredStores')->modelKeys());
        $this->assertTrue($response->viewData('flashSales')->first()->relationLoaded('items'));
        $this->assertTrue($response->viewData('flashSales')->first()->items->first()->relationLoaded('product'));
        $this->assertTrue($response->viewData('latestProducts')->first()->relationLoaded('category'));
        $this->assertTrue($response->viewData('latestProducts')->first()->relationLoaded('store'));
    }

    public function test_catalog_search_category_filter_and_price_sort_use_database_products(): void
    {
        $food = Category::create(['name' => 'Makanan & Minuman', 'slug' => 'makanan-minuman', 'sort_order' => 1]);
        $fashion = Category::create(['name' => 'Fashion', 'slug' => 'fashion', 'sort_order' => 2]);
        $this->makeProduct($food, 'Kopi Gayo', 25000);
        $this->makeProduct($food, 'Kopi Robusta', 15000);
        $this->makeProduct($fashion, 'Kemeja Tenun', 90000);

        $response = $this->get('/produk?search=Kopi&category=makanan-minuman&sort=price_asc');

        $response->assertOk()->assertSeeInOrder(['Kopi Robusta', 'Kopi Gayo'])->assertDontSee('Kemeja Tenun');
    }

    public function test_category_page_and_product_detail_show_database_content_without_inventing_stock(): void
    {
        $category = Category::create(['name' => 'Kerajinan Lokal', 'slug' => 'kerajinan-lokal']);
        $product = $this->makeProduct($category, 'Tas Anyaman', 89000);

        $this->get('/kategori/kerajinan-lokal')->assertOk()->assertSee('Tas Anyaman');
        $this->get(route('products.show', $product->slug))->assertOk()->assertSee('Belum diperbarui')->assertSee('Rp 89.000');
    }

    public function test_local_product_images_use_a_host_relative_storage_url(): void
    {
        $category = Category::create(['name' => 'Kerajinan Lokal', 'slug' => 'kerajinan-lokal']);
        $product = $this->makeProduct($category, 'Produk Gambar Lokal', 89000);
        $product->update(['image' => 'products/contoh.jpg']);

        $this->get(route('products.show', $product->slug))
            ->assertOk()
            ->assertSee('/storage/products/contoh.jpg');
    }

    public function test_every_category_has_a_matching_product_platform(): void
    {
        $this->seed();

        $categories = Category::orderBy('sort_order')->get();
        $products = collect();

        foreach ($categories as $index => $category) {
            $products->push($this->makeProduct($category, 'Produk Uji Kategori '.$index, 10000 + $index));
        }

        foreach ($categories as $index => $category) {
            $response = $this->get(route('category', $category->slug));

            $response->assertOk()
                ->assertSeeText($category->name)
                ->assertSee($products[$index]->name);

            foreach ($products as $otherIndex => $product) {
                if ($otherIndex !== $index) {
                    $response->assertDontSee($product->name);
                }
            }
        }
    }

    public function test_category_shortcuts_open_the_matching_category_platform(): void
    {
        $food = Category::create(['name' => 'Makanan & Minuman', 'slug' => 'makanan-minuman']);
        $fashion = Category::create(['name' => 'Fashion', 'slug' => 'fashion']);
        $craft = Category::create(['name' => 'Kerajinan Tangan', 'slug' => 'kerajinan-tangan']);

        $coffee = $this->makeProduct($food, 'Kopi Lokal', 25000);
        $shirt = $this->makeProduct($fashion, 'Baju Tenun', 90000);
        $basket = $this->makeProduct($craft, 'Keranjang Anyaman', 50000);

        $this->get(route('makanan-lokal'))
            ->assertOk()->assertSee('Makanan Lokal Indonesia')->assertSee('Kopi Lokal')->assertDontSee('Baju Tenun')->assertDontSee('Keranjang Anyaman')
            ->assertSee(route('products.show', $coffee->slug));

        $this->get(route('fashion'))
            ->assertOk()->assertSee('Fashion lokal terbaik')->assertSee('Baju Tenun')->assertDontSee('Kopi Lokal')->assertDontSee('Keranjang Anyaman')
            ->assertSee(route('products.show', $shirt->slug));

        $this->get(route('fashion', ['category' => 'Pria']))
            ->assertOk()->assertSee('Baju Tenun')
            ->assertSee(route('category', $food->slug))
            ->assertSee(route('category', $fashion->slug))
            ->assertSee(route('category', $craft->slug));

        $this->get(route('kerajinan'))
            ->assertOk()->assertSee('Kerajinan Lokal')->assertSee('Keranjang Anyaman')->assertDontSee('Kopi Lokal')->assertDontSee('Baju Tenun')
            ->assertSee(route('products.show', $basket->slug));
    }

    public function test_fashion_subcategory_filters_update_products_and_show_the_empty_state(): void
    {
        $fashion = Category::create(['name' => 'Fashion', 'slug' => 'fashion']);
        $bag = $this->makeProduct($fashion, 'Tas Anyaman', 50000);
        $this->makeProduct($fashion, 'Baju Tenun', 90000);

        $this->get(route('fashion', ['subcategory' => 'tas']))
            ->assertOk()
            ->assertSee('Tas Anyaman')
            ->assertDontSee('Baju Tenun')
            ->assertSeeHtml('aria-current="page"');

        $this->get(route('fashion', ['subcategory' => 'sepatu']))
            ->assertOk()
            ->assertSee('Fashion belum ditemukan')
            ->assertSee('0 produk')
            ->assertDontSee($bag->name);
    }

    public function test_claimed_voucher_is_saved_and_prefilled_on_checkout(): void
    {
        $category = Category::create(['name' => 'Makanan', 'slug' => 'makanan']);
        $product = $this->makeProduct($category, 'Kopi Lokal', 120000);
        $this->makeVoucher('MOMA25', 'discount', 25000, 100000);
        $user = User::factory()->create();

        $this->actingAs($user)
            ->withSession(['cart' => [$product->id => 1]])
            ->postJson(route('voucher.claim'), ['code' => 'moma25'])
            ->assertOk()
            ->assertJsonPath('checkoutUrl', route('checkout.create'))
            ->assertSessionHas('checkout_voucher_code', 'MOMA25');

        $this->get(route('checkout.create'))
            ->assertOk()
            ->assertSee('value="MOMA25"', false);
    }

    public function test_free_shipping_voucher_from_promo_page_is_saved_for_checkout(): void
    {
        $category = Category::create(['name' => 'Makanan', 'slug' => 'makanan']);
        $product = $this->makeProduct($category, 'Kopi Lokal', 50000);
        $this->makeVoucher('ONGKIR10', 'shipping', 10000, 50000);
        $user = User::factory()->create();

        $this->actingAs($user)
            ->withSession(['cart' => [$product->id => 1]])
            ->postJson(route('voucher.claim'), ['code' => 'ongkir10'])
            ->assertOk()
            ->assertSessionHas('checkout_voucher_code', 'ONGKIR10');

        $this->get(route('checkout.create'))
            ->assertOk()
            ->assertSee('value="ONGKIR10"', false);
    }

    public function test_invalid_voucher_code_is_not_saved(): void
    {
        $this->postJson(route('voucher.claim'), ['code' => 'INVALID'])
            ->assertUnprocessable()
            ->assertSessionMissing('checkout_voucher_code');
    }

    public function test_voucher_claim_rejects_cart_below_minimum_spend(): void
    {
        $category = Category::create(['name' => 'Makanan', 'slug' => 'makanan']);
        $product = $this->makeProduct($category, 'Kopi Lokal', 30000);
        $this->makeVoucher('MOMA25', 'discount', 25000, 100000);

        $this->withSession(['cart' => [$product->id => 1]])
            ->postJson(route('voucher.claim'), ['code' => 'MOMA25'])
            ->assertUnprocessable()
            ->assertJsonValidationErrors('code')
            ->assertSessionMissing('checkout_voucher_code');
    }

    public function test_checkout_applies_discount_voucher_and_increments_usage_once(): void
    {
        $category = Category::create(['name' => 'Makanan', 'slug' => 'makanan']);
        $product = $this->makeProduct($category, 'Kopi Lokal', 120000, 3);
        $voucher = $this->makeVoucher('MOMA25', 'discount', 25000, 100000, quota: 1);
        $user = User::factory()->create();

        $this->actingAs($user)
            ->withSession([
                'cart' => [$product->id => 1],
                'checkout_voucher_code' => 'MOMA25',
            ])
            ->get(route('checkout.create'))
            ->assertOk()
            ->assertSee('Rp 110.000');

        $this->actingAs($user)
            ->withSession([
                'cart' => [$product->id => 1],
                'checkout_voucher_code' => 'MOMA25',
            ])
            ->post(route('checkout.store'), [
                'shipping_address' => 'Alamat pembeli',
                'contact_phone' => '081234567890',
                'payment_method' => 'cod',
            ])
            ->assertRedirect();

        $order = Order::firstOrFail();
        $this->assertSame(120000, $order->subtotal);
        $this->assertSame(15000, $order->shipping_cost);
        $this->assertSame('MOMA25', $order->voucher_code);
        $this->assertSame(25000, $order->discount_amount);
        $this->assertSame(1, $voucher->fresh()->used_count);
    }

    public function test_shipping_voucher_cannot_discount_more_than_base_shipping(): void
    {
        $category = Category::create(['name' => 'Makanan', 'slug' => 'makanan']);
        $product = $this->makeProduct($category, 'Kopi Lokal', 60000);
        $voucher = $this->makeVoucher('ONGKIR30', 'shipping', 30000, 50000);
        $user = User::factory()->create();

        $this->actingAs($user)
            ->withSession([
                'cart' => [$product->id => 1],
                'checkout_voucher_code' => 'ONGKIR30',
            ])
            ->post(route('checkout.store'), [
                'shipping_address' => 'Alamat pembeli',
                'contact_phone' => '081234567890',
                'payment_method' => 'cod',
            ])
            ->assertRedirect();

        $order = Order::firstOrFail();
        $this->assertSame(15000, $order->shipping_cost);
        $this->assertSame(15000, $order->discount_amount);
        $this->assertSame(1, $voucher->fresh()->used_count);
    }

    public function test_cashback_voucher_is_applied_as_capped_checkout_discount(): void
    {
        $category = Category::create(['name' => 'Makanan', 'slug' => 'makanan']);
        $product = $this->makeProduct($category, 'Kopi Lokal', 200000);
        $voucher = $this->makeVoucher('MOMA5', 'cashback', 5, 200000, maxDiscount: 8000);
        $user = User::factory()->create();

        $this->actingAs($user)
            ->withSession([
                'cart' => [$product->id => 1],
                'checkout_voucher_code' => 'MOMA5',
            ])
            ->post(route('checkout.store'), [
                'shipping_address' => 'Alamat pembeli',
                'contact_phone' => '081234567890',
                'payment_method' => 'cod',
            ])
            ->assertRedirect();

        $order = Order::firstOrFail();
        $this->assertSame(8000, $order->discount_amount);
        $this->assertSame(1, $voucher->fresh()->used_count);
    }

    public function test_checkout_rejects_exhausted_voucher_without_creating_order_or_changing_stock(): void
    {
        $category = Category::create(['name' => 'Makanan', 'slug' => 'makanan']);
        $product = $this->makeProduct($category, 'Kopi Lokal', 120000, 3);
        $voucher = $this->makeVoucher('MOMA25', 'discount', 25000, 100000, quota: 1);
        $voucher->update(['used_count' => 1]);
        $user = User::factory()->create();

        $this->actingAs($user)
            ->withSession([
                'cart' => [$product->id => 1],
                'checkout_voucher_code' => 'MOMA25',
            ])
            ->post(route('checkout.store'), [
                'shipping_address' => 'Alamat pembeli',
                'contact_phone' => '081234567890',
                'payment_method' => 'cod',
            ])
            ->assertSessionHasErrors('voucher');

        $this->assertDatabaseCount('orders', 0);
        $this->assertSame(3, $product->fresh()->stock);
        $this->assertSame(1, $voucher->fresh()->used_count);
    }

    public function test_guest_can_add_product_to_session_cart(): void
    {
        $category = Category::create(['name' => 'Makanan', 'slug' => 'makanan']);
        $product = $this->makeProduct($category, 'Kopi Lokal', 30000, 4);

        $this->post(route('cart.add', $product->slug), ['quantity' => 2])
            ->assertRedirect(route('cart.index'))
            ->assertSessionHas("cart.{$product->id}", 2);

        $this->get(route('cart.index'))->assertOk()->assertSee('Kopi Lokal')->assertSee('Rp 60.000');
    }

    public function test_flash_sale_buy_now_adds_the_product_and_opens_checkout(): void
    {
        $category = Category::create(['name' => 'Makanan', 'slug' => 'makanan']);
        $product = $this->makeProduct($category, 'Kopi Flash Sale', 30000, 4);
        $flashSale = FlashSale::create([
            'title' => 'Flash Sale Aktif',
            'starts_at' => now()->subMinute(),
            'ends_at' => now()->addHour(),
            'is_active' => true,
        ]);
        $flashSaleItem = FlashSaleItem::create([
            'flash_sale_id' => $flashSale->id,
            'product_id' => $product->id,
            'sale_price' => 20000,
            'stock_limit' => 3,
        ]);
        $user = User::factory()->create();

        $this->actingAs($user)->get(route('flash-sale'))
            ->assertOk()
            ->assertSee(route('cart.add', $product->slug))
            ->assertSee('name="flash_sale_item_id" value="'.$flashSaleItem->id.'"', false)
            ->assertSee('name="redirect_to" value="checkout"', false);

        $this->actingAs($user)->post(route('cart.add', $product->slug), [
            'quantity' => 1,
            'flash_sale_item_id' => $flashSaleItem->id,
            'redirect_to' => 'checkout',
        ])->assertRedirect(route('checkout.create'))
            ->assertSessionHas("cart.{$product->id}", 1)
            ->assertSessionHas("flash_sale_items.{$product->id}", $flashSaleItem->id);

        $this->get(route('checkout.create'))->assertOk()->assertSee('Kopi Flash Sale')->assertSee('Rp 20.000');
    }

    public function test_checkout_atomically_consumes_flash_sale_stock_and_increments_sold_count(): void
    {
        $category = Category::create(['name' => 'Makanan', 'slug' => 'makanan']);
        $product = $this->makeProduct($category, 'Kopi Promo', 30000, 5);
        $user = User::factory()->create();
        $flashSale = FlashSale::create([
            'title' => 'Flash Sale Aktif',
            'starts_at' => now()->subMinute(),
            'ends_at' => now()->addHour(),
            'is_active' => true,
        ]);
        $flashSaleItem = FlashSaleItem::create([
            'flash_sale_id' => $flashSale->id,
            'product_id' => $product->id,
            'sale_price' => 21000,
            'stock_limit' => 4,
            'sold_count' => 1,
        ]);

        $this->actingAs($user)
            ->withSession([
                'cart' => [$product->id => 2],
                'flash_sale_items' => [$product->id => $flashSaleItem->id],
            ])
            ->post(route('checkout.store'), [
                'shipping_address' => 'Alamat pembeli',
                'contact_phone' => '081234567890',
                'payment_method' => 'cod',
            ])
            ->assertRedirect();

        $order = Order::firstOrFail();
        $this->assertSame(42000, $order->subtotal);
        $this->assertDatabaseHas('order_items', [
            'order_id' => $order->id,
            'product_id' => $product->id,
            'quantity' => 2,
            'price' => 21000,
        ]);
        $this->assertSame(3, $flashSaleItem->fresh()->sold_count);
        $this->assertSame(3, $product->fresh()->stock);
    }

    public function test_checkout_rejects_flash_sale_quantity_over_remaining_stock_without_partial_updates(): void
    {
        $category = Category::create(['name' => 'Makanan', 'slug' => 'makanan']);
        $product = $this->makeProduct($category, 'Kopi Promo Habis', 30000, 5);
        $user = User::factory()->create();
        $flashSale = FlashSale::create([
            'title' => 'Flash Sale Hampir Habis',
            'starts_at' => now()->subMinute(),
            'ends_at' => now()->addHour(),
            'is_active' => true,
        ]);
        $flashSaleItem = FlashSaleItem::create([
            'flash_sale_id' => $flashSale->id,
            'product_id' => $product->id,
            'sale_price' => 21000,
            'stock_limit' => 3,
            'sold_count' => 2,
        ]);

        $this->actingAs($user)
            ->withSession([
                'cart' => [$product->id => 2],
                'flash_sale_items' => [$product->id => $flashSaleItem->id],
            ])
            ->post(route('checkout.store'), [
                'shipping_address' => 'Alamat pembeli',
                'contact_phone' => '081234567890',
                'payment_method' => 'cod',
            ])
            ->assertSessionHasErrors('cart');

        $this->assertDatabaseCount('orders', 0);
        $this->assertSame(2, $flashSaleItem->fresh()->sold_count);
        $this->assertSame(5, $product->fresh()->stock);
    }

    public function test_authenticated_buyer_can_toggle_wishlist(): void
    {
        $category = Category::create(['name' => 'Fashion', 'slug' => 'fashion']);
        $product = $this->makeProduct($category, 'Kain Lokal', 40000);
        $user = User::factory()->create();

        $this->actingAs($user)->post(route('wishlist.toggle', $product->slug))->assertRedirect();
        $this->assertTrue($user->wishlistProducts()->whereKey($product->id)->exists());
        $this->actingAs($user)->get(route('wishlist'))->assertOk()->assertSee('Kain Lokal');
    }

    public function test_account_dashboard_uses_only_the_authenticated_users_real_data(): void
    {
        $user = User::factory()->create(['name' => 'Pembeli MoMa', 'email' => 'pembeli@example.test']);
        $otherUser = User::factory()->create();

        $user->orders()->create([
            'order_number' => 'NM-PEMBELI123',
            'status' => 'awaiting_confirmation',
            'subtotal' => 125000,
            'shipping_cost' => null,
            'shipping_address' => 'Alamat pengiriman pembeli',
            'contact_phone' => '081234567890',
        ]);

        Store::create([
            'user_id' => $user->id,
            'store_name' => 'Toko Pemilik Akun',
            'slug' => 'toko-pemilik-akun',
            'category' => 'Kerajinan',
            'phone' => '081234567890',
            'address' => 'Alamat toko',
            'status' => 'pending',
        ]);

        Store::create([
            'user_id' => $otherUser->id,
            'store_name' => 'Toko Akun Lain',
            'slug' => 'toko-akun-lain',
            'category' => 'Fashion',
            'phone' => '081234567891',
            'address' => 'Alamat toko lain',
            'status' => 'approved',
        ]);

        $this->actingAs($user)->get(route('dashboard'))
            ->assertOk()
            ->assertDontSee('aria-label="Navigasi akun MoMa.id"', false)
            ->assertSee('Pembeli MoMa')
            ->assertSee('pembeli@example.test')
            ->assertSeeHtml('<span class="account-order-count">1</span>')
            ->assertSee('Belum Bayar')
            ->assertSee('Dikemas')
            ->assertSee('Dikirim')
            ->assertSee('Selesai')
            ->assertSee('Toko Pemilik Akun')
            ->assertSee('Menunggu verifikasi')
            ->assertDontSee('Toko Akun Lain')
            ->assertDontSee('Member Gold')
            ->assertDontSee('4.280')
            ->assertDontSee('72%');
    }

    public function test_dashboard_order_status_counts_and_history_filters_are_separate(): void
    {
        $user = User::factory()->create();
        $otherUser = User::factory()->create();
        $statuses = [
            'awaiting_payment' => 'NM-UNPAID-001',
            'awaiting_confirmation' => 'NM-PACKED-001',
            'processing' => 'NM-PACKED-002',
            'shipped' => 'NM-SHIPPED-001',
            'completed' => 'NM-COMPLETED-001',
        ];

        foreach ($statuses as $status => $orderNumber) {
            $user->orders()->create([
                'order_number' => $orderNumber,
                'status' => $status,
                'subtotal' => 25000,
                'shipping_cost' => 15000,
                'shipping_address' => 'Alamat pembeli',
                'contact_phone' => '081234567890',
            ]);
        }

        $otherUser->orders()->create([
            'order_number' => 'NM-OTHER-UNPAID-001',
            'status' => 'awaiting_payment',
            'subtotal' => 25000,
            'shipping_cost' => 15000,
            'shipping_address' => 'Alamat akun lain',
            'contact_phone' => '081234567891',
        ]);

        $this->actingAs($user)->get(route('dashboard'))
            ->assertViewHas('orderStatusCounts', [
                'unpaid' => 1,
                'packed' => 2,
                'shipped' => 1,
                'completed' => 1,
            ])
            ->assertSee(route('orders', ['status' => 'unpaid']))
            ->assertSee(route('orders', ['status' => 'packed']))
            ->assertSee(route('orders', ['status' => 'shipped']))
            ->assertSee(route('orders', ['status' => 'completed']));

        $this->get(route('orders', ['status' => 'unpaid']))
            ->assertOk()
            ->assertSee('NM-UNPAID-001')
            ->assertDontSee('NM-PACKED-001')
            ->assertDontSee('NM-OTHER-UNPAID-001');

        $this->get(route('orders', ['status' => 'packed']))
            ->assertOk()
            ->assertSee('NM-PACKED-001')
            ->assertSee('NM-PACKED-002')
            ->assertDontSee('NM-SHIPPED-001');

        $this->get(route('orders', ['status' => 'shipped']))
            ->assertOk()
            ->assertSee('NM-SHIPPED-001')
            ->assertDontSee('NM-COMPLETED-001');

        $this->get(route('orders', ['status' => 'completed']))
            ->assertOk()
            ->assertSee('NM-COMPLETED-001')
            ->assertDontSee('NM-SHIPPED-001');
    }

    public function test_order_history_shows_localized_status_item_count_and_order_details_link(): void
    {
        $user = User::factory()->create();
        $category = Category::create(['name' => 'Makanan', 'slug' => 'makanan']);
        $product = $this->makeProduct($category, 'Kopi Lokal', 25000);
        $order = $user->orders()->create([
            'order_number' => 'NM-HISTORY-001',
            'status' => 'awaiting_confirmation',
            'subtotal' => 50000,
            'shipping_cost' => null,
            'shipping_address' => 'Alamat pembeli',
            'contact_phone' => '081234567890',
        ]);
        $order->items()->create([
            'product_id' => $product->id,
            'product_name' => $product->name,
            'seller' => $product->seller,
            'image' => $product->image,
            'quantity' => 2,
            'price' => $product->price,
        ]);

        $this->actingAs($user)->get(route('orders'))
            ->assertOk()
            ->assertSee('Riwayat pesanan')
            ->assertSee('NM-HISTORY-001')
            ->assertSee('Menunggu konfirmasi')
            ->assertSee('2 item')
            ->assertSee('Rp 50.000')
            ->assertSee(route('orders.show', $order));
    }

    public function test_store_application_routes_require_authentication(): void
    {
        $this->get(route('stores.create'))->assertRedirect(route('login'));
        $this->post(route('stores.store'))->assertRedirect(route('login'));
    }

    public function test_store_application_is_automatically_approved_for_the_authenticated_user(): void
    {
        $user = User::factory()->create();

        $this->actingAs($user)->post(route('stores.store'), [
            'store_name' => 'Toko Lokal',
            'category' => 'Kerajinan Lokal',
            'phone' => '081234567890',
            'address' => 'Banda Aceh',
        ])->assertRedirect(route('stores.create'))
            ->assertSessionHas('success', 'Toko berhasil dibuat dan langsung dikonfirmasi.');

        $this->assertDatabaseHas('stores', [
            'user_id' => $user->id,
            'store_name' => 'Toko Lokal',
            'status' => 'approved',
        ]);

        $this->get(route('stores.create'))->assertOk()->assertSee('Disetujui');
    }

    public function test_checkout_creates_order_and_decrements_known_stock(): void
    {
        $category = Category::create(['name' => 'Kerajinan', 'slug' => 'kerajinan']);
        $product = $this->makeProduct($category, 'Keranjang Anyaman', 50000, 5);
        $user = User::factory()->create();

        $response = $this->actingAs($user)
            ->withSession(['cart' => [$product->id => 2]])
            ->post(route('checkout.store'), [
                'shipping_address' => 'Jl. Pasar Lokal No. 10, Banda Aceh',
                'contact_phone' => '081234567890',
                'payment_method' => 'cod',
            ]);

        $order = Order::firstOrFail();
        $response->assertRedirect(route('orders.show', $order));
        $this->assertDatabaseHas('orders', ['id' => $order->id, 'user_id' => $user->id, 'subtotal' => 100000, 'status' => 'awaiting_confirmation']);
        $this->assertDatabaseHas('order_items', ['order_id' => $order->id, 'product_id' => $product->id, 'quantity' => 2, 'price' => 50000]);
        $this->assertSame(3, $product->fresh()->stock);
        $response->assertSessionMissing('cart');
    }

    private function makeProduct(Category $category, string $name, int $price, ?int $stock = null): Product
    {
        return Product::create([
            'category_id' => $category->id,
            'name' => $name,
            'slug' => str($name)->slug(),
            'description' => 'Produk lokal berkualitas.',
            'seller' => 'UMKM Test',
            'location' => 'Banda Aceh',
            'price' => $price,
            'stock' => $stock,
            'image' => 'https://example.test/product.jpg',
        ]);
    }

    private function makeVoucher(
        string $code,
        string $type,
        int $amount,
        int $minimumSpend,
        ?int $maxDiscount = null,
        ?int $quota = null,
    ): Voucher {
        return Voucher::create([
            'code' => $code,
            'type' => $type,
            'amount' => $amount,
            'min_spend' => $minimumSpend,
            'max_discount' => $maxDiscount,
            'quota' => $quota,
            'used_count' => 0,
            'is_active' => true,
            'starts_at' => now()->subDay(),
            'ends_at' => now()->addDay(),
        ]);
    }
}
