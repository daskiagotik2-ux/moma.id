<?php

namespace Tests\Feature;

use App\Models\Voucher;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class VoucherTest extends TestCase
{
    use RefreshDatabase;

    public function test_voucher_marketplace_is_rendered(): void
    {
        Voucher::create([
            'code' => 'MOMA25',
            'type' => 'discount',
            'amount' => 25000,
            'min_spend' => 100000,
            'is_active' => true,
            'starts_at' => now()->subDay(),
            'ends_at' => now()->addDay(),
        ]);

        $response = $this->get(route('voucher'));

        $response->assertOk();
        $response->assertSee('Voucher Saya');
        $response->assertSee('Gunakan voucher untuk mendapatkan harga terbaik.');
        $response->assertSee('Semua');
        $response->assertSee('Gratis Ongkir');
        $response->assertSee('Diskon');
        $response->assertSee('Cashback');
        $response->assertSee('Voucher Pilihan');
        $response->assertSee('MOMA25');
    }

    public function test_voucher_marketplace_hides_expired_or_exhausted_database_vouchers(): void
    {
        Voucher::create([
            'code' => 'EXPIRED',
            'type' => 'discount',
            'amount' => 10000,
            'ends_at' => now()->subSecond(),
            'is_active' => true,
        ]);
        Voucher::create([
            'code' => 'SOLDOUT',
            'type' => 'discount',
            'amount' => 10000,
            'quota' => 1,
            'used_count' => 1,
            'is_active' => true,
        ]);

        $this->get(route('voucher'))
            ->assertOk()
            ->assertDontSee('EXPIRED')
            ->assertDontSee('SOLDOUT');
    }

    public function test_free_shipping_page_lists_only_active_shipping_vouchers_from_database(): void
    {
        Voucher::create([
            'code' => 'ONGKIR10',
            'type' => 'shipping',
            'amount' => 10000,
            'min_spend' => 50000,
            'is_active' => true,
            'starts_at' => now()->subDay(),
            'ends_at' => now()->addDay(),
        ]);
        Voucher::create([
            'code' => 'DISKON',
            'type' => 'discount',
            'amount' => 10000,
            'is_active' => true,
        ]);

        $this->get(route('gratis-ongkir'))
            ->assertOk()
            ->assertSee('ONGKIR10')
            ->assertDontSee('data-voucher-code="DISKON"', false);
    }
}
