<?php

namespace Tests\Feature;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class KategoriTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed();
    }

    public function test_semua_kategori_page_is_rendered(): void
    {
        $response = $this->get(route('kategori'));

        $response->assertOk();
        $response->assertSee('Semua Kategori');
        $response->assertSee('Jelajahi produk UMKM berdasarkan kategori yang sesuai dengan kebutuhanmu.');
        $response->assertSee('Fashion');
        $response->assertSee('Makanan & Minuman');
        $response->assertSee('Elektronik');
        $response->assertSee('Otomotif');
        $response->assertDontSee('Flash Sale');
        $response->assertDontSee('Voucher');
        $this->assertSame(10, substr_count($response->getContent(), 'class="category-card category-card--'));
    }

    public function test_placeholder_category_is_rendered(): void
    {
        $response = $this->get(route('kategori.placeholder', 'elektronik'));

        $response->assertRedirect(route('category', 'elektronik'));
        $this->get(route('category', 'elektronik'))->assertOk()->assertSeeText('Elektronik');
    }

    public function test_primary_navigation_activates_only_the_current_section(): void
    {
        foreach ([
            ['route' => 'home', 'label' => 'Beranda'],
            ['route' => 'kategori', 'label' => 'Kategori'],
            ['route' => 'shop', 'label' => 'UMKM'],
            ['route' => 'promo', 'label' => 'Promo'],
        ] as $section) {
            $route = $section['route'];
            $response = $this->get(route($route));
            $response->assertOk();
            $activeLinkPattern = '/<a[^>]*class="header-nav-link header-nav-link-active"[^>]*aria-current="page"[^>]*>'.preg_quote($section['label'], '/').'<\/a>/';

            $this->assertMatchesRegularExpression($activeLinkPattern, $response->getContent());
            $this->assertSame(1, substr_count($response->getContent(), 'header-nav-link-active'));
        }
    }

    public function test_mobile_menu_button_controls_the_primary_navigation(): void
    {
        $response = $this->get(route('home'));

        $response->assertOk()
            ->assertSee('aria-controls="primary-navigation"', false)
            ->assertSee(':aria-expanded="mobileMenuOpen"', false)
            ->assertSee("navigation-open", false)
            ->assertSee("window.matchMedia('(min-width: 1024px)').matches", false)
            ->assertSee("@keydown.escape.window=\"mobileMenuOpen = false\"", false);
    }
}
