<?php

namespace Tests\Feature;

use App\Enums\PaymentMethod;
use App\Enums\PaymentRecordStatus;
use App\Enums\PaymentStatus;
use App\Models\Category;
use App\Models\FlashSale;
use App\Models\FlashSaleItem;
use App\Models\Order;
use App\Models\Payment;
use App\Models\Product;
use App\Models\Store;
use App\Models\User;
use App\Models\Voucher;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;

class PaymentFlowTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        config([
            'payment.methods.bank_transfer.accounts.BCA.number' => '1234567890',
            'payment.methods.qris.image' => 'images/test-qris.png',
        ]);
    }

    public function test_checkout_requires_payment_method(): void
    {
        [$buyer, $product] = $this->makeBuyerAndProduct();

        $this->actingAs($buyer)
            ->withSession(['cart' => [$product->id => 1]])
            ->post(route('checkout.store'), [
                'shipping_address' => 'Alamat pembeli',
                'contact_phone' => '081234567890',
            ])
            ->assertSessionHasErrors('payment_method');

        $this->assertDatabaseCount('orders', 0);
    }

    public function test_checkout_displays_configured_payment_methods_and_serverside_costs(): void
    {
        [$buyer, $product] = $this->makeBuyerAndProduct();

        $this->actingAs($buyer)->withSession(['cart' => [$product->id => 1]])
            ->get(route('checkout.create'))
            ->assertOk()
            ->assertSee('Metode Pembayaran')
            ->assertSee('Bayar di Tempat (COD)')
            ->assertSee('Transfer Bank')
            ->assertSee('E-wallet / QRIS')
            ->assertSee('Rp 115.000');
    }

    public function test_manual_methods_without_payment_instructions_are_not_available(): void
    {
        config([
            'payment.methods.bank_transfer.accounts.BCA.number' => '',
            'payment.methods.bank_transfer.accounts.BRI.number' => '',
            'payment.methods.bank_transfer.accounts.Mandiri.number' => '',
            'payment.methods.qris.image' => '',
        ]);
        [$buyer, $product] = $this->makeBuyerAndProduct();

        $this->actingAs($buyer)->withSession(['cart' => [$product->id => 1]])
            ->get(route('checkout.create'))
            ->assertOk()
            ->assertSee('Bayar di Tempat (COD)')
            ->assertDontSee('Transfer Bank')
            ->assertDontSee('E-wallet / QRIS');

        $this->actingAs($buyer)->withSession(['cart' => [$product->id => 1]])
            ->post(route('checkout.store'), [
                'shipping_address' => 'Alamat pembeli',
                'contact_phone' => '081234567890',
                'payment_method' => 'bank_transfer',
            ])
            ->assertSessionHasErrors('payment_method');

        $this->assertDatabaseCount('orders', 0);
    }

    public function test_cod_checkout_is_unpaid_and_seller_can_approve(): void
    {
        [$buyer, $product, $storeOwner] = $this->makeBuyerAndProduct(withStore: true);

        $response = $this->actingAs($buyer)
            ->withSession(['cart' => [$product->id => 1]])
            ->post(route('checkout.store'), [
                'shipping_address' => 'Alamat pembeli',
                'contact_phone' => '081234567890',
                'payment_method' => 'cod',
            ]);
        $order = Order::firstOrFail();

        $response->assertRedirect(route('orders.show', $order));
        $this->assertSame(PaymentMethod::Cod, $order->payment_method);
        $this->assertSame(PaymentStatus::Unpaid, $order->payment_status);
        $this->assertSame('awaiting_confirmation', $order->status);
        $this->assertDatabaseCount('payments', 0);

        $this->actingAs($storeOwner)
            ->post(route('seller.orders.approve', $order))
            ->assertRedirect(route('seller.orders'));
        $this->assertDatabaseHas('orders', ['id' => $order->id, 'status' => 'processing']);
    }

    public function test_bank_transfer_order_cannot_be_approved_until_payment_is_verified(): void
    {
        [$buyer, $product, $storeOwner] = $this->makeBuyerAndProduct(withStore: true);
        $this->makeVoucher();

        $this->actingAs($buyer)
            ->withSession([
                'cart' => [$product->id => 1],
                'checkout_voucher_code' => 'PAY25',
            ])
            ->post(route('checkout.store'), [
                'shipping_address' => 'Alamat pembeli',
                'contact_phone' => '081234567890',
                'payment_method' => 'bank_transfer',
            ])
            ->assertRedirect(route('orders.pay', Order::firstOrFail()));

        $order = Order::firstOrFail();
        $this->assertSame('awaiting_payment', $order->status);
        $this->assertSame(PaymentStatus::Unpaid, $order->payment_status);
        $this->assertSame(90000, $order->grand_total);
        $this->assertDatabaseHas('payments', ['order_id' => $order->id, 'method' => 'bank_transfer', 'amount' => 90000]);
        $this->actingAs($buyer)->get(route('orders.pay', $order))
            ->assertOk()
            ->assertSee('Nominal pembayaran')
            ->assertSee('Rp 90.000');

        $this->actingAs($storeOwner)
            ->post(route('seller.orders.approve', $order))
            ->assertStatus(422)
            ->assertSee('Pembayaran non-COD harus disetujui seluruh toko terlebih dahulu.');
        $this->assertDatabaseHas('orders', ['id' => $order->id, 'status' => 'awaiting_payment']);
    }

    public function test_only_order_owner_can_upload_proof_and_seller_verification_enables_order_approval(): void
    {
        Storage::fake(config('payment.proof_disk'));
        [$buyer, $product, $storeOwner] = $this->makeBuyerAndProduct(withStore: true);
        $this->actingAs($buyer)
            ->withSession(['cart' => [$product->id => 1]])
            ->post(route('checkout.store'), [
                'shipping_address' => 'Alamat pembeli',
                'contact_phone' => '081234567890',
                'payment_method' => 'qris',
            ]);
        $order = Order::firstOrFail();
        $payment = $order->payments()->firstOrFail();

        $otherUser = User::factory()->create();
        $this->actingAs($otherUser)->get(route('orders.pay', $order))->assertNotFound();
        $this->actingAs($otherUser)
            ->post(route('orders.payments.upload', $order), ['proof' => UploadedFile::fake()->image('bukti.png')])
            ->assertNotFound();

        $this->actingAs($buyer)
            ->post(route('orders.payments.upload', $order), ['proof' => UploadedFile::fake()->image('bukti.png')])
            ->assertRedirect(route('orders.pay', $order));
        $payment->refresh();
        $this->assertNotNull($payment->proof_path);
        Storage::disk(config('payment.proof_disk'))->assertExists($payment->proof_path);
        $this->assertSame(PaymentStatus::WaitingVerification, $order->fresh()->payment_status);
        $this->actingAs($buyer)->get(route('payments.proof', $payment))->assertOk();
        $this->actingAs($storeOwner)->get(route('payments.proof', $payment))->assertOk();

        $this->actingAs($storeOwner)
            ->post(route('seller.orders.payments.verify', [$order, $payment]), ['decision' => 'approve', 'note' => 'Transfer sesuai.'])
            ->assertRedirect(route('seller.orders'));
        $order->refresh();
        $this->assertSame(PaymentStatus::Paid, $order->payment_status);
        $this->assertSame('awaiting_confirmation', $order->status);
        $this->assertNotNull($order->paid_at);
        $this->assertSame(PaymentRecordStatus::Verified, $payment->fresh()->status);

        $this->actingAs($storeOwner)
            ->post(route('seller.orders.approve', $order))
            ->assertRedirect(route('seller.orders'));
        $this->assertDatabaseHas('orders', ['id' => $order->id, 'status' => 'processing']);

        $this->actingAs($storeOwner)
            ->post(route('seller.orders.payments.verify', [$order, $payment]), ['decision' => 'approve'])
            ->assertSessionHas('success', 'Pembayaran ini sudah diproses sebelumnya.');
    }

    public function test_seller_can_reject_proof_and_buyer_can_resubmit_before_expiry(): void
    {
        Storage::fake(config('payment.proof_disk'));
        [$buyer, $product, $storeOwner] = $this->makeBuyerAndProduct(withStore: true);
        $this->actingAs($buyer)->withSession(['cart' => [$product->id => 1]])
            ->post(route('checkout.store'), [
                'shipping_address' => 'Alamat pembeli',
                'contact_phone' => '081234567890',
                'payment_method' => 'bank_transfer',
            ]);
        $order = Order::firstOrFail();
        $this->actingAs($buyer)->post(route('orders.payments.upload', $order), ['proof' => UploadedFile::fake()->image('first.png')])
            ->assertRedirect(route('orders.pay', $order));
        $firstPayment = $order->payments()->firstOrFail();
        $this->actingAs($storeOwner)->post(route('seller.orders.payments.verify', [$order, $firstPayment]), [
            'decision' => 'reject',
            'note' => 'Nominal tidak sesuai.',
        ])->assertRedirect();

        $this->assertSame(PaymentStatus::Failed, $order->fresh()->payment_status);
        $this->actingAs($buyer)->post(route('orders.payments.upload', $order), ['proof' => UploadedFile::fake()->image('second.png')])
            ->assertRedirect(route('orders.pay', $order));
        $this->assertSame(2, $order->payments()->count());
        $this->assertSame(PaymentStatus::WaitingVerification, $order->fresh()->payment_status);
    }

    public function test_only_a_seller_with_items_in_the_order_can_verify_payment(): void
    {
        [$buyer, $product, $storeOwner] = $this->makeBuyerAndProduct(withStore: true);
        $this->actingAs($buyer)->withSession(['cart' => [$product->id => 1]])
            ->post(route('checkout.store'), [
                'shipping_address' => 'Alamat pembeli',
                'contact_phone' => '081234567890',
                'payment_method' => 'bank_transfer',
            ]);
        $order = Order::firstOrFail();
        $payment = $order->payments()->firstOrFail();
        Storage::fake(config('payment.proof_disk'));
        $this->actingAs($buyer)->post(route('orders.payments.upload', $order), [
            'proof' => UploadedFile::fake()->image('bukti.png'),
        ])->assertRedirect(route('orders.pay', $order));

        $unrelatedSeller = User::factory()->create();
        Store::create([
            'user_id' => $unrelatedSeller->id,
            'store_name' => 'Toko Tidak Terkait',
            'slug' => 'toko-tidak-terkait',
            'category' => 'Kerajinan',
            'phone' => '081234567892',
            'address' => 'Alamat toko lain',
            'status' => 'approved',
        ]);
        $this->actingAs($unrelatedSeller)
            ->post(route('seller.orders.payments.verify', [$order, $payment]), ['decision' => 'approve'])
            ->assertNotFound();
        $this->assertSame(PaymentStatus::WaitingVerification, $order->fresh()->payment_status);
    }

    public function test_each_store_must_approve_multi_store_order_payment(): void
    {
        Storage::fake(config('payment.proof_disk'));
        [$buyer, $firstProduct, $firstSeller] = $this->makeBuyerAndProduct(withStore: true);
        $secondSeller = User::factory()->create();
        $secondStore = Store::create([
            'user_id' => $secondSeller->id,
            'store_name' => 'Toko Kedua',
            'slug' => 'toko-kedua',
            'category' => 'Kerajinan',
            'phone' => '081234567891',
            'address' => 'Alamat toko kedua',
            'status' => 'approved',
        ]);
        $secondProduct = $secondStore->products()->create([
            'category_id' => $firstProduct->category_id,
            'name' => 'Produk Kedua',
            'slug' => 'produk-kedua',
            'seller' => $secondStore->store_name,
            'location' => 'Jakarta',
            'price' => 50000,
            'stock' => 5,
            'image' => 'https://example.test/second-product.jpg',
        ]);
        $this->actingAs($buyer)->withSession(['cart' => [$firstProduct->id => 1, $secondProduct->id => 1]])
            ->post(route('checkout.store'), [
                'shipping_address' => 'Alamat pembeli',
                'contact_phone' => '081234567890',
                'payment_method' => 'bank_transfer',
            ]);
        $order = Order::firstOrFail();
        $payment = $order->payments()->firstOrFail();
        $this->actingAs($buyer)->post(route('orders.payments.upload', $order), [
            'proof' => UploadedFile::fake()->image('bukti.png'),
        ])->assertRedirect(route('orders.pay', $order));

        $this->actingAs($firstSeller)
            ->post(route('seller.orders.payments.verify', [$order, $payment]), ['decision' => 'approve'])
            ->assertRedirect(route('seller.orders'));
        $this->assertSame(PaymentStatus::WaitingVerification, $order->fresh()->payment_status);
        $this->assertSame('awaiting_payment', $order->fresh()->status);

        $this->actingAs($secondSeller)
            ->post(route('seller.orders.payments.verify', [$order, $payment]), ['decision' => 'approve'])
            ->assertRedirect(route('seller.orders'));
        $this->assertSame(PaymentStatus::Paid, $order->fresh()->payment_status);
        $this->assertSame('awaiting_confirmation', $order->fresh()->status);
        $this->assertSame(2, $payment->approvals()->count());
    }

    public function test_expiration_command_cancels_order_and_restores_product_and_flash_sale_stock(): void
    {
        [$buyer, $product] = $this->makeBuyerAndProduct(stock: 5);
        $flashSale = FlashSale::create([
            'title' => 'Promo',
            'starts_at' => now()->subHour(),
            'ends_at' => now()->addHour(),
            'is_active' => true,
        ]);
        $flashSaleItem = FlashSaleItem::create([
            'flash_sale_id' => $flashSale->id,
            'product_id' => $product->id,
            'sale_price' => 8000,
            'stock_limit' => 4,
            'sold_count' => 2,
        ]);
        $product->update(['stock' => 3]);
        $order = $buyer->orders()->create([
            'order_number' => 'NM-EXPIRED-001',
            'status' => 'awaiting_payment',
            'subtotal' => 16000,
            'shipping_cost' => 15000,
            'shipping_address' => 'Alamat pembeli',
            'contact_phone' => '081234567890',
            'payment_method' => PaymentMethod::BankTransfer,
            'payment_status' => PaymentStatus::Unpaid,
            'payment_expires_at' => now()->subMinute(),
        ]);
        $order->items()->create([
            'product_id' => $product->id,
            'flash_sale_item_id' => $flashSaleItem->id,
            'product_name' => $product->name,
            'seller' => 'UMKM Test',
            'quantity' => 2,
            'price' => 8000,
        ]);
        Payment::factory()->create(['order_id' => $order->id, 'method' => 'bank_transfer', 'amount' => $order->grand_total]);

        $this->artisan('payments:expire')->assertSuccessful();

        $this->assertDatabaseHas('orders', ['id' => $order->id, 'status' => 'cancelled', 'payment_status' => 'expired']);
        $this->assertSame(5, $product->fresh()->stock);
        $this->assertSame(0, $flashSaleItem->fresh()->sold_count);
        $this->artisan('payments:expire')->expectsOutput('0 pesanan pembayaran kedaluwarsa diproses.')->assertSuccessful();
        $this->assertSame(5, $product->fresh()->stock);
    }

    private function makeBuyerAndProduct(bool $withStore = false, ?int $stock = 5): array
    {
        $buyer = User::factory()->create();
        $storeOwner = $withStore ? User::factory()->create() : null;
        $store = $storeOwner ? Store::create([
            'user_id' => $storeOwner->id,
            'store_name' => 'Toko Pembayaran',
            'slug' => 'toko-pembayaran',
            'category' => 'Kerajinan',
            'phone' => '081234567890',
            'address' => 'Alamat toko',
            'status' => 'approved',
        ]) : null;
        $category = Category::create(['name' => 'Kerajinan', 'slug' => 'kerajinan']);
        $attributes = [
            'category_id' => $category->id,
            'name' => 'Produk Pembayaran',
            'slug' => 'produk-pembayaran',
            'seller' => $store?->store_name ?? 'UMKM Test',
            'location' => 'Jakarta',
            'price' => 100000,
            'stock' => $stock,
            'image' => 'https://example.test/product.jpg',
        ];
        $product = $store ? $store->products()->create($attributes) : Product::create($attributes);

        return [$buyer, $product, $storeOwner];
    }

    private function makeVoucher(): Voucher
    {
        return Voucher::create([
            'code' => 'PAY25',
            'type' => 'discount',
            'amount' => 25000,
            'min_spend' => 0,
            'is_active' => true,
            'starts_at' => now()->subDay(),
            'ends_at' => now()->addDay(),
        ]);
    }
}
