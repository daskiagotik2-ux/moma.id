<?php

namespace Tests\Feature;

use App\Models\Category;
use App\Models\Product;
use App\Models\Store;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;

class SellerCenterTest extends TestCase
{
    use RefreshDatabase;

    public function test_seller_routes_send_guests_to_login_and_users_without_a_store_to_registration(): void
    {
        $this->get(route('seller.dashboard'))->assertRedirect(route('login'));
        $this->get(route('seller.products.index'))->assertRedirect(route('login'));

        $user = User::factory()->create();
        $this->actingAs($user)->get(route('seller.dashboard'))
            ->assertOk()
            ->assertSee('Akun ini belum memiliki toko')
            ->assertSee('Buka Toko Sekarang');
        $this->actingAs($user)->get(route('seller.products.index'))
            ->assertRedirect(route('stores.create'));
    }

    public function test_store_application_shows_store_details_and_seller_center_link(): void
    {
        $user = User::factory()->create();

        $this->actingAs($user)->post(route('stores.store'), [
            'store_name' => 'Kriya Pagi',
            'category' => 'Kerajinan Lokal',
            'description' => 'Produk kerajinan buatan lokal.',
            'phone' => '081234567890',
            'address' => 'Banda Aceh',
        ])->assertRedirect(route('stores.create'));

        $response = $this->actingAs($user)->get(route('stores.create'));
        $response
            ->assertOk()
            ->assertSee('Kriya Pagi')
            ->assertSee('Masuk ke Seller Center')
            ->assertSee(route('seller.dashboard'))
            ->assertDontSee('Nama Toko *');

        $this->assertMatchesRegularExpression(
            '/<a[^>]*class="header-nav-link header-nav-link-active"[^>]*aria-current="page"[^>]*>Seller Center<\/a>/',
            $response->getContent()
        );
        $this->assertSame(1, substr_count($response->getContent(), 'header-nav-link-active'));
    }

    public function test_store_owner_can_submit_prices_with_thousands_separator(): void
    {
        Storage::fake('public');
        $user = User::factory()->create();
        $store = $this->makeStore($user, 'Toko Teh');
        $category = Category::create(['name' => 'Makanan & Minuman', 'slug' => 'makanan-minuman']);

        $this->actingAs($user)->post(route('seller.products.store'), [
            'name' => 'Teh Daun Lokal',
            'category_id' => $category->id,
            'description' => 'Teh lokal pilihan.',
            'price' => '43,000',
            'stock' => 8,
            'image' => UploadedFile::fake()->image('teh.jpg'),
        ])->assertRedirect(route('seller.products.index'));

        $product = Product::withoutGlobalScope('marketplace_approved_store')->where('name', 'Teh Daun Lokal')->firstOrFail();
        $this->assertSame(43000, $product->price);
    }

    public function test_store_owner_can_create_update_and_delete_products_with_uploaded_images(): void
    {
        Storage::fake('public');
        $user = User::factory()->create();
        $store = $this->makeStore($user, 'Toko Teh');
        $category = Category::create(['name' => 'Makanan & Minuman', 'slug' => 'makanan-minuman']);

        $this->actingAs($user)->post(route('seller.products.store'), [
            'name' => 'Teh Daun Lokal',
            'category_id' => $category->id,
            'description' => 'Teh lokal pilihan.',
            'price' => 45000,
            'stock' => 8,
            'image' => UploadedFile::fake()->image('teh.jpg'),
        ])->assertRedirect(route('seller.products.index'));

        $product = Product::withoutGlobalScope('marketplace_approved_store')->where('name', 'Teh Daun Lokal')->firstOrFail();
        $this->assertSame($store->id, $product->store_id);
        $this->assertSame($store->store_name, $product->seller);
        Storage::disk('public')->assertExists($product->getRawOriginal('image'));
        $this->assertDatabaseHas('products', ['id' => $product->id, 'store_id' => $store->id]);
        $this->get(route('seller.products.index'))->assertOk()->assertSee('Teh Daun Lokal');
        $this->get(route('products'))->assertOk()->assertSee('Teh Daun Lokal');

        $storedImage = $product->getRawOriginal('image');
        $this->put(route('seller.products.update', $product), [
            'name' => 'Teh Daun Lokal Premium',
            'category_id' => $category->id,
            'description' => 'Kemasan baru.',
            'price' => 52000,
            'stock' => 6,
        ])->assertRedirect(route('seller.products.index'));
        $this->assertDatabaseHas('products', [
            'id' => $product->id,
            'name' => 'Teh Daun Lokal Premium',
            'store_id' => $store->id,
            'image' => $storedImage,
        ]);

        $this->delete(route('seller.products.destroy', $product))->assertRedirect(route('seller.products.index'));
        $this->assertDatabaseMissing('products', ['id' => $product->id]);
        Storage::disk('public')->assertMissing($storedImage);
    }

    public function test_seller_cannot_edit_or_delete_another_stores_product(): void
    {
        $owner = User::factory()->create();
        $otherUser = User::factory()->create();
        $store = $this->makeStore($owner, 'Toko Pemilik');
        $otherStore = $this->makeStore($otherUser, 'Toko Lain');
        $category = Category::create(['name' => 'Fashion', 'slug' => 'fashion']);
        $product = $otherStore->products()->create([
            'category_id' => $category->id,
            'name' => 'Kain Toko Lain',
            'slug' => 'kain-toko-lain',
            'seller' => $otherStore->store_name,
            'location' => 'Banda Aceh',
            'price' => 80000,
            'stock' => 3,
            'image' => 'https://example.test/kain.jpg',
        ]);

        $this->actingAs($owner)->get(route('seller.products.edit', $product))->assertNotFound();
        $this->actingAs($owner)->put(route('seller.products.update', $product), [
            'name' => 'Diubah', 'category_id' => $category->id, 'price' => 10, 'stock' => 1,
        ])->assertNotFound();
        $this->actingAs($owner)->delete(route('seller.products.destroy', $product))->assertNotFound();
        $this->assertDatabaseHas('products', ['id' => $product->id, 'store_id' => $otherStore->id]);
        $this->assertDatabaseHas('stores', ['id' => $store->id, 'user_id' => $owner->id]);
    }

    public function test_pending_store_owner_can_manage_products_hidden_from_public_marketplace(): void
    {
        $user = User::factory()->create();
        $store = $this->makeStore($user, 'Toko Menunggu', 'pending');
        $category = Category::create(['name' => 'Fashion', 'slug' => 'fashion']);
        $product = $store->products()->create([
            'category_id' => $category->id,
            'name' => 'Kain Menunggu',
            'slug' => 'kain-menunggu',
            'seller' => $store->store_name,
            'location' => 'Banda Aceh',
            'price' => 80000,
            'stock' => 3,
            'image' => 'https://example.test/kain.jpg',
        ]);

        $this->actingAs($user)->get(route('seller.products.index'))->assertOk()->assertSee('Kain Menunggu');
        $this->actingAs($user)->get(route('seller.products.edit', $product))->assertOk()->assertSee('Edit Produk');
        $this->get(route('products'))->assertOk()->assertDontSee('Kain Menunggu');
        $this->get(route('shop.show', $store->slug))->assertNotFound();
    }

    public function test_dashboard_totals_use_the_current_stores_products_and_orders(): void
    {
        $user = User::factory()->create();
        $otherUser = User::factory()->create();
        $store = $this->makeStore($user, 'Toko Angka Nyata');
        $otherStore = $this->makeStore($otherUser, 'Toko Lain');
        $category = Category::create(['name' => 'Kerajinan', 'slug' => 'kerajinan']);
        $product = $store->products()->create([
            'category_id' => $category->id, 'name' => 'Keranjang Anyam', 'slug' => 'keranjang-anyam',
            'seller' => $store->store_name, 'location' => 'Banda Aceh', 'price' => 20000,
            'stock' => 4, 'image' => 'https://example.test/anyam.jpg',
        ]);
        $otherProduct = $otherStore->products()->create([
            'category_id' => $category->id, 'name' => 'Produk Tetangga', 'slug' => 'produk-tetangga',
            'seller' => $otherStore->store_name, 'location' => 'Medan', 'price' => 50000,
            'stock' => 90, 'image' => 'https://example.test/neighbor.jpg',
        ]);
        $order = $user->orders()->create([
            'order_number' => 'NM-SELLER-001', 'status' => 'awaiting_confirmation', 'subtotal' => 60000,
            'shipping_cost' => null, 'shipping_address' => 'Alamat pembeli', 'contact_phone' => '081200000001',
        ]);
        $order->items()->create([
            'product_id' => $product->id, 'product_name' => $product->name, 'seller' => $store->store_name,
            'image' => $product->getRawOriginal('image'), 'quantity' => 3, 'price' => 20000,
        ]);

        $this->actingAs($user)->get(route('seller.dashboard'))
            ->assertOk()
            ->assertSee('Toko Angka Nyata')
            ->assertSee('Keranjang Anyam')
            ->assertSee('Rp 60.000')
            ->assertSee('NM-SELLER-001')
            ->assertDontSee('Produk Tetangga');

        $this->actingAs($user)->get(route('seller.orders'))
            ->assertOk()
            ->assertSee('NM-SELLER-001')
            ->assertSee('Keranjang Anyam')
            ->assertSee('Setujui');
    }

    public function test_each_store_handles_its_items_until_buyer_confirms_delivery(): void
    {
        $firstOwner = User::factory()->create();
        $secondOwner = User::factory()->create();
        $firstStore = $this->makeStore($firstOwner, 'Toko Pertama');
        $secondStore = $this->makeStore($secondOwner, 'Toko Kedua');
        $buyer = User::factory()->create();
        $category = Category::create(['name' => 'Kerajinan', 'slug' => 'kerajinan']);
        $firstProduct = $firstStore->products()->create([
            'category_id' => $category->id,
            'name' => 'Tas Anyam',
            'slug' => 'tas-anyam',
            'seller' => $firstStore->store_name,
            'location' => 'Banda Aceh',
            'price' => 20000,
            'stock' => 5,
            'image' => 'https://example.test/tas-anyam.jpg',
        ]);
        $secondProduct = $secondStore->products()->create([
            'category_id' => $category->id,
            'name' => 'Dompet Tenun',
            'slug' => 'dompet-tenun',
            'seller' => $secondStore->store_name,
            'location' => 'Medan',
            'price' => 30000,
            'stock' => 5,
            'image' => 'https://example.test/dompet-tenun.jpg',
        ]);
        $order = $buyer->orders()->create([
            'order_number' => 'NM-MULTISTORE-001',
            'status' => 'awaiting_confirmation',
            'subtotal' => 50000,
            'shipping_cost' => null,
            'shipping_address' => 'Alamat pembeli',
            'contact_phone' => '081234567890',
        ]);
        $firstItem = $order->items()->create([
            'product_id' => $firstProduct->id,
            'product_name' => $firstProduct->name,
            'seller' => $firstStore->store_name,
            'quantity' => 1,
            'price' => 20000,
        ]);
        $secondItem = $order->items()->create([
            'product_id' => $secondProduct->id,
            'product_name' => $secondProduct->name,
            'seller' => $secondStore->store_name,
            'quantity' => 1,
            'price' => 30000,
        ]);

        $this->actingAs($firstOwner)->post(route('seller.orders.approve', $order))
            ->assertRedirect(route('seller.orders'))
            ->assertSessionHas('success');

        $this->assertDatabaseHas('order_items', ['id' => $firstItem->id, 'seller_status' => 'accepted']);
        $this->assertDatabaseHas('order_items', ['id' => $secondItem->id, 'seller_status' => 'pending']);
        $this->assertDatabaseHas('orders', ['id' => $order->id, 'status' => 'awaiting_confirmation']);

        $this->actingAs($secondOwner)->post(route('seller.orders.approve', $order))
            ->assertRedirect(route('seller.orders'))
            ->assertSessionHas('success');

        $this->assertDatabaseHas('order_items', ['id' => $secondItem->id, 'seller_status' => 'accepted']);
        $this->assertDatabaseHas('orders', ['id' => $order->id, 'status' => 'processing']);

        $this->actingAs($buyer)->get(route('orders.show', $order))
            ->assertOk()
            ->assertSee('Sedang diproses')
            ->assertSee('Pesanan disetujui toko');
        $this->actingAs($buyer)->post(route('orders.confirm-receipt', $order))->assertUnprocessable();
        $this->actingAs(User::factory()->create())
            ->post(route('orders.confirm-receipt', $order))
            ->assertNotFound();

        $this->actingAs($firstOwner)->post(route('seller.orders.ship', $order))
            ->assertRedirect(route('seller.orders'))
            ->assertSessionHas('success');
        $this->assertDatabaseHas('orders', ['id' => $order->id, 'status' => 'processing']);
        $this->assertDatabaseHas('order_items', ['id' => $firstItem->id, 'seller_status' => 'shipped']);
        $this->assertDatabaseHas('order_items', ['id' => $secondItem->id, 'seller_status' => 'accepted']);

        $this->actingAs($secondOwner)->post(route('seller.orders.ship', $order))
            ->assertRedirect(route('seller.orders'))
            ->assertSessionHas('success');
        $this->assertDatabaseHas('orders', ['id' => $order->id, 'status' => 'shipped']);

        $this->actingAs($buyer)->get(route('orders.show', $order))
            ->assertOk()
            ->assertSee('Dalam pengiriman')
            ->assertSee('Konfirmasi barang diterima');
        $this->actingAs($buyer)->post(route('orders.confirm-receipt', $order))
            ->assertRedirect(route('orders.show', $order))
            ->assertSessionHas('success');
        $this->assertDatabaseHas('orders', ['id' => $order->id, 'status' => 'completed']);
        $this->assertDatabaseHas('order_items', ['id' => $firstItem->id, 'seller_status' => 'completed']);
        $this->assertDatabaseHas('order_items', ['id' => $secondItem->id, 'seller_status' => 'completed']);

        $this->actingAs($buyer)->get(route('orders.show', $order))
            ->assertOk()
            ->assertSee('Selesai')
            ->assertSee('Pesanan diterima');
    }

    public function test_store_cannot_approve_an_order_without_its_products(): void
    {
        $owner = User::factory()->create();
        $otherOwner = User::factory()->create();
        $store = $this->makeStore($owner, 'Toko Saya');
        $otherStore = $this->makeStore($otherOwner, 'Toko Orang');
        $category = Category::create(['name' => 'Kerajinan', 'slug' => 'kerajinan']);
        $product = $otherStore->products()->create([
            'category_id' => $category->id,
            'name' => 'Produk Toko Orang',
            'slug' => 'produk-toko-orang',
            'seller' => $otherStore->store_name,
            'location' => 'Medan',
            'price' => 30000,
            'stock' => 5,
            'image' => 'https://example.test/produk-toko-orang.jpg',
        ]);
        $order = User::factory()->create()->orders()->create([
            'order_number' => 'NM-OTHER-STORE-001',
            'status' => 'awaiting_confirmation',
            'subtotal' => 30000,
            'shipping_cost' => null,
            'shipping_address' => 'Alamat pembeli',
            'contact_phone' => '081234567890',
        ]);
        $item = $order->items()->create([
            'product_id' => $product->id,
            'product_name' => $product->name,
            'seller' => $otherStore->store_name,
            'quantity' => 1,
            'price' => 30000,
        ]);

        $this->actingAs($owner)->post(route('seller.orders.approve', $order))->assertNotFound();
        $this->actingAs($owner)->post(route('seller.orders.ship', $order))->assertNotFound();
        $this->assertDatabaseHas('order_items', ['id' => $item->id, 'seller_status' => 'pending']);
        $this->assertSame($store->id, $owner->store->id);
    }

    public function test_public_store_lists_approved_products_and_hides_unapproved_stores(): void
    {
        $approvedOwner = User::factory()->create();
        $pendingOwner = User::factory()->create();
        $approved = $this->makeStore($approvedOwner, 'Toko Publik');
        $pending = $this->makeStore($pendingOwner, 'Toko Menunggu', 'pending');
        $category = Category::create(['name' => 'Rumah Tangga', 'slug' => 'rumah-tangga']);
        $approved->products()->create([
            'category_id' => $category->id, 'name' => 'Mangkuk Lokal', 'slug' => 'mangkuk-lokal',
            'seller' => $approved->store_name, 'location' => 'Banda Aceh', 'price' => 35000,
            'stock' => 2, 'image' => 'https://example.test/mangkuk.jpg',
        ]);
        $pending->products()->create([
            'category_id' => $category->id, 'name' => 'Produk Belum Disetujui', 'slug' => 'produk-belum-disetujui',
            'seller' => $pending->store_name, 'location' => 'Medan', 'price' => 25000,
            'stock' => 2, 'image' => 'https://example.test/pending.jpg',
        ]);

        $this->get(route('shop.show', $approved->slug))->assertOk()->assertSee('Toko Publik')->assertSee('Mangkuk Lokal');
        $this->get(route('shop.show', $pending->slug))->assertNotFound();
        $this->get(route('products'))->assertOk()->assertSee('Mangkuk Lokal')->assertDontSee('Produk Belum Disetujui');
    }

    private function makeStore(User $user, string $name, string $status = 'approved'): Store
    {
        return Store::create([
            'user_id' => $user->id,
            'store_name' => $name,
            'slug' => str($name)->slug(),
            'category' => 'Kerajinan Lokal',
            'phone' => '081234567890',
            'address' => 'Banda Aceh',
            'status' => $status,
        ]);
    }
}
