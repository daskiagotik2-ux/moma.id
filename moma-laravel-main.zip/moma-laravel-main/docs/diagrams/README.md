# Diagram Sistem MoMa.id

Diagram dibuat dari migrasi database, model, route, dan alur yang tersedia pada aplikasi.

- [ERD (SVG)](./erd.svg) — struktur tabel dan relasi database.
- [UML Class Diagram (SVG)](./uml.svg) — kelas model domain dan relasinya.
- [DFD Level 0 (SVG)](./dfd-level-0.svg) — proses internal serta data store.
- [DFD Konteks (SVG)](./dfd-konteks.svg) — batas sistem dan entitas eksternal.
- [Keterangan DFD Level 0](../DFD-Level-0.md) dan [keterangan DFD Konteks](../DFD-Konteks.md).

SVG adalah format gambar vektor; dapat dibuka di browser, dimasukkan ke dokumen, dan diperbesar tanpa pecah.
