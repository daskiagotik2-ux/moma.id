# DFD Diagram Konteks MoMa.id

Diagram konteks memperlihatkan MoMa.id sebagai satu proses serta pertukaran data dengan pengunjung, pembeli, penjual, dan calon penjual.

![DFD Diagram Konteks MoMa.id](./diagrams/dfd-konteks.svg)

## Alur Data

- **Pengunjung:** meminta katalog, pencarian, dan filter; sistem mengembalikan daftar produk, kategori, promo, dan detail produk.
- **Pembeli:** mengirim data akun, keranjang, wishlist, dan checkout; sistem mengembalikan status akun, pesanan, dan pembayaran.
- **Penjual:** mengirim data toko dan produk, mengelola pesanan, serta memeriksa bukti pembayaran; sistem menyediakan hasil verifikasi dan status pesanan.
- **Calon penjual:** mengirim pengajuan toko; sistem mengembalikan konfirmasi pengajuan serta status/data toko.

Pembayaran berlangsung manual (COD, transfer, atau QRIS) dan diverifikasi oleh toko terkait. Diagram ini tidak menunjukkan integrasi payment gateway eksternal atau proses admin yang tidak tersedia pada alur aplikasi aktif. Rincian proses internal tersedia pada [DFD Level 0](./DFD-Level-0.md).
