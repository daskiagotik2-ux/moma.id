# DFD Level 0 MoMa.id

Diagram ini merinci proses internal marketplace dan data store utama. Versi SVG di bawah mengikuti alur yang tersedia pada aplikasi saat ini.

![DFD Level 0 MoMa.id](./diagrams/dfd-level-0.svg)

## Proses Utama

1. **Telusuri katalog:** pencarian, filter, kategori, dan detail produk.
2. **Kelola akun dan profil:** registrasi, login, dan perubahan profil.
3. **Kelola keranjang dan wishlist:** keranjang disimpan pada session, sedangkan wishlist disimpan di database.
4. **Checkout dan buat pesanan:** memvalidasi checkout dan menyimpan pesanan beserta itemnya.
5. **Verifikasi pembayaran:** memproses bukti pembayaran dan persetujuan toko terkait.
6. **Kelola toko dan produk:** mengelola data toko serta katalog produk.
7. **Proses pengiriman pesanan:** penjual menyetujui dan mengirim item tokonya; pembeli mengonfirmasi penerimaan setelah seluruh item dikirim.

Data store diagram meliputi pengguna/toko, katalog, pesanan/item, pembayaran/persetujuan, wishlist, dan data promosi. Keranjang tidak memiliki tabel permanen karena disimpan pada session aplikasi. Pembayaran manual (COD/transfer/QRIS), tanpa gateway eksternal aktif. Diagram konteks tersedia di [DFD-Konteks.md](./DFD-Konteks.md).
