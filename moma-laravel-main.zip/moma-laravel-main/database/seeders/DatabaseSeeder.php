<?php

namespace Database\Seeders;

use App\Models\Category;
use App\Models\Product;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $categories = [
            ['name'=>'Makanan & Minuman','slug'=>'makanan-minuman','icon'=>'🍲','sort_order'=>1],
            ['name'=>'Fashion','slug'=>'fashion','icon'=>'👗','sort_order'=>2],
            ['name'=>'Kerajinan Tangan','slug'=>'kerajinan-tangan','icon'=>'👜','sort_order'=>3],
            ['name'=>'Kecantikan & Perawatan','slug'=>'kecantikan-perawatan','icon'=>'🧴','sort_order'=>4],
            ['name'=>'Elektronik','slug'=>'elektronik','icon'=>'🎧','sort_order'=>5],
            ['name'=>'Rumah & Dapur','slug'=>'rumah-dapur','icon'=>'🍳','sort_order'=>6],
            ['name'=>'Olahraga & Hobi','slug'=>'olahraga-hobi','icon'=>'👟','sort_order'=>7],
            ['name'=>'Buku & Alat Tulis','slug'=>'buku-alat-tulis','icon'=>'📚','sort_order'=>8],
            ['name'=>'Otomotif','slug'=>'otomotif','icon'=>'🚗','sort_order'=>9],
            ['name'=>'Lainnya','slug'=>'lainnya','icon'=>'▦','sort_order'=>10],
        ];

        foreach ($categories as $category) {
            Category::create($category);
        }

        $ids = Category::pluck('id','slug');

        $products = [
            ['category_id'=>$ids['makanan-minuman'],'name'=>'Kopi Gayo Arabica','slug'=>'kopi-gayo-arabica','description'=>'Kopi Gayo pilihan dengan aroma khas Aceh.','seller'=>'Dapur Bunda Aceh','location'=>'Banda Aceh','price'=>45000,'old_price'=>60000,'discount_percent'=>25,'rating'=>4.9,'review_count'=>1200,'image'=>'https://images.unsplash.com/photo-1447933601403-0c6688de566e?auto=format&fit=crop&w=900&q=85','is_featured'=>true],
            ['category_id'=>$ids['fashion'],'name'=>'Tenun Aceh','slug'=>'tenun-aceh','description'=>'Tenun dengan motif tradisional khas Aceh.','seller'=>'Tenun Aceh Official','location'=>'Pidie','price'=>120000,'old_price'=>150000,'discount_percent'=>20,'rating'=>4.8,'review_count'=>892,'image'=>'https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?auto=format&fit=crop&w=900&q=85','is_featured'=>true],
            ['category_id'=>$ids['makanan-minuman'],'name'=>'Kue Timphan','slug'=>'kue-timphan','description'=>'Kue khas Aceh, isi 10 dengan rasa autentik.','seller'=>'Dapur Bunda Aceh','location'=>'Banda Aceh','price'=>35000,'old_price'=>50000,'discount_percent'=>30,'rating'=>4.9,'review_count'=>1500,'image'=>'https://images.unsplash.com/photo-1519869325930-281384150729?auto=format&fit=crop&w=900&q=85','is_featured'=>true],
            ['category_id'=>$ids['kerajinan-tangan'],'name'=>'Tas Rajut Handmade','slug'=>'tas-rajut-handmade','description'=>'Tas rajut handmade edisi terbatas.','seller'=>'Kriya Nusantara','location'=>'Aceh Besar','price'=>28000,'old_price'=>40000,'discount_percent'=>30,'rating'=>4.7,'review_count'=>640,'image'=>'https://images.unsplash.com/photo-1594223274512-ad4803739b7c?auto=format&fit=crop&w=900&q=85','is_featured'=>true],
            ['category_id'=>$ids['makanan-minuman'],'name'=>'Keripik Ubi Ungu','slug'=>'keripik-ubi-ungu','description'=>'Camilan renyah dan sehat dari bahan lokal.','seller'=>'Rasa Daerah','location'=>'Aceh','price'=>20000,'old_price'=>40000,'discount_percent'=>50,'rating'=>4.7,'review_count'=>520,'image'=>'https://images.unsplash.com/photo-1621939514649-280e2aaad09a?auto=format&fit=crop&w=900&q=85','is_featured'=>true],
            ['category_id'=>$ids['kecantikan-perawatan'],'name'=>'Body Care Herbal Aceh','slug'=>'body-care-herbal-aceh','description'=>'Perawatan tubuh berbahan herbal lokal.','seller'=>'Aceh Beauty','location'=>'Banda Aceh','price'=>65000,'old_price'=>80000,'discount_percent'=>19,'rating'=>4.8,'review_count'=>340,'image'=>'https://images.unsplash.com/photo-1556229010-6c3f2c9ca5f8?auto=format&fit=crop&w=900&q=85','is_featured'=>false],
            ['category_id'=>$ids['rumah-dapur'],'name'=>'Panci Keramik Lokal','slug'=>'panci-keramik-lokal','description'=>'Peralatan dapur dengan desain modern.','seller'=>'Rumah Aceh','location'=>'Aceh Besar','price'=>185000,'old_price'=>220000,'discount_percent'=>16,'rating'=>4.8,'review_count'=>210,'image'=>'https://images.unsplash.com/photo-1584990347449-ae3c0dff6f2d?auto=format&fit=crop&w=900&q=85','is_featured'=>false],
            ['category_id'=>$ids['olahraga-hobi'],'name'=>'Sepatu Lokal Nusantara','slug'=>'sepatu-lokal-nusantara','description'=>'Sepatu nyaman untuk aktivitas harian.','seller'=>'Nusa Sport','location'=>'Medan','price'=>175000,'old_price'=>210000,'discount_percent'=>17,'rating'=>4.7,'review_count'=>410,'image'=>'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=900&q=85','is_featured'=>false],
        ];

        foreach ($products as $product) {
            Product::create($product);
        }

        $this->call(VoucherSeeder::class);
    }
}