<?php

namespace Database\Seeders;

use App\Models\Voucher;
use Illuminate\Database\Seeder;

class VoucherSeeder extends Seeder
{
    public function run(): void
    {
        $vouchers = [
            ['code' => 'MOMA25', 'type' => 'discount', 'amount' => 25000, 'min_spend' => 100000],
            ['code' => 'MOMA15', 'type' => 'shipping', 'amount' => 15000, 'min_spend' => 75000],
            ['code' => 'MOMA5', 'type' => 'cashback', 'amount' => 5, 'min_spend' => 200000],
            ['code' => 'MOMA40', 'type' => 'discount', 'amount' => 40000, 'min_spend' => 250000],
            ['code' => 'ONGKIR10', 'type' => 'shipping', 'amount' => 10000, 'min_spend' => 50000],
            ['code' => 'ONGKIR20', 'type' => 'shipping', 'amount' => 20000, 'min_spend' => 100000],
            ['code' => 'ONGKIR30', 'type' => 'shipping', 'amount' => 30000, 'min_spend' => 150000],
        ];

        foreach ($vouchers as $voucher) {
            Voucher::firstOrCreate(
                ['code' => $voucher['code']],
                [...$voucher, 'is_active' => true, 'starts_at' => now()->startOfDay(), 'ends_at' => now()->endOfYear()],
            );
        }
    }
}
