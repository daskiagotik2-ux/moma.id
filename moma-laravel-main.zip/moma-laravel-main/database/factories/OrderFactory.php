<?php

namespace Database\Factories;

use App\Enums\PaymentMethod;
use App\Enums\PaymentStatus;
use App\Models\Order;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<Order>
 */
class OrderFactory extends Factory
{
    protected $model = Order::class;

    public function definition(): array
    {
        return [
            'user_id' => User::factory(),
            'order_number' => 'NM-'.fake()->unique()->bothify('##########'),
            'status' => 'awaiting_confirmation',
            'subtotal' => 100000,
            'shipping_cost' => 15000,
            'shipping_address' => fake()->address(),
            'contact_phone' => fake()->numerify('08##########'),
            'payment_method' => PaymentMethod::Cod,
            'payment_status' => PaymentStatus::Unpaid,
            'grand_total' => 115000,
        ];
    }

    public function bankTransfer(): static
    {
        return $this->manualPayment(PaymentMethod::BankTransfer);
    }

    public function cod(): static
    {
        return $this->state([
            'status' => 'awaiting_confirmation',
            'payment_method' => PaymentMethod::Cod,
            'payment_status' => PaymentStatus::Unpaid,
            'payment_expires_at' => null,
            'paid_at' => null,
        ]);
    }

    public function qris(): static
    {
        return $this->manualPayment(PaymentMethod::Qris);
    }

    public function paid(): static
    {
        return $this->state([
            'status' => 'awaiting_confirmation',
            'payment_method' => PaymentMethod::BankTransfer,
            'payment_status' => PaymentStatus::Paid,
            'payment_expires_at' => now()->addHours(config('payment.expiration_hours', 24)),
            'paid_at' => now(),
        ]);
    }

    public function waitingVerification(): static
    {
        return $this->state([
            'status' => 'awaiting_payment',
            'payment_method' => PaymentMethod::BankTransfer,
            'payment_status' => PaymentStatus::WaitingVerification,
            'payment_expires_at' => now()->addHours(config('payment.expiration_hours', 24)),
        ]);
    }

    public function failed(): static
    {
        return $this->state([
            'status' => 'awaiting_payment',
            'payment_method' => PaymentMethod::BankTransfer,
            'payment_status' => PaymentStatus::Failed,
            'payment_expires_at' => now()->addHours(config('payment.expiration_hours', 24)),
        ]);
    }

    public function unpaid(): static
    {
        return $this->state([
            'payment_status' => PaymentStatus::Unpaid,
            'paid_at' => null,
        ]);
    }

    public function expired(): static
    {
        return $this->state([
            'status' => 'cancelled',
            'payment_method' => PaymentMethod::BankTransfer,
            'payment_status' => PaymentStatus::Expired,
            'payment_expires_at' => now()->subMinute(),
        ]);
    }

    public function refunded(): static
    {
        return $this->state([
            'status' => 'cancelled',
            'payment_method' => PaymentMethod::BankTransfer,
            'payment_status' => PaymentStatus::Refunded,
        ]);
    }

    private function manualPayment(PaymentMethod $method): static
    {
        return $this->state([
            'status' => 'awaiting_payment',
            'payment_method' => $method,
            'payment_status' => PaymentStatus::Unpaid,
            'payment_expires_at' => now()->addHours(config('payment.expiration_hours', 24)),
        ]);
    }
}
