<?php

namespace Database\Factories;

use App\Enums\PaymentMethod;
use App\Enums\PaymentRecordStatus;
use App\Models\Order;
use App\Models\Payment;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<Payment>
 */
class PaymentFactory extends Factory
{
    protected $model = Payment::class;

    public function definition(): array
    {
        return [
            'order_id' => Order::factory()->bankTransfer(),
            'method' => PaymentMethod::BankTransfer,
            'amount' => 115000,
            'status' => PaymentRecordStatus::Pending,
            'reference' => null,
            'verified_by' => null,
            'verified_at' => null,
            'note' => null,
        ];
    }

    public function verified(): static
    {
        return $this->state([
            'status' => PaymentRecordStatus::Verified,
            'verified_at' => now(),
        ]);
    }

    public function qris(): static
    {
        return $this->state([
            'method' => PaymentMethod::Qris,
        ]);
    }

    public function rejected(): static
    {
        return $this->state([
            'status' => PaymentRecordStatus::Rejected,
            'verified_at' => now(),
            'note' => 'Bukti pembayaran tidak jelas.',
        ]);
    }
}
