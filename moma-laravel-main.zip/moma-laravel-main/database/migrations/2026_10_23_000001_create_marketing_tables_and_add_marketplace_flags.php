<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('banners')) {
            Schema::create('banners', function (Blueprint $table) {
                $table->id();
                $table->string('title');
                $table->text('subtitle')->nullable();
                $table->text('image')->nullable();
                $table->string('link_url')->nullable();
                $table->enum('position', ['hero', 'side'])->default('hero');
                $table->unsignedInteger('sort_order')->default(0);
                $table->boolean('is_active')->default(true);
                $table->timestamp('starts_at')->nullable();
                $table->timestamp('ends_at')->nullable();
                $table->timestamps();
            });
        }

        if (! Schema::hasTable('flash_sales')) {
            Schema::create('flash_sales', function (Blueprint $table) {
                $table->id();
                $table->string('title');
                $table->dateTime('starts_at');
                $table->dateTime('ends_at');
                $table->boolean('is_active')->default(true);
                $table->timestamps();
            });
        }

        if (! Schema::hasTable('flash_sale_items')) {
            Schema::create('flash_sale_items', function (Blueprint $table) {
                $table->id();
                $table->foreignId('flash_sale_id')->constrained()->cascadeOnDelete();
                $table->foreignId('product_id')->constrained()->cascadeOnDelete();
                $table->unsignedBigInteger('sale_price');
                $table->unsignedInteger('stock_limit');
                $table->unsignedInteger('sold_count')->default(0);
                $table->timestamps();

                $table->unique(['flash_sale_id', 'product_id']);
            });
        }

        if (! Schema::hasTable('vouchers')) {
            Schema::create('vouchers', function (Blueprint $table) {
                $table->id();
                $table->string('code')->unique();
                $table->enum('type', ['discount', 'shipping', 'cashback']);
                $table->unsignedBigInteger('amount');
                $table->unsignedBigInteger('min_spend')->default(0);
                $table->unsignedBigInteger('max_discount')->nullable();
                $table->unsignedInteger('quota')->nullable();
                $table->unsignedInteger('used_count')->default(0);
                $table->timestamp('starts_at')->nullable();
                $table->timestamp('ends_at')->nullable();
                $table->boolean('is_active')->default(true);
                $table->timestamps();
            });
        }

        if (! Schema::hasColumn('stores', 'is_official') || ! Schema::hasColumn('stores', 'is_featured')) {
            Schema::table('stores', function (Blueprint $table) {
                if (! Schema::hasColumn('stores', 'is_official')) {
                    $table->boolean('is_official')->default(false);
                }

                if (! Schema::hasColumn('stores', 'is_featured')) {
                    $table->boolean('is_featured')->default(false);
                }
            });
        }

        if (! Schema::hasColumn('orders', 'voucher_code') || ! Schema::hasColumn('orders', 'discount_amount')) {
            Schema::table('orders', function (Blueprint $table) {
                if (! Schema::hasColumn('orders', 'voucher_code')) {
                    $table->string('voucher_code')->nullable();
                }

                if (! Schema::hasColumn('orders', 'discount_amount')) {
                    $table->unsignedBigInteger('discount_amount')->default(0);
                }
            });
        }
    }

    public function down(): void
    {
        Schema::table('orders', function (Blueprint $table) {
            $table->dropColumn(['voucher_code', 'discount_amount']);
        });

        Schema::table('stores', function (Blueprint $table) {
            $table->dropColumn(['is_official', 'is_featured']);
        });

        Schema::dropIfExists('vouchers');
        Schema::dropIfExists('flash_sale_items');
        Schema::dropIfExists('flash_sales');
        Schema::dropIfExists('banners');
    }
};
