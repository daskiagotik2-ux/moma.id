<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
   
public function up(): void
{
    Schema::create('stores', function (Blueprint $table) {
        $table->id();

        // Menghubungkan toko dengan akun pengguna
        $table->foreignId('user_id')
            ->unique()
            ->constrained('users')
            ->cascadeOnDelete();

        $table->string('store_name');
        $table->string('slug')->unique();
        $table->text('description')->nullable();
        $table->string('category');
        $table->string('phone', 25);
        $table->text('address');

        // Toko harus menunggu persetujuan admin
        $table->string('status')->default('pending');
        $table->text('admin_note')->nullable();

        $table->timestamps();
    });
}
    public function down(): void
    {
        Schema::dropIfExists('stores');
    }
};