<?php

use App\Http\Controllers\BuyerController;
use App\Http\Controllers\FashionController;
use App\Http\Controllers\FlashSaleController;
use App\Http\Controllers\GratisOngkirController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\KerajinanController;
use App\Http\Controllers\MakananLokalController;
use App\Http\Controllers\MomaMallController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\PaymentController;
use App\Http\Controllers\ProdukTerlarisController;
use App\Http\Controllers\PublicStoreController;
use App\Http\Controllers\SellerController;
use App\Http\Controllers\SellerProductController;
use App\Http\Controllers\StoreController;
use App\Http\Controllers\TokoPilihanController;
use App\Http\Controllers\VoucherController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;


/*
|--------------------------------------------------------------------------
| Marketplace Routes — NusantaraMart
|--------------------------------------------------------------------------
*/

// Public
Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('/produk', [HomeController::class, 'products'])->name('products');
Route::get('/produk/{product:slug}', [HomeController::class, 'showProduct'])->name('products.show');
Route::get('/kategori', [HomeController::class, 'categories'])->name('kategori');
Route::get('/kategori-placeholder/{category}', [HomeController::class, 'categoryPlaceholder'])->name('kategori.placeholder');
Route::get('/keranjang', [BuyerController::class, 'cart'])->name('cart.index');
Route::post('/keranjang/{product:slug}', [BuyerController::class, 'addToCart'])->name('cart.add');
Route::patch('/keranjang/{product:slug}', [BuyerController::class, 'updateCart'])->name('cart.update');
Route::delete('/keranjang/{product:slug}', [BuyerController::class, 'removeFromCart'])->name('cart.remove');
Route::middleware('auth')->group(function () {
    Route::get('/checkout', [BuyerController::class, 'checkout'])->name('checkout.create');
    Route::post('/checkout', [BuyerController::class, 'placeOrder'])->name('checkout.store');
    Route::get('/pesanan/{order}/bayar', [PaymentController::class, 'show'])->name('orders.pay');
    Route::post('/pesanan/{order}/bayar', [PaymentController::class, 'uploadProof'])->name('orders.payments.upload');
    Route::post('/pesanan/{order}/konfirmasi-diterima', [BuyerController::class, 'confirmReceipt'])->name('orders.confirm-receipt');
    Route::get('/pembayaran/{payment}/bukti', [PaymentController::class, 'proof'])->name('payments.proof');
    Route::delete('/voucher/pilihan', [VoucherController::class, 'clear'])->name('voucher.clear');
    Route::get('/pesanan', [BuyerController::class, 'orders'])->name('orders');
    Route::get('/pesanan/{order}', [BuyerController::class, 'showOrder'])->name('orders.show');
    Route::get('/wishlist', [BuyerController::class, 'wishlist'])->name('wishlist');
    Route::post('/wishlist/{product:slug}', [BuyerController::class, 'toggleWishlist'])->name('wishlist.toggle');
});
Route::get('/kategori/{category}', [HomeController::class, 'category'])->name('category');
Route::get('/promo', [HomeController::class, 'promo'])->name('promo');
Route::view('/bantuan', 'help')->name('help');
Route::get('/flash-sale', [FlashSaleController::class, 'index'])->name('flash-sale');
Route::get('/moma-mall', [MomaMallController::class, 'index'])->name('moma-mall');
Route::get('/makanan-lokal', [MakananLokalController::class, 'index'])->name('makanan-lokal');
Route::get('/fashion', [FashionController::class, 'index'])->name('fashion');
Route::get('/kerajinan', [KerajinanController::class, 'index'])->name('kerajinan');
Route::get('/gratis-ongkir', [GratisOngkirController::class, 'index'])->name('gratis-ongkir');
Route::get('/produk-terlaris', [ProdukTerlarisController::class, 'index'])->name('produk-terlaris');
Route::get('/voucher', [VoucherController::class, 'index'])->name('voucher');
Route::post('/voucher/gunakan', [VoucherController::class, 'claim'])->name('voucher.claim');
Route::get('/toko-pilihan', [TokoPilihanController::class, 'index'])->name('toko-pilihan');
Route::get('/toko', [TokoPilihanController::class, 'index'])->name('shop');

Route::middleware('seller.auth')->group(function () {
    Route::get('/toko/pengajuan', [StoreController::class, 'create'])->name('stores.create');
    Route::post('/toko/pengajuan', [StoreController::class, 'store'])->name('stores.store');
    Route::put('/toko/pengajuan', [StoreController::class, 'update'])->name('stores.update');

    Route::prefix('seller')->name('seller.')->group(function () {
        Route::get('/', [SellerController::class, 'dashboard'])->name('dashboard');
        Route::middleware('seller.store')->group(function () {
            Route::get('/produk', [SellerProductController::class, 'index'])->name('products.index');
            Route::get('/produk/tambah', [SellerProductController::class, 'create'])->name('products.create');
            Route::post('/produk', [SellerProductController::class, 'store'])->name('products.store');
            Route::get('/produk/{product}/edit', [SellerProductController::class, 'edit'])->name('products.edit');
            Route::put('/produk/{product}', [SellerProductController::class, 'update'])->name('products.update');
            Route::delete('/produk/{product}', [SellerProductController::class, 'destroy'])->name('products.destroy');
            Route::get('/pesanan', [SellerController::class, 'orders'])->name('orders');
            Route::post('/pesanan/{order}/setujui', [SellerController::class, 'approveOrder'])->name('orders.approve');
            Route::post('/pesanan/{order}/kirim', [SellerController::class, 'shipOrder'])->name('orders.ship');
            Route::post('/pesanan/{order}/pembayaran/{payment}/verifikasi', [SellerController::class, 'verifyPayment'])->name('orders.payments.verify');
            Route::get('/statistik', [SellerController::class, 'statistics'])->name('statistics');
            Route::get('/pengaturan-toko', [SellerController::class, 'settings'])->name('settings');
        });
    });
});

Route::get('/toko/{store:slug}', [PublicStoreController::class, 'show'])->name('shop.show');

// Dashboard & Profile (Breeze)
Route::get('/dashboard', function (Request $request) {
    $user = $request->user();
    $orders = $user->orders();

    return view('dashboard', [
        'orderCount' => $user->orders()->count(),
        'orderStatusCounts' => [
            'unpaid' => (clone $orders)->where('status', 'awaiting_payment')->count(),
            'packed' => (clone $orders)->whereIn('status', ['awaiting_confirmation', 'processing'])->count(),
            'shipped' => (clone $orders)->where('status', 'shipped')->count(),
            'completed' => (clone $orders)->where('status', 'completed')->count(),
        ],
        'store' => $user->store,
    ]);
})->middleware(['auth'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';