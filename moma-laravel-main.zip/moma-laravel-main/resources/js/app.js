import './bootstrap';

import Alpine from 'alpinejs';

window.Alpine = Alpine;

Alpine.start();

const renderLucideIcons = () => window.lucide?.createIcons();

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', renderLucideIcons, { once: true });
} else {
    renderLucideIcons();
}

document.querySelectorAll('[data-voucher-claim]').forEach((form) => {
    form.addEventListener('submit', async (event) => {
        event.preventDefault();

        const button = form.querySelector('[data-copy-voucher]');
        const card = form.closest('.voucher-card, .gratis-voucher-card');
        const status = card.querySelector('.voucher-claim-status, .gratis-voucher-claim-status');
        const code = button.dataset.copyVoucher;
        button.disabled = true;
        status.textContent = 'Menyiapkan voucher...';

        try {
            const response = await fetch(form.action, {
                method: 'POST',
                body: new FormData(form),
                credentials: 'same-origin',
                headers: { Accept: 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
            });
            const result = await response.json();

            if (!response.ok) {
                const validationMessage = Object.values(result.errors || {}).flat()[0];
                throw new Error(validationMessage || result.message || 'Voucher tidak dapat disiapkan. Silakan coba lagi.');
            }

            let copied = false;

            try {
                await navigator.clipboard.writeText(code);
                copied = true;
            } catch {
                copied = false;
            }

            button.innerHTML = copied
                ? '<i class="fa-solid fa-check"></i> Disalin'
                : '<i class="fa-regular fa-copy"></i> Kode siap';
            button.classList.add('copied');
            status.textContent = copied
                ? 'Kode disalin dan disimpan untuk checkout.'
                : `Kode ${code} disimpan untuk checkout. Salin manual jika diperlukan.`;

            if (result.checkoutUrl) {
                window.location.assign(result.checkoutUrl);
            }
        } catch (error) {
            status.textContent = error.message;
        } finally {
            button.disabled = false;
        }
    });
});

document.querySelectorAll('[data-image-fallback]').forEach((image) => {
    const showFallback = () => {
        image.hidden = true;
        image.nextElementSibling.hidden = false;
    };

    if (image.complete && image.naturalWidth === 0) {
        showFallback();
    } else {
        image.addEventListener('error', showFallback, { once: true });
    }
});

const syncMobileSidebarScroll = () => {
    const mobileShells = document.querySelectorAll('.marketplace-sidebar-shell');

    const sync = (shell, sidebar) => {
        const isOpen = sidebar.classList.contains('marketplace-sidebar-open');
        const isMobile = window.innerWidth < 1024;
        const shouldLock = isMobile && isOpen;

        sidebar.setAttribute('aria-hidden', String(!isOpen));
        sidebar.toggleAttribute('inert', !isOpen);
        document.body.classList.toggle('moma-sidebar-open', shouldLock);
        document.body.style.overflow = shouldLock ? 'hidden' : '';

        const focusableSelector = 'a[href], button:not([disabled]), [tabindex]:not([tabindex="-1"])';
        const focusable = [...sidebar.querySelectorAll(focusableSelector)];

        if (isOpen) {
            const firstFocusable = focusable[0];
            if (firstFocusable && document.activeElement !== firstFocusable) {
                firstFocusable.focus({ preventScroll: true });
            }
        }

        if (!isOpen && document.activeElement && shell.contains(document.activeElement)) {
            const trigger = shell.querySelector('.marketplace-sidebar-trigger');
            trigger?.focus({ preventScroll: true });
        }
    };

    mobileShells.forEach((shell) => {
        const sidebar = shell.querySelector('.marketplace-sidebar');
        if (!sidebar) {
            return;
        }

        const observer = new MutationObserver(() => sync(shell, sidebar));
        observer.observe(sidebar, { attributes: true, attributeFilter: ['class'] });
        window.addEventListener('resize', () => sync(shell, sidebar), { passive: true });

        document.addEventListener('keydown', (event) => {
            if (event.key !== 'Escape' || !sidebar.classList.contains('marketplace-sidebar-open') || window.innerWidth >= 1024) {
                return;
            }

            sidebar.classList.remove('marketplace-sidebar-open');
            sync(shell, sidebar);
        }, { passive: false });

        sync(shell, sidebar);
    });
};

syncMobileSidebarScroll();

document.querySelectorAll('[data-payment-countdown]').forEach((timer) => {
    const deadline = new Date(timer.dataset.paymentCountdown).getTime();
    const updateCountdown = () => {
        const remaining = Math.max(0, deadline - Date.now());
        const hours = Math.floor(remaining / 3_600_000);
        const minutes = Math.floor((remaining % 3_600_000) / 60_000);
        const seconds = Math.floor((remaining % 60_000) / 1_000);
        timer.textContent = remaining === 0
            ? 'Batas waktu pembayaran telah berakhir.'
            : `Sisa waktu pembayaran: ${hours} jam ${minutes} menit ${seconds} detik`;
    };

    updateCountdown();
    window.setInterval(updateCountdown, 1000);
});

const loginForm = document.querySelector('[data-login-form]');

if (loginForm) {
    const passwordField = loginForm.querySelector('#password');
    const passwordToggle = loginForm.querySelector('[data-password-toggle]');
    const eyeIcon = passwordToggle.querySelector('[data-eye-icon]');
    const eyeOffIcon = passwordToggle.querySelector('[data-eye-off-icon]');
    const submitButton = loginForm.querySelector('[data-login-submit]');
    const submitLabel = loginForm.querySelector('[data-login-submit-label]');
    const spinner = loginForm.querySelector('[data-login-spinner]');

    passwordToggle.addEventListener('click', () => {
        const showPassword = passwordField.type === 'password';

        passwordField.type = showPassword ? 'text' : 'password';
        passwordToggle.setAttribute('aria-label', showPassword ? 'Sembunyikan kata sandi' : 'Tampilkan kata sandi');
        eyeIcon.hidden = showPassword;
        eyeOffIcon.hidden = !showPassword;
    });

    loginForm.addEventListener('submit', () => {
        if (!loginForm.reportValidity()) {
            return;
        }

        submitButton.disabled = true;
        submitButton.setAttribute('aria-busy', 'true');
        submitLabel.textContent = 'Memproses...';
        spinner.hidden = false;
    });
}

const shopIdentityForm = document.querySelector('#shop-identity-form');

if (shopIdentityForm) {
    const shopFields = [...shopIdentityForm.querySelectorAll('input, select, textarea')];
    const descriptionField = shopIdentityForm.querySelector('#shop-description');
    const characterCount = shopIdentityForm.querySelector('.shop-character-count');
    const previewName = document.querySelector('#preview-name');
    const previewCategory = document.querySelector('#preview-category');
    const previewDescription = document.querySelector('#preview-description');
    const previewLocation = document.querySelector('#preview-location');

    const updatePreview = () => {
        const shopName = shopIdentityForm.elements.shop_name.value.trim();
        const category = shopIdentityForm.elements.category.value;
        const location = shopIdentityForm.elements.location.value;
        const description = descriptionField.value.trim();

        previewName.textContent = shopName || 'Nama Toko Anda';
        previewCategory.textContent = category || 'Kategori Toko';
        previewLocation.textContent = location || 'Lokasi';
        previewDescription.textContent = description || 'Deskripsi toko Anda akan muncul di sini setelah disimpan.';
        characterCount.textContent = `${description.length} / 300 karakter`;
    };

    shopFields.forEach((field) => field.addEventListener('input', updatePreview));
    shopFields.forEach((field) => field.addEventListener('change', updatePreview));
    descriptionField.addEventListener('input', updatePreview);

    shopIdentityForm.addEventListener('submit', (event) => {
        event.preventDefault();

        let isValid = true;
        shopFields.forEach((field) => {
            const fieldContainer = field.closest('.shop-field');
            const valid = field.checkValidity();
            fieldContainer.classList.toggle('invalid', !valid);
            isValid = isValid && valid;
        });

        const status = shopIdentityForm.querySelector('.shop-form-status');

        if (!isValid) {
            status.textContent = 'Periksa kembali data toko yang Anda isi.';
            shopIdentityForm.querySelector(':invalid')?.focus();
            return;
        }

        status.textContent = 'Identitas toko berhasil disimpan.';
        updatePreview();
    });

    shopIdentityForm.addEventListener('reset', () => {
        shopFields.forEach((field) => field.closest('.shop-field').classList.remove('invalid'));
        shopIdentityForm.querySelector('.shop-form-status').textContent = '';
    });

    updatePreview();
}

const flashCountdown = document.querySelector('.flash-sale-countdown');

if (flashCountdown) {
    const deadline = Date.now() + 5 * 24 * 60 * 60 * 1000 + 23 * 60 * 60 * 1000 + 41 * 60 * 1000 + 12000;

    const updateCountdown = () => {
        const remaining = Math.max(0, deadline - Date.now());
        const days = Math.floor(remaining / 86400000);
        const hours = Math.floor((remaining % 86400000) / 3600000);
        const minutes = Math.floor((remaining % 3600000) / 60000);
        const seconds = Math.floor((remaining % 60000) / 1000);

        document.querySelector('#flash-days').textContent = String(days).padStart(2, '0');
        document.querySelector('#flash-hours').textContent = String(hours).padStart(2, '0');
        document.querySelector('#flash-minutes').textContent = String(minutes).padStart(2, '0');
        document.querySelector('#flash-seconds').textContent = String(seconds).padStart(2, '0');
    };

    updateCountdown();
    window.setInterval(updateCountdown, 1000);
}
