@extends('layouts.app')
@section('content')
<div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
    <h2 class="text-xl font-bold text-brand-700 mb-4">Promo & Voucher</h2>
    <p class="text-sm text-gray-600">Kumpulan voucher potongan harga dan promo menarik.</p>
</div>
@endsection