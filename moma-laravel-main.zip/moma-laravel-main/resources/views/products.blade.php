@extends('layouts.app')

@section('title', 'Katalog Produk | MoMa.id')

@section('content')
<div class="catalog-page">
    <nav class="catalog-breadcrumb" aria-label="Breadcrumb">
        <a href="{{ route('home') }}">Beranda</a>
        <i class="fa-solid fa-chevron-right"></i>
        <span>Katalog produk</span>
    </nav>

    <section class="catalog-hero">
        <div class="catalog-hero-copy">
            <span class="catalog-eyebrow"><i class="fa-solid fa-bag-shopping"></i> KATALOG MoMa.id</span>
            <h1>Temukan produk lokal pilihan</h1>
            <p>Jelajahi produk UMKM berdasarkan nama, kategori, atau kisaran harga.</p>
            <div class="catalog-hero-meta">
                <span><i class="fa-solid fa-box-open"></i> {{ number_format($products->total(), 0, ',', '.') }} produk ditemukan</span>
                <span><i class="fa-solid fa-layer-group"></i> {{ $categories->count() }} kategori</span>
            </div>
        </div>
        <div class="catalog-hero-panel">
            <small>Produk lokal</small>
            <strong>Belanja dari UMKM</strong>
            <p>Gunakan filter untuk menemukan produk yang sesuai.</p>
            <a href="{{ route('category', 'semua') }}">Lihat kategori <i class="fa-solid fa-arrow-right"></i></a>
        </div>
    </section>

    <form class="catalog-toolbar" method="GET" action="{{ route('products') }}" aria-label="Filter produk">
        <label class="sr-only" for="catalog-search">Cari produk</label>
        <input id="catalog-search" class="catalog-sort" type="search" name="search" value="{{ request('search') }}" placeholder="Cari nama produk atau toko">

        <label class="sr-only" for="catalog-category">Kategori</label>
        <select class="catalog-sort" id="catalog-category" name="category">
            <option value="">Semua kategori</option>
            @foreach ($categories as $category)
                <option value="{{ $category->slug }}" @selected(request('category') === $category->slug)>{{ $category->name }}</option>
            @endforeach
        </select>

        <label class="sr-only" for="catalog-sort">Urutkan</label>
        <select class="catalog-sort" id="catalog-sort" name="sort">
            <option value="newest" @selected(request('sort', 'newest') === 'newest')>Terbaru</option>
            <option value="popular" @selected(request('sort') === 'popular')>Rating dan ulasan</option>
            <option value="price_asc" @selected(request('sort') === 'price_asc')>Harga terendah</option>
            <option value="price_desc" @selected(request('sort') === 'price_desc')>Harga tertinggi</option>
        </select>

        <button class="catalog-filter active" type="submit"><i class="fa-solid fa-sliders"></i> Terapkan</button>
        @if (request()->hasAny(['search', 'category', 'sort']) && (request('search') || request('category') || request('sort') !== 'newest'))
            <a class="catalog-filter" href="{{ route('products') }}">Reset</a>
        @endif
    </form>

    <section class="catalog-section">
        <div class="catalog-section-header">
            <div>
                <span class="catalog-section-kicker">HASIL KATALOG</span>
                <h2>{{ $products->total() }} produk</h2>
            </div>
        </div>

        @if ($products->isNotEmpty())
            <div class="catalog-product-grid">
                @foreach ($products as $product)
                    <x-product-card :product="$product" />
                @endforeach
            </div>
            <div class="catalog-pagination">{{ $products->links() }}</div>
        @else
            <div class="catalog-empty-state">
                <i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i>
                <h3>Produk tidak ditemukan</h3>
                <p>Coba kata pencarian atau kategori lain.</p>
                <a href="{{ route('products') }}">Lihat semua produk</a>
            </div>
        @endif
    </section>
</div>
@endsection