@extends('layouts.app')

@section('title', 'MoMa Mall')

@section('content')
<div class="moma-mall-page">
    <nav class="moma-breadcrumb" aria-label="Breadcrumb">
        <a href="{{ route('home') }}">Beranda</a>
        <i class="fa-solid fa-chevron-right"></i>
        <span>MoMa Mall</span>
    </nav>

    <section class="moma-hero">
        <div class="moma-hero-copy">
            <span class="moma-hero-kicker"><i class="fa-solid fa-shield-heart"></i> KUALITAS TERJAMIN</span>
            <h1>MoMa Mall</h1>
            <p>Temukan brand dan produk pilihan dengan kualitas terbaik.</p>
            <div class="moma-hero-meta">
                <span><strong>{{ $officialStores->count() }}</strong> toko resmi</span>
                <span><strong>{{ number_format($officialStores->sum('products')) }}</strong> produk pilihan</span>
                <span><strong>{{ number_format($officialStores->avg('rating') ?? 0, 1) }}/5</strong> rating rata-rata</span>
            </div>
        </div>
        <div class="moma-hero-visual" aria-hidden="true">
            <span class="moma-hero-ring ring-one"></span>
            <span class="moma-hero-ring ring-two"></span>
            <div class="moma-hero-logo"><i class="fa-solid fa-store"></i><strong>MoMa</strong><span>MALL</span></div>
            <i class="moma-hero-star star-one fa-solid fa-star"></i>
            <i class="moma-hero-star star-two fa-solid fa-star"></i>
            <i class="moma-hero-star star-three fa-solid fa-star"></i>
        </div>
    </section>

    <section class="moma-section">
        <div class="moma-section-heading">
            <div>
                <span>DAFTAR RESMI</span>
                <h2>Official Store</h2>
                <p>Toko dan brand yang dipercaya oleh pembeli NusantaraMart.</p>
            </div>
            <a href="{{ route('products') }}">Lihat semua produk <i class="fa-solid fa-arrow-right"></i></a>
        </div>

        <div class="moma-store-grid">
            @foreach($officialStores as $store)
                <article class="moma-store-card">
                    <div class="moma-store-top">
                        <div class="moma-store-logo">{{ $store['logo'] }}</div>
                        <span class="moma-official-badge"><i class="fa-solid fa-badge-check"></i> Official</span>
                    </div>
                    <h3>{{ $store['name'] }}</h3>
                    <div class="moma-store-location"><i class="fa-solid fa-location-dot"></i> {{ $store['location'] }}</div>
                    <div class="moma-store-stats">
                        <div><i class="fa-solid fa-star"></i><strong>{{ number_format($store['rating'], 1) }}</strong><span>Rating</span></div>
                        <div><i class="fa-solid fa-box"></i><strong>{{ number_format($store['products']) }}</strong><span>Produk</span></div>
                    </div>
                    <a class="moma-store-button" href="{{ route('shop.show', $store['slug']) }}">Kunjungi Toko <i class="fa-solid fa-arrow-up-right-from-square"></i></a>
                </article>
            @endforeach
        </div>
    </section>

    <section class="moma-section moma-products-section">
        <div class="moma-section-heading">
            <div>
                <span>PRODUK PILIHAN</span>
                <h2>Produk MoMa Mall</h2>
                <p>Produk unggulan dari Toko Gotik dan Toko Wilda.</p>
            </div>
            <span class="moma-product-count">{{ $productCards->count() }} produk</span>
        </div>

        <div class="moma-product-grid">
            @foreach($productCards as $product)
                <article class="moma-product-card">
                    <div class="moma-product-image">
                        @if($product['image'])
                            <img src="{{ $product['image'] }}" alt="{{ $product['name'] }}" loading="lazy">
                        @else
                            <div class="moma-product-placeholder"><i class="fa-solid fa-box-open"></i></div>
                        @endif
                        <span class="moma-official-badge"><i class="fa-solid fa-badge-check"></i> Official</span>
                    </div>
                    <div class="moma-product-body">
                        <div class="moma-product-seller">{{ $product['seller'] }}</div>
                        <h3>{{ $product['name'] }}</h3>
                        <div class="moma-product-price">
                            <strong>Rp {{ number_format($product['price'], 0, ',', '.') }}</strong>
                            @if($product['normal_price'] > $product['price'])
                                <del>Rp {{ number_format($product['normal_price'], 0, ',', '.') }}</del>
                            @endif
                        </div>
                        <div class="moma-product-meta">
                            <span><i class="fa-solid fa-star"></i> {{ number_format($product['rating'], 1) }}</span>
                            <span><i class="fa-solid fa-bag-shopping"></i> {{ number_format($product['sold']) }} terjual</span>
                        </div>
                        <a class="moma-product-button" href="{{ route('products.show', $product['slug']) }}">Lihat Produk <i class="fa-solid fa-arrow-right"></i></a>
                    </div>
                </article>
            @endforeach
            @if($productCards->isEmpty())
                <p class="moma-products-empty">Belum ada produk dari Toko Gotik dan Toko Wilda.</p>
            @endif
        </div>
    </section>
</div>
@endsection
