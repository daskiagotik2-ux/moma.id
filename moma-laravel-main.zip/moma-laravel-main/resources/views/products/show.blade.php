@extends('layouts.app')

@section('title', $product->name.' | MoMa.id')

@section('content')
<div class="product-detail-page">
    <nav class="catalog-breadcrumb" aria-label="Breadcrumb">
        <a href="{{ route('home') }}">Beranda</a>
        <i class="fa-solid fa-chevron-right"></i>
        <a href="{{ route('category', $product->category->slug) }}">{{ $product->category->name }}</a>
        <i class="fa-solid fa-chevron-right"></i>
        <span>{{ $product->name }}</span>
    </nav>

    @if (session('success')) <p class="buyer-flash-success" role="status">{{ session('success') }}</p> @endif
    @if (session('error')) <p class="buyer-flash-error" role="alert">{{ session('error') }}</p> @endif

    <section class="product-detail-grid">
        <div class="product-detail-image"><img src="{{ $product->image }}" alt="{{ $product->name }}"></div>
        <div class="product-detail-info">
            <span class="catalog-section-kicker">{{ $product->category->name }}</span>
            <h1>{{ $product->name }}</h1>
            <div class="product-detail-rating">
                @if ($product->review_count > 0)
                    <i class="fa-solid fa-star"></i> {{ number_format($product->rating, 1, ',', '.') }} · {{ number_format($product->review_count, 0, ',', '.') }} ulasan
                @else
                    Belum ada ulasan
                @endif
            </div>
            <p class="product-detail-price">{{ $product->formatted_price }}</p>
            <dl class="product-detail-facts">
                <div><dt>Stok</dt><dd>{{ $product->stock === null ? 'Belum diperbarui' : ($product->stock > 0 ? number_format($product->stock, 0, ',', '.').' tersedia' : 'Habis') }}</dd></div>
                <div><dt>Toko</dt><dd>@if($product->store?->status === 'approved')<a class="text-[#B91C2B] hover:underline" href="{{ route('shop.show', $product->store->slug) }}">{{ $product->store->store_name }}</a>@else{{ $product->seller }}@endif</dd></div>
                <div><dt>Lokasi</dt><dd>{{ $product->location }}</dd></div>
            </dl>
            <div class="product-detail-description">
                <h2>Deskripsi</h2>
                <p>{{ $product->description ?: 'Deskripsi produk belum ditambahkan.' }}</p>
            </div>
            @if ($product->stock !== 0)
                <div class="product-detail-actions">
                    <form method="POST" action="{{ route('cart.add', $product->slug) }}">
                        @csrf
                        <input type="hidden" name="quantity" value="1">
                        <button class="buyer-secondary-button" type="submit">Tambah ke Keranjang</button>
                    </form>
                    <form method="POST" action="{{ route('cart.add', $product->slug) }}">
                        @csrf
                        <input type="hidden" name="quantity" value="1">
                        <input type="hidden" name="redirect_to" value="checkout">
                        <button class="buyer-primary-button" type="submit">Beli Sekarang</button>
                    </form>
                    @auth
                        <form method="POST" action="{{ route('wishlist.toggle', $product->slug) }}">
                            @csrf
                            <button class="buyer-icon-button" type="submit" aria-label="Simpan ke wishlist"><i class="fa-regular fa-heart"></i></button>
                        </form>
                    @else
                        <a class="buyer-icon-button" href="{{ route('wishlist') }}" aria-label="Daftar atau masuk untuk menyimpan ke wishlist"><i class="fa-regular fa-heart"></i></a>
                    @endauth
                </div>
                @if ($product->stock === null)
                    <p class="product-stock-note">Jumlah stok belum dicatat. Toko akan mengonfirmasi ketersediaan setelah pesanan dibuat.</p>
                @endif
            @else
                <p class="product-stock-note">Produk sedang habis dan belum dapat dipesan.</p>
            @endif
        </div>
    </section>
</div>
@endsection