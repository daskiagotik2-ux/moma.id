@extends('layouts.app')

@section('title', 'Fashion | MoMa.id')

@section('content')
<div class="fashion-page">
    <nav class="fashion-breadcrumb" aria-label="Breadcrumb">
        <a href="{{ route('home') }}">Beranda</a>
        <i class="fa-solid fa-chevron-right"></i>
        <span>Fashion</span>
    </nav>

    <section class="fashion-hero">
        <div class="fashion-hero-copy">
            <span class="fashion-kicker"><i class="fa-solid fa-shirt"></i> KATEGORI FASHION</span>
            <h1>Fashion</h1>
            <p>Temukan fashion pilihan dari UMKM dan brand lokal.</p>
            <div class="fashion-hero-meta">
                <span><i class="fa-solid fa-store"></i> 100% lokal</span>
                <span><i class="fa-solid fa-shield-halved"></i> Verifikasi toko</span>
                <span><i class="fa-solid fa-truck-fast"></i> Pengiriman cepat</span>
            </div>
        </div>
        <div class="fashion-hero-art" aria-hidden="true">
            <span class="fashion-fashion-card card-one"><i class="fa-solid fa-shirt"></i></span>
            <span class="fashion-fashion-card card-two"><i class="fa-solid fa-bag-shopping"></i></span>
            <span class="fashion-hero-label">NEW<br>SEASON</span>
        </div>
    </section>

    <nav class="fashion-category-strip" aria-label="Jelajahi kategori fashion">
        @foreach($subcategories as $slug => $subcategory)
            <a
                class="fashion-category-chip {{ $selectedSubcategory === $slug ? 'active' : '' }}"
                href="{{ route('fashion', array_merge(request()->query(), ['subcategory' => $slug])) }}"
                @if($selectedSubcategory === $slug) aria-current="page" @endif
            >
                <i class="fa-solid {{ $subcategory['icon'] }}" aria-hidden="true"></i>{{ $subcategory['label'] }}
            </a>
        @endforeach
    </nav>
    <details class="fashion-other-categories">
        <summary>Kategori lainnya</summary>
        <nav aria-label="Kategori produk lainnya">
            @foreach($categories as $category)
                <a href="{{ route('category', $category->slug) }}">{{ $category->name }}</a>
            @endforeach
        </nav>
    </details>

    <section class="fashion-content">
        <aside class="fashion-filter-sidebar">
            <div class="fashion-filter-heading">
                <h2>Filter</h2>
                <a href="{{ route('fashion') }}">Hapus</a>
            </div>
            <form action="{{ route('fashion') }}" method="GET" class="fashion-filter-form">
                <fieldset>
                    <legend>Kategori</legend>
                    @foreach($subcategories as $slug => $subcategory)
                        <label>
                            <input type="radio" name="subcategory" value="{{ $slug }}" @checked($selectedSubcategory === $slug)>
                            <span>{{ $subcategory['label'] }}</span>
                        </label>
                    @endforeach
                </fieldset>
                <label class="fashion-search-label" for="fashion-search">Cari produk</label>
                <input id="fashion-search" type="search" name="search" value="{{ request('search') }}" placeholder="Cari produk fashion...">
                <fieldset>
                    <legend>Urutkan</legend>
                    <label><input type="radio" name="sort" value="rating" {{ request('sort', 'rating') === 'rating' ? 'checked' : '' }}><span>Rating tertinggi</span></label>
                    <label><input type="radio" name="sort" value="price_asc" {{ request('sort') === 'price_asc' ? 'checked' : '' }}><span>Harga terendah</span></label>
                    <label><input type="radio" name="sort" value="price_desc" {{ request('sort') === 'price_desc' ? 'checked' : '' }}><span>Harga tertinggi</span></label>
                </fieldset>
                <fieldset>
                    <legend>Harga</legend>
                    <label><input type="radio" name="price" value="100000" {{ request('price') === '100000' ? 'checked' : '' }}><span>Dibawah Rp100 ribu</span></label>
                    <label><input type="radio" name="price" value="250000" {{ request('price') === '250000' ? 'checked' : '' }}><span>Dibawah Rp250 ribu</span></label>
                    <label><input type="radio" name="price" value="500000" {{ request('price') === '500000' ? 'checked' : '' }}><span>Dibawah Rp500 ribu</span></label>
                </fieldset>
                <fieldset>
                    <legend>Rating</legend>
                    <label><input type="radio" name="rating" value="4.8" {{ request('rating') === '4.8' ? 'checked' : '' }}><span>4.8 ke atas</span></label>
                    <label><input type="radio" name="rating" value="4.7" {{ request('rating') === '4.7' ? 'checked' : '' }}><span>4.7 ke atas</span></label>
                </fieldset>
                <fieldset>
                    <legend>Lokasi</legend>
                    @foreach($locations as $location)
                        <label><input type="radio" name="location" value="{{ $location }}" @checked(request('location') === $location)><span>{{ $location }}</span></label>
                    @endforeach
                </fieldset>
                <button class="fashion-apply-filter" type="submit"><i class="fa-solid fa-sliders"></i> Terapkan filter</button>
            </form>
        </aside>

        <div class="fashion-products">
            <div class="fashion-products-heading">
                <div><span>PRODUK TERPILIH</span><h2>Fashion lokal terbaik</h2></div>
                <span>{{ $productCards->count() }} produk</span>
            </div>

            @if($productCards->isNotEmpty())
                <div class="fashion-product-grid">
                    @foreach($productCards as $product)
                        <article class="fashion-product-card">
                            <div class="fashion-product-image">
                                @if($product['image'])
                                    <img src="{{ $product['image'] }}" alt="{{ $product['name'] }}" loading="lazy" data-image-fallback>
                                    <div class="fashion-product-placeholder" hidden><i class="fa-solid fa-shirt" aria-hidden="true"></i></div>
                                @else
                                    <div class="fashion-product-placeholder"><i class="fa-solid fa-shirt"></i></div>
                                @endif
                                @if($product['discount'] > 0)
                                    <span class="fashion-discount">-{{ $product['discount'] }}%</span>
                                @endif
                                <button class="fashion-favorite" type="button" aria-label="Simpan ke wishlist"><i class="fa-regular fa-heart"></i></button>
                            </div>
                            <div class="fashion-product-body">
                                <div class="fashion-product-seller">{{ $product['seller'] }} <span>•</span> {{ $product['location'] }}</div>
                                <h3>{{ $product['name'] }}</h3>
                                <div class="fashion-price"><strong>Rp {{ number_format($product['price'], 0, ',', '.') }}</strong>@if($product['old_price'] > $product['price'])<del>Rp {{ number_format($product['old_price'], 0, ',', '.') }}</del>@endif</div>
                                <div class="fashion-product-meta">
                                    <span><i class="fa-solid fa-star"></i> {{ number_format($product['rating'], 1) }}</span>
                                    <span><i class="fa-solid fa-bag-shopping"></i> {{ number_format($product['sold']) }} terjual</span>
                                </div>
                                <div class="fashion-product-footer">
                                    <span>{{ $product['category'] }}</span>
                                    <a href="{{ route('products.show', $product['slug']) }}" class="fashion-view-button">Lihat Produk <i class="fa-solid fa-arrow-right"></i></a>
                                </div>
                            </div>
                        </article>
                    @endforeach
                </div>
            @else
                <div class="fashion-empty">
                    <i class="fa-solid fa-search"></i>
                    <h3>Fashion belum ditemukan</h3>
                    <p>Coba kata kunci atau hapus filter untuk melihat semua produk.</p>
                    <a href="{{ route('fashion') }}">Hapus filter</a>
                </div>
            @endif
        </div>
    </section>
</div>
@endsection
