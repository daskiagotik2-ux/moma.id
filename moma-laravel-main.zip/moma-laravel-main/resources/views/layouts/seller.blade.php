@extends('layouts.app')

@section('content')
<div class="seller-shell">
    @include('seller.partials.sidebar')
    <main class="seller-main">
        @yield('seller-content')
    </main>
</div>
@endsection