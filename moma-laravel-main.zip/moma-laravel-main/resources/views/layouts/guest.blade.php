<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>@yield('title', request()->routeIs('register') ? 'Daftar | MoMa.id' : 'Masuk | MoMa.id')</title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=plus-jakarta-sans:400,500,600,700,800&display=swap" rel="stylesheet" />

        <!-- Scripts -->
        @vite(['resources/css/app.css', 'resources/js/app.js'])
    </head>
    <body class="auth-shell">
        <header class="auth-header">
            <div class="auth-header-inner">
                <a href="{{ route('home') }}" class="auth-logo" aria-label="MoMa.id beranda">
                    <x-moma-logo class="auth-logo-mark" />
                    <span class="auth-logo-wordmark">MoMa<span>.id</span></span>
                </a>
                <span class="auth-header-divider" aria-hidden="true"></span>
                <span class="auth-header-title">{{ request()->routeIs('register') ? 'Daftar' : 'Masuk' }}</span>
                <a class="auth-help-link" href="{{ route('help') }}">Butuh bantuan?</a>
            </div>
        </header>

        <main class="auth-main">
            {{ $slot }}
        </main>

        <footer class="auth-footer">© {{ date('Y') }} MoMa.id · Mendukung karya lokal Indonesia</footer>
    </body>
</html>
