<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'MoMa.id - Belanja dari UMKM Indonesia')</title>
    @if (request()->routeIs('home'))
        <script>
            if (sessionStorage.getItem('moma-splash-seen') === '1') {
                document.documentElement.classList.add('moma-splash-seen');
            } else {
                document.documentElement.classList.add('moma-splash-active');
            }
        </script>
    @endif
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://unpkg.com/lucide@latest"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <script>
        document.documentElement.classList.toggle('dark', localStorage.getItem('moma-theme') === 'dark'
            || (!localStorage.getItem('moma-theme') && window.matchMedia('(prefers-color-scheme: dark)').matches));
    </script>
    @vite(['resources/css/app.css', 'resources/css/marketplace-sidebar.css', 'resources/css/seller.css', 'resources/css/voucher.css', 'resources/css/kategori.css', 'resources/js/app.js'])
</head>
@php
    $isAccountPage = request()->routeIs(['dashboard', 'orders', 'wishlist', 'profile.edit', 'profile.update', 'profile.destroy']);
@endphp
<body class="bg-[#F3F0EF] text-[#4A171D] font-sans antialiased @if($isAccountPage) marketplace-customer-page @else marketplace-home-page @endif">
    @if (session('login_success'))
        <div class="login-success-toast" role="status" aria-live="polite">{{ session('login_success') }}</div>
    @endif
    @include('partials.header')
    <div class="app-shell @if(request()->routeIs('dashboard')) account-app-shell @endif @if(request()->routeIs('home')) marketplace-home-shell @endif">
        <div class="@if($isAccountPage) page-grid @if(request()->routeIs('dashboard')) account-dashboard-grid @endif @if(request()->routeIs('orders', 'orders.show')) account-orders-grid @endif @if(request()->routeIs('profile.edit', 'profile.update', 'profile.destroy')) account-settings-grid @endif @endif @if(request()->routeIs('home')) marketplace-home-grid @endif">
            <main class="main" id="main-content" tabindex="-1">
                @yield('content')
            </main>
            @if($isAccountPage && !request()->routeIs('dashboard', 'orders', 'orders.show', 'profile.edit', 'profile.update', 'profile.destroy'))
                @include('partials.rightbar')
            @endif
        </div>
        @include('partials.footer')
    </div>
</body>
</html>