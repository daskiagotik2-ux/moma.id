@extends('layouts.app')

@section('title', 'Dashboard — MoMa.id')

@section('content')
<div class="account-dashboard">
    <section class="account-welcome">
        <span class="account-avatar" aria-hidden="true">{{ strtoupper(substr(Auth::user()->name, 0, 1)) }}</span>
        <div class="account-welcome-copy">
            <span class="account-membership">AKUN MoMa.ID</span>
            <h1>Hai, {{ Auth::user()->name }}</h1>
            <p>{{ Auth::user()->email }}</p>
        </div>
        <div class="account-header-actions">
            <a class="account-edit-link" href="{{ route('cart.index') }}" aria-label="Buka keranjang" title="Keranjang">
                <i data-lucide="shopping-cart"></i>
            </a>
            <a class="account-edit-link" href="{{ route('profile.edit') }}" aria-label="Pengaturan akun" title="Pengaturan akun">
                <i data-lucide="settings-2"></i>
            </a>
        </div>
    </section>

    <section class="account-panel" aria-labelledby="account-orders-title">
        <div class="account-panel-heading">
            <h2 id="account-orders-title"><i data-lucide="package-check"></i> Pesanan saya</h2>
            <a href="{{ route('orders') }}">Lihat Riwayat Pesanan @if($orderCount > 0)<span class="account-order-count">{{ $orderCount }}</span>@endif <i data-lucide="chevron-right"></i></a>
        </div>
        <div class="account-order-links">
            <a class="account-order-status" href="{{ route('orders', ['status' => 'unpaid']) }}">
                <span class="account-feature-icon"><i data-lucide="credit-card"></i></span>
                <span>Belum Bayar</span>
                <span class="account-order-status-count">{{ $orderStatusCounts['unpaid'] }}</span>
            </a>
            <a class="account-order-status" href="{{ route('orders', ['status' => 'packed']) }}">
                <span class="account-feature-icon"><i data-lucide="package-check"></i></span>
                <span>Dikemas</span>
                <span class="account-order-status-count">{{ $orderStatusCounts['packed'] }}</span>
            </a>
            <a class="account-order-status" href="{{ route('orders', ['status' => 'shipped']) }}">
                <span class="account-feature-icon"><i data-lucide="truck"></i></span>
                <span>Dikirim</span>
                <span class="account-order-status-count">{{ $orderStatusCounts['shipped'] }}</span>
            </a>
            <a class="account-order-status" href="{{ route('orders', ['status' => 'completed']) }}">
                <span class="account-feature-icon"><i data-lucide="badge-check"></i></span>
                <span>Selesai</span>
                <span class="account-order-status-count">{{ $orderStatusCounts['completed'] }}</span>
            </a>
        </div>
    </section>

    <section class="account-panel" aria-labelledby="account-shortcuts-title">
        <div class="account-panel-heading">
            <h2 id="account-shortcuts-title"><i data-lucide="layout-grid"></i> Layanan saya</h2>
        </div>
        <div class="account-shortcut-grid">
            <a class="account-shortcut" href="{{ route('wishlist') }}">
                <span class="account-feature-icon"><i data-lucide="heart"></i></span>
                <span><strong>Produk Favorit</strong><small>Produk yang kamu simpan</small></span>
                <i class="account-shortcut-arrow" data-lucide="chevron-right"></i>
            </a>
            <a class="account-shortcut" href="{{ route('cart.index') }}">
                <span class="account-feature-icon"><i data-lucide="shopping-cart"></i></span>
                <span><strong>Keranjang belanja</strong><small>Lanjutkan belanja kamu</small></span>
                <i class="account-shortcut-arrow" data-lucide="chevron-right"></i>
            </a>
            <a class="account-shortcut" href="{{ route('profile.edit') }}">
                <span class="account-feature-icon"><i data-lucide="user-round-cog"></i></span>
                <span><strong>Pengaturan akun</strong><small>Ubah nama, email, dan sandi</small></span>
                <i class="account-shortcut-arrow" data-lucide="chevron-right"></i>
            </a>
            <a class="account-shortcut" href="{{ route('products') }}">
                <span class="account-feature-icon"><i data-lucide="store"></i></span>
                <span><strong>Jelajahi produk</strong><small>Temukan produk UMKM</small></span>
                <i class="account-shortcut-arrow" data-lucide="chevron-right"></i>
            </a>
        </div>
    </section>

    <section class="account-panel account-activity-panel" aria-labelledby="account-activity-title">
        <div class="account-panel-heading">
            <h2 id="account-activity-title"><i data-lucide="activity"></i> Pusat aktivitas</h2>
        </div>
        <div class="account-activity-list">
            @if($store)
                <a href="{{ route('seller.dashboard') }}">
                    <i data-lucide="store"></i>
                    <span><strong>Toko Saya</strong><small>{{ $store->store_name }} · @switch($store->status) @case('approved') Disetujui @break @case('revision') Perlu perbaikan @break @case('rejected') Ditolak @break @default Menunggu verifikasi @endswitch</small></span>
                    <i class="account-shortcut-arrow" data-lucide="chevron-right"></i>
                </a>
            @else
                <a href="{{ route('stores.create') }}">
                    <i data-lucide="store"></i>
                    <span><strong>Mulai berjualan</strong><small>Ajukan pendaftaran toko</small></span>
                    <i class="account-shortcut-arrow" data-lucide="chevron-right"></i>
                </a>
            @endif
            <a href="{{ route('orders') }}">
                <i data-lucide="receipt-text"></i>
                <span><strong>Riwayat belanja</strong><small>Lihat semua pesananmu</small></span>
                <i class="account-shortcut-arrow" data-lucide="chevron-right"></i>
            </a>
            <a href="{{ route('help') }}">
                <i data-lucide="circle-help"></i>
                <span><strong>Pusat bantuan</strong><small>Temukan jawaban dan bantuan</small></span>
                <i class="account-shortcut-arrow" data-lucide="chevron-right"></i>
            </a>
            <form method="POST" action="{{ route('logout') }}" class="account-logout-row">
                @csrf
                <button type="submit">
                    <i data-lucide="log-out"></i>
                    <span><strong>Keluar dari akun</strong></span>
                    <i class="account-shortcut-arrow" data-lucide="chevron-right"></i>
                </button>
            </form>
        </div>
    </section>

    <nav class="account-bottom-nav" aria-label="Navigasi utama">
        <a href="{{ route('home') }}">
            <i data-lucide="house"></i>
            <span>Beranda</span>
        </a>
        <a href="{{ route('category', 'semua') }}">
            <i data-lucide="tags"></i>
            <span>Kategori</span>
        </a>
        <a href="{{ route('cart.index') }}">
            <i data-lucide="shopping-cart"></i>
            <span>Keranjang</span>
        </a>
        <a href="{{ route('dashboard') }}" aria-current="page">
            <i data-lucide="user-round"></i>
            <span>Saya</span>
        </a>
    </nav>
</div>
@endsection