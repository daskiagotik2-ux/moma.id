@extends('layouts.app')

@section('title', 'Makanan Lokal Indonesia')

@section('content')
<div class="makanan-lokal-page">
    <nav class="makanan-breadcrumb" aria-label="Breadcrumb">
        <a href="{{ route('home') }}">Beranda</a>
        <i class="fa-solid fa-chevron-right"></i>
        <span>Makanan Lokal</span>
    </nav>

    <section class="makanan-hero">
        <div class="makanan-hero-copy">
            <span class="makanan-hero-kicker"><i class="fa-solid fa-leaf"></i> DARI UMKM INDONESIA</span>
            <h1>Makanan Lokal Indonesia</h1>
            <p>Temukan makanan khas dan produk kuliner lokal dari UMKM Indonesia.</p>
            <div class="makanan-hero-stats">
                <span><strong>{{ $productCards->count() }}</strong> produk tersedia</span>
                <span><strong>100%</strong> lokal</span>
                <span><strong>UMKM</strong> terverifikasi</span>
            </div>
        </div>
        <div class="makanan-hero-art" aria-hidden="true">
            <div class="makanan-plate"><i class="fa-solid fa-utensils"></i><span>LOCAL<br>FLAVOUR</span></div>
            <i class="makanan-leaf leaf-one fa-solid fa-leaf"></i>
            <i class="makanan-leaf leaf-two fa-solid fa-leaf"></i>
        </div>
    </section>

    <section class="makanan-category-section">
        <div class="makanan-category-heading">
            <div><span>JELAJAHI WILAYAH</span><h2>Temukan khasmu</h2></div>
            <p>Mulai dari legendar Aceh hingga hidangan khas Papua.</p>
        </div>
        <div class="makanan-category-grid">
            @php($categories = [
                ['Aceh', 'fa-map-location-dot', '#ef5d46'],
                ['Sumatera', 'fa-location-dot', '#f59d3e'],
                ['Jawa', 'fa-map', '#3b8f75'],
                ['Kalimantan', 'fa-tree', '#3e73b7'],
                ['Sulawesi', 'fa-location-crosshairs', '#8b62b8'],
                ['Papua', 'fa-globe', '#d95a83'],
            ])
            @foreach($categories as $category)
                <a class="makanan-category-card" href="{{ route('makanan-lokal', ['location' => $category[0]]) }}">
                    <span style="--category-color: {{ $category[2] }}"><i class="fa-solid {{ $category[1] }}"></i></span>
                    <strong>{{ $category[0] }}</strong>
                </a>
            @endforeach
        </div>
    </section>

    <section class="makanan-products-section">
        <div class="makanan-product-heading">
            <div><span>PRODUK TERPILIH</span><h2>Makanan Lokal</h2></div>
            <p>Jadikan pilihan makanmu lebih nikmat.</p>
        </div>

        <form class="makanan-filter" action="{{ route('makanan-lokal') }}" method="GET">
            <label class="makanan-search">
                <i class="fa-solid fa-magnifying-glass"></i>
                <input type="search" name="search" value="{{ request('search') }}" placeholder="Cari makanan lokal..." aria-label="Cari makanan lokal">
            </label>
            <div class="makanan-filter-controls">
                <label><span>Lokasi</span><select name="location"><option value="">Semua lokasi</option><option value="Aceh">Aceh</option><option value="Sumatera">Sumatera</option><option value="Jawa">Jawa</option><option value="Kalimantan">Kalimantan</option><option value="Sulawesi">Sulawesi</option><option value="Papua">Papua</option></select></label>
                <label><span>Harga</span><select name="price"><option value="">Semua harga</option><option value="10000">Dibawah Rp10 ribu</option><option value="30000">Dibawah Rp30 ribu</option><option value="50000">Dibawah Rp50 ribu</option></select></label>
                <label><span>Rating</span><select name="rating"><option value="">Semua rating</option><option value="4.8">4.8 ke atas</option><option value="4.7">4.7 ke atas</option><option value="4.5">4.5 ke atas</option></select></label>
                <label><span>Terlaris</span><select name="popular"><option value="">Semua produk</option><option value="1">Terlaris</option></select></label>
                <button type="submit"><i class="fa-solid fa-sliders"></i> Filter</button>
            </div>
        </form>

        <div class="makanan-result-count"><span>{{ $productCards->count() }} produk</span><small>Disusun berdasarkan rating</small></div>

        @if($productCards->isNotEmpty())
            <div class="makanan-product-grid">
                @foreach($productCards as $product)
                    <article class="makanan-product-card">
                        <div class="makanan-product-image">
                            @if($product['image'])
                                <img src="{{ $product['image'] }}" alt="{{ $product['name'] }}" loading="lazy">
                            @else
                                <div class="makanan-product-placeholder"><i class="fa-solid fa-utensils"></i></div>
                            @endif
                            <span class="makanan-local-badge"><i class="fa-solid fa-leaf"></i> UMKM Lokal</span>
                        </div>
                        <div class="makanan-product-body">
                            <div class="makanan-product-seller">{{ $product['seller'] }} <span>•</span> {{ $product['location'] }}</div>
                            <h3>{{ $product['name'] }}</h3>
                            <div class="makanan-product-price"><strong>Rp {{ number_format($product['price'], 0, ',', '.') }}</strong>@if($product['normal_price'] > $product['price'])<del>Rp {{ number_format($product['normal_price'], 0, ',', '.') }}</del>@endif</div>
                            <div class="makanan-product-meta">
                                <span><i class="fa-solid fa-star"></i> {{ number_format($product['rating'], 1) }}</span>
                                <span><i class="fa-solid fa-bag-shopping"></i> {{ number_format($product['sold']) }} terjual</span>
                            </div>
                            <a class="makanan-buy-button" href="{{ route('products.show', $product['slug']) }}"><i class="fa-solid fa-arrow-right"></i> Lihat produk</a>
                        </div>
                    </article>
                @endforeach
            </div>
        @else
            <div class="makanan-empty">
                <i class="fa-solid fa-search"></i>
                <h3>Makanan belum ditemukan</h3>
                <p>Coba kata kunci lain atau reset filter.</p>
                <a href="{{ route('makanan-lokal') }}">Hapus filter</a>
            </div>
        @endif
    </section>
</div>
@endsection
