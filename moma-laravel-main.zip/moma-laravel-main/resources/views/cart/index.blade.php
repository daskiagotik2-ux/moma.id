@extends('layouts.app')

@section('title', 'Keranjang | MoMa.id')

@section('content')
<div class="buyer-page">
    <header class="buyer-page-heading"><span>BELANJA</span><h1>Keranjang</h1><p>Periksa produk dan jumlah sebelum melanjutkan.</p></header>
    @if (session('success')) <p class="buyer-flash-success" role="status">{{ session('success') }}</p> @endif
    @if (session('error')) <p class="buyer-flash-error" role="alert">{{ session('error') }}</p> @endif
    @if ($errors->any()) <p class="buyer-flash-error" role="alert">{{ $errors->first() }}</p> @endif

    @if ($items->isEmpty())
        <section class="buyer-empty-state"><i class="fa-solid fa-basket-shopping" aria-hidden="true"></i><h2>Keranjang masih kosong</h2><p>Produk yang Anda pilih akan muncul di sini.</p><a class="buyer-primary-button" href="{{ route('products') }}">Jelajahi produk</a></section>
    @else
        <div class="buyer-cart-layout">
            <section class="buyer-cart-items" aria-label="Produk di keranjang">
                @foreach ($items as $item)
                    @php($product = $item['product'])
                    <article class="buyer-cart-row">
                        <a href="{{ route('products.show', $product->slug) }}" class="buyer-cart-image"><img src="{{ $product->image }}" alt="{{ $product->name }}"></a>
                        <div class="buyer-cart-copy"><a href="{{ route('products.show', $product->slug) }}"><strong>{{ $product->name }}</strong></a><small>{{ $product->seller }}</small><b>{{ $product->formatted_price }}</b>
                            @if ($product->stock === null)<small>Stok akan dikonfirmasi toko</small>@endif
                        </div>
                        <form class="buyer-quantity-form" method="POST" action="{{ route('cart.update', $product->slug) }}">
                            @csrf @method('PATCH')
                            <label class="sr-only" for="quantity-{{ $product->id }}">Jumlah {{ $product->name }}</label>
                            <input id="quantity-{{ $product->id }}" type="number" name="quantity" min="1" max="99" value="{{ $item['quantity'] }}">
                            <button type="submit" aria-label="Perbarui jumlah"><i class="fa-solid fa-rotate"></i></button>
                        </form>
                        <strong class="buyer-line-total">Rp {{ number_format($product->price * $item['quantity'], 0, ',', '.') }}</strong>
                        <form method="POST" action="{{ route('cart.remove', $product->slug) }}">
                            @csrf @method('DELETE')
                            <button class="buyer-icon-button buyer-remove" type="submit" aria-label="Hapus {{ $product->name }}"><i class="fa-regular fa-trash-can"></i></button>
                        </form>
                    </article>
                @endforeach
            </section>
            <aside class="buyer-summary">
                <h2>Ringkasan</h2>
                <div><span>Subtotal</span><strong>Rp {{ number_format($subtotal, 0, ',', '.') }}</strong></div>
                <p>Ongkir dikonfirmasi oleh toko saat pesanan diproses.</p>
                <a class="buyer-primary-button" href="{{ route('checkout.create') }}">Lanjut ke checkout</a>
            </aside>
        </div>
    @endif
</div>
@endsection