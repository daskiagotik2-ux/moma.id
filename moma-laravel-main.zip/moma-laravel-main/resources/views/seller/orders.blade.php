@extends('layouts.seller')

@section('title', 'Pesanan Masuk | Seller Center MoMa.id')

@section('seller-content')
<header class="seller-page-heading"><div><span class="seller-eyebrow">TRANSAKSI TOKO</span><h1>Pesanan Masuk</h1><p>Pesanan yang mencakup produk dari {{ $store->store_name }}.</p></div></header>
<section class="seller-panel">
    @if(session('success'))
        <div class="seller-flash" role="status">{{ session('success') }}</div>
    @endif
    @if(session('error'))
        <div class="seller-flash seller-flash-error" role="alert">{{ session('error') }}</div>
    @endif
    @if($orders->isEmpty())
        <div class="seller-empty">Belum ada pesanan untuk produk toko ini.</div>
    @else
        <div class="seller-table-wrap seller-orders-table-wrap"><table class="seller-table seller-orders-table"><thead><tr><th>Nomor</th><th>Pembeli</th><th>Produk toko</th><th>Tanggal</th><th>Nilai toko</th><th>Pembayaran</th><th>Status toko</th><th>Aksi</th></tr></thead><tbody>
            @foreach($orders as $order)
                @php
                    $hasPendingStoreItems = $order->items->contains(fn ($item) => $item->seller_status === 'pending');
                    $hasAcceptedStoreItems = $order->items->contains(fn ($item) => $item->seller_status === 'accepted');
                    $storeItemsShipped = $order->items->isNotEmpty()
                        && $order->items->every(fn ($item) => in_array($item->seller_status, ['shipped', 'completed'], true));
                    $storeItemsCompleted = $order->items->isNotEmpty()
                        && $order->items->every(fn ($item) => $item->seller_status === 'completed');
                    $payment = $order->payments->first();
                    $thisStoreApproved = $payment?->approvals->contains('store_id', $store->id) ?? false;
                    $canVerifyPayment = $payment
                        && $payment->status->value === 'pending'
                        && $payment->proof_path
                        && $order->payment_status->value === 'waiting_verification'
                        && ! $thisStoreApproved;
                @endphp
                <tr>
                    <td data-label="Nomor"><strong>{{ $order->order_number }}</strong></td>
                    <td data-label="Pembeli">{{ $order->user?->name ?? 'Akun dihapus' }}</td>
                    <td data-label="Produk toko">@foreach($order->items as $item)<div>{{ $item->product_name }} <span class="text-gray-500">× {{ $item->quantity }}</span></div>@endforeach</td>
                    <td data-label="Tanggal">{{ $order->created_at->locale('id')->translatedFormat('d M Y') }}</td>
                    <td data-label="Nilai toko"><strong>Rp {{ number_format($order->items->sum(fn ($item) => $item->price * $item->quantity), 0, ',', '.') }}</strong></td>
                    <td data-label="Pembayaran">
                        <span>{{ $order->payment_method->label() }}</span><br>
                        <span class="payment-badge payment-badge-{{ $order->payment_status->value }}">{{ match($order->payment_status->value) { 'unpaid' => 'Belum dibayar', 'waiting_verification' => 'Menunggu verifikasi', 'paid' => 'Lunas', 'failed' => 'Ditolak', 'expired' => 'Kedaluwarsa', 'refunded' => 'Dikembalikan' } }}</span>
                    </td>
                    <td data-label="Status toko">
                        @if($order->status === 'awaiting_payment')
                            <span class="seller-pill seller-pill-muted">{{ match($order->payment_status->value) { 'waiting_verification' => 'Menunggu verifikasi toko', 'failed' => 'Menunggu unggah ulang bukti', default => 'Menunggu pembayaran' } }}</span>
                        @elseif($order->status === 'cancelled')
                            <span class="seller-pill seller-pill-muted">Dibatalkan</span>
                        @elseif($storeItemsCompleted)
                            <span class="seller-pill">Selesai</span>
                        @elseif($storeItemsShipped)
                            <span class="seller-pill">Dikirim</span>
                        @elseif($hasAcceptedStoreItems)
                            <span class="seller-pill">Disetujui toko</span>
                        @else
                            <span class="seller-pill seller-pill-muted">Menunggu konfirmasi toko</span>
                        @endif
                    </td>
                    <td data-label="Aksi">
                        @if($canVerifyPayment)
                            <div class="seller-payment-review">
                                <a href="{{ route('payments.proof', $payment) }}">Unduh bukti bayar</a>
                                @if($payment->approvals->isNotEmpty())
                                    <small>Disetujui {{ $payment->approvals->count() }} toko; menunggu toko lain.</small>
                                @endif
                                <form method="POST" action="{{ route('seller.orders.payments.verify', [$order, $payment]) }}" class="seller-payment-review-form">
                                    @csrf
                                    <label class="sr-only" for="payment-note-{{ $payment->id }}">Catatan verifikasi</label>
                                    <input id="payment-note-{{ $payment->id }}" name="note" maxlength="1000" placeholder="Catatan (opsional)">
                                    <button class="seller-button seller-order-approve" name="decision" value="approve" type="submit">Setujui bukti</button>
                                    <button class="seller-order-reject" name="decision" value="reject" type="submit" onclick="return confirm('Tolak bukti pembayaran ini?')">Tolak bukti</button>
                                </form>
                            </div>
                        @elseif($thisStoreApproved && $order->payment_status->value === 'waiting_verification')
                            <span class="seller-order-complete">Persetujuan toko Anda tercatat</span>
                        @elseif($hasPendingStoreItems && $order->status === 'awaiting_confirmation' && ($order->payment_method->value === 'cod' || $order->payment_status->value === 'paid'))
                            <form method="POST" action="{{ route('seller.orders.approve', $order) }}" onsubmit="return confirm('Setujui pesanan {{ $order->order_number }} dari toko Anda?')">
                                @csrf
                                <button class="seller-button seller-order-approve" type="submit"><i class="fa-solid fa-check" aria-hidden="true"></i> Setujui</button>
                            </form>
                        @elseif($hasAcceptedStoreItems && in_array($order->status, ['processing', 'shipped'], true))
                            <form method="POST" action="{{ route('seller.orders.ship', $order) }}" onsubmit="return confirm('Tandai produk toko Anda sudah dikirim?')">
                                @csrf
                                <button class="seller-button seller-order-approve" type="submit"><i class="fa-solid fa-truck" aria-hidden="true"></i> Tandai dikirim</button>
                            </form>
                        @else
                            <span class="seller-order-complete">{{ $order->status === 'awaiting_payment' ? match($order->payment_status->value) { 'waiting_verification' => 'Menunggu verifikasi toko', 'failed' => 'Menunggu unggah ulang', default => 'Menunggu pembayaran' } : ($order->status === 'cancelled' ? 'Dibatalkan' : ($storeItemsCompleted ? 'Selesai' : ($storeItemsShipped ? 'Sudah dikirim' : 'Diproses'))) }}</span>
                        @endif
                    </td>
                </tr>
            @endforeach
        </tbody></table></div>
        <div class="seller-pagination">{{ $orders->links() }}</div>
    @endif
</section>
@endsection