@extends('layouts.seller')

@section('title', 'Statistik Penjualan | Seller Center MoMa.id')

@section('seller-content')
<header class="seller-page-heading"><div><span class="seller-eyebrow">PERFORMA TOKO</span><h1>Statistik Penjualan</h1><p>Ringkasan dihitung dari item pesanan produk {{ $store->store_name }}.</p></div></header>
<section class="seller-metrics"><div class="seller-metric"><span>Nilai produk dalam pesanan</span><strong>Rp {{ number_format($sales, 0, ',', '.') }}</strong></div><div class="seller-metric"><span>Pesanan tercatat</span><strong>{{ number_format($orders->total(), 0, ',', '.') }}</strong></div></section>
<section class="seller-panel">
    <div class="seller-panel-heading"><h2>Rincian pesanan</h2></div>
    @if($orders->isEmpty())<div class="seller-empty">Belum ada data penjualan untuk ditampilkan.</div>
    @else
        <div class="seller-table-wrap"><table class="seller-table"><thead><tr><th>Tanggal</th><th>Pesanan</th><th>Pembeli</th><th>Nilai produk toko</th><th>Status</th></tr></thead><tbody>@foreach($orders as $order)<tr><td>{{ $order->created_at->format('d M Y') }}</td><td>{{ $order->order_number }}</td><td>{{ $order->user?->name ?? 'Akun dihapus' }}</td><td>Rp {{ number_format($order->items->sum(fn ($item) => $item->price * $item->quantity), 0, ',', '.') }}</td><td>{{ str_replace('_', ' ', ucfirst($order->status)) }}</td></tr>@endforeach</tbody></table></div>
        <div class="seller-pagination">{{ $orders->links() }}</div>
    @endif
</section>
@endsection