@extends('layouts.seller')

@section('title', 'Pengaturan Toko | Seller Center MoMa.id')

@section('seller-content')
<header class="seller-page-heading"><div><span class="seller-eyebrow">PROFIL TOKO</span><h1>Pengaturan Toko</h1><p>Perbarui informasi publik dan kontak toko Anda.</p></div></header>
@if(session('success'))<div class="seller-flash" role="status">{{ session('success') }}</div>@endif
<form class="seller-form" method="POST" action="{{ route('stores.update') }}">
    @csrf @method('PUT')
    <div class="seller-field seller-field-wide"><label for="store_name">Nama toko *</label><input id="store_name" name="store_name" type="text" value="{{ old('store_name', $store->store_name) }}" maxlength="100" required>@error('store_name')<span class="seller-field-error">{{ $message }}</span>@enderror</div>
    <div class="seller-field"><label for="category">Kategori toko *</label><select id="category" name="category" required><option value="">Pilih kategori</option>@foreach(['Makanan & Minuman','Fashion','Kerajinan Lokal','Kecantikan','Elektronik','Rumah Tangga','Lainnya'] as $category)<option value="{{ $category }}" @selected(old('category', $store->category) === $category)>{{ $category }}</option>@endforeach</select>@error('category')<span class="seller-field-error">{{ $message }}</span>@enderror</div>
    <div class="seller-field"><label for="phone">Nomor telepon/WhatsApp *</label><input id="phone" name="phone" type="tel" value="{{ old('phone', $store->phone) }}" maxlength="25" required>@error('phone')<span class="seller-field-error">{{ $message }}</span>@enderror</div>
    <div class="seller-field seller-field-wide"><label for="description">Deskripsi toko</label><textarea id="description" name="description" maxlength="1000">{{ old('description', $store->description) }}</textarea>@error('description')<span class="seller-field-error">{{ $message }}</span>@enderror</div>
    <div class="seller-field seller-field-wide"><label for="address">Alamat toko *</label><textarea id="address" name="address" maxlength="1000" required>{{ old('address', $store->address) }}</textarea>@error('address')<span class="seller-field-error">{{ $message }}</span>@enderror</div>
    <div class="seller-form-actions"><button class="seller-button" type="submit">Simpan Perubahan</button></div>
</form>
@endsection