@extends('layouts.seller')

@section('title', 'Buka Toko | Seller Center MoMa.id')

@section('seller-content')
<section class="seller-panel seller-empty">
    <span class="seller-eyebrow">SELLER CENTER MoMa.ID</span>
    <h1 class="mt-2 text-xl font-extrabold text-[#4A171D]">Akun ini belum memiliki toko</h1>
    <p class="mx-auto mt-2 max-w-lg">Daftarkan toko terlebih dahulu. Setelah formulir dikirim, toko demo akan langsung aktif dan Anda dapat mengelola produk.</p>
    <a class="seller-button mt-5" href="{{ route('stores.create') }}"><i class="fa-solid fa-store"></i> Buka Toko Sekarang</a>
</section>
@endsection