@extends('layouts.seller')

@section('title', ($product->exists ? 'Edit Produk' : 'Tambah Produk').' | Seller Center MoMa.id')

@section('seller-content')
<header class="seller-page-heading"><div><span class="seller-eyebrow">{{ $product->exists ? 'UBAH KATALOG' : 'KATALOG TOKO' }}</span><h1>{{ $product->exists ? 'Edit Produk' : 'Tambah Produk' }}</h1><p>Informasi produk akan ditampilkan di marketplace selama toko disetujui.</p></div><a class="seller-button seller-button-secondary" href="{{ route('seller.products.index') }}"><i class="fa-solid fa-arrow-left"></i> Kembali</a></header>
<form class="seller-form" method="POST" enctype="multipart/form-data" action="{{ $product->exists ? route('seller.products.update', $product) : route('seller.products.store') }}">
    @csrf
    @if($product->exists) @method('PUT') @endif
    <div class="seller-field seller-field-wide"><label for="name">Nama produk *</label><input id="name" name="name" type="text" value="{{ old('name', $product->name) }}" maxlength="255" required>@error('name')<span class="seller-field-error">{{ $message }}</span>@enderror</div>
    <div class="seller-field"><label for="category_id">Kategori *</label><select id="category_id" name="category_id" required><option value="">Pilih kategori</option>@foreach($categories as $category)<option value="{{ $category->id }}" @selected((string) old('category_id', $product->category_id) === (string) $category->id)>{{ $category->name }}</option>@endforeach</select>@error('category_id')<span class="seller-field-error">{{ $message }}</span>@enderror</div>
    <div class="seller-field"><label for="price">Harga (Rp) *</label><input id="price" name="price" type="text" inputmode="numeric" pattern="[0-9.,]+" value="{{ old('price', $product->price) }}" required>@error('price')<span class="seller-field-error">{{ $message }}</span>@enderror</div>
    <div class="seller-field"><label for="stock">Stok *</label><input id="stock" name="stock" type="number" min="0" max="999999" value="{{ old('stock', $product->stock ?? 0) }}" required>@error('stock')<span class="seller-field-error">{{ $message }}</span>@enderror</div>
    <div class="seller-field"><label for="image">Foto produk {{ $product->exists ? '(opsional)' : '*' }}</label><input id="image" name="image" type="file" accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp" {{ $product->exists ? '' : 'required' }}>@if($product->exists)<small>Foto saat ini tetap digunakan jika tidak memilih file baru.</small>@endif<small>JPG, PNG, atau WebP; maksimal 5 MB.</small>@error('image')<span class="seller-field-error">{{ $message }}</span>@enderror</div>
    <div class="seller-field seller-field-wide"><label for="description">Deskripsi</label><textarea id="description" name="description" maxlength="5000">{{ old('description', $product->description) }}</textarea>@error('description')<span class="seller-field-error">{{ $message }}</span>@enderror</div>
    <div class="seller-form-actions"><a class="seller-button seller-button-secondary" href="{{ route('seller.products.index') }}">Batal</a><button class="seller-button" type="submit">{{ $product->exists ? 'Simpan Perubahan' : 'Simpan Produk' }}</button></div>
</form>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const priceInput = document.getElementById('price');
        const form = priceInput ? priceInput.closest('form') : null;

        if (!priceInput || !form) {
            return;
        }

        const stripPriceFormatting = () => {
            priceInput.value = priceInput.value.replace(/[^\d]/g, '');
        };

        priceInput.addEventListener('focus', function () {
            stripPriceFormatting();
        });

        priceInput.addEventListener('blur', function () {
            if (!priceInput.value) {
                return;
            }

            const digits = priceInput.value.replace(/\D/g, '');
            if (!digits) {
                priceInput.value = '';
                return;
            }

            priceInput.value = Number(digits).toLocaleString('id-ID');
        });

        form.addEventListener('submit', function () {
            stripPriceFormatting();
        });
    });
</script>
@endsection