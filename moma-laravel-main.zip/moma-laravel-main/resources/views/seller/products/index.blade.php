@extends('layouts.seller')

@section('title', 'Produk Saya | Seller Center MoMa.id')

@section('seller-content')
<header class="seller-page-heading"><div><span class="seller-eyebrow">KATALOG TOKO</span><h1>Produk Saya</h1><p>Kelola produk milik {{ $store->store_name }}.</p></div><a class="seller-button" href="{{ route('seller.products.create') }}"><i class="fa-solid fa-plus"></i> Tambah Produk</a></header>
@if(session('success'))<div class="seller-flash" role="status">{{ session('success') }}</div>@endif
<section class="seller-panel">
    @if($products->isEmpty())
        <div class="seller-empty">Toko belum memiliki produk. Gunakan tombol Tambah Produk untuk mulai mengisi katalog.</div>
    @else
        <div class="seller-table-wrap"><table class="seller-table"><thead><tr><th>Produk</th><th>Harga</th><th>Stok</th><th>Ketersediaan</th><th>Aksi</th></tr></thead><tbody>
            @foreach($products as $product)
                <tr>
                    <td><div class="seller-product-cell"><img src="{{ $product->image }}" alt="{{ $product->name }}"><span><strong>{{ $product->name }}</strong><small>{{ $product->category?->name ?? 'Kategori tidak tersedia' }}</small></span></div></td>
                    <td>Rp {{ number_format($product->price, 0, ',', '.') }}</td>
                    <td>{{ number_format($product->stock ?? 0, 0, ',', '.') }}</td>
                    <td><span class="seller-pill {{ $product->stock === 0 ? 'seller-pill-muted' : '' }}">{{ $product->stock === 0 ? 'Habis' : 'Aktif' }}</span></td>
                    <td><div class="seller-inline-actions"><a href="{{ route('seller.products.edit', $product) }}">Edit</a><form method="POST" action="{{ route('seller.products.destroy', $product) }}" onsubmit="return confirm('Hapus produk ini?')">@csrf @method('DELETE')<button type="submit">Hapus</button></form></div></td>
                </tr>
            @endforeach
        </tbody></table></div>
        <div class="seller-pagination">{{ $products->links() }}</div>
    @endif
</section>
@endsection