<aside class="seller-sidebar" aria-label="Navigasi Seller Center">
    <a class="seller-sidebar-brand" href="{{ route('seller.dashboard') }}">
        <span class="seller-brand-mark">M</span>
        <span><strong>Seller Center</strong><small>MoMa.id</small></span>
    </a>
    @if(auth()->user()->store)
        <div class="seller-store-chip"><span class="seller-store-dot"></span><span>{{ auth()->user()->store->store_name }}</span></div>
    @endif
    <nav class="seller-nav">
        <a href="{{ route('seller.dashboard') }}" @class(['active' => request()->routeIs('seller.dashboard')])><i class="fa-solid fa-chart-pie"></i> Dashboard</a>
        <a href="{{ route('seller.products.index') }}" @class(['active' => request()->routeIs('seller.products.index', 'seller.products.edit')])><i class="fa-solid fa-boxes-stacked"></i> Produk Saya</a>
        <a href="{{ route('seller.products.create') }}" @class(['active' => request()->routeIs('seller.products.create')])><i class="fa-solid fa-circle-plus"></i> Tambah Produk</a>
        <a href="{{ route('seller.orders') }}" @class(['active' => request()->routeIs('seller.orders')])><i class="fa-solid fa-receipt"></i> Pesanan Masuk</a>
        <a href="{{ route('seller.statistics') }}" @class(['active' => request()->routeIs('seller.statistics')])><i class="fa-solid fa-chart-column"></i> Statistik Penjualan</a>
        <a href="{{ route('seller.settings') }}" @class(['active' => request()->routeIs('seller.settings')])><i class="fa-solid fa-store"></i> Pengaturan Toko</a>
        <a href="{{ route('stores.create') }}" @class(['active' => request()->routeIs('stores.create')])><i class="fa-solid fa-circle-check"></i> Status Toko</a>
    </nav>
    <div class="seller-sidebar-bottom">
        @if(auth()->user()->store?->status === 'approved')
            <a href="{{ route('shop.show', auth()->user()->store->slug) }}"><i class="fa-solid fa-arrow-up-right-from-square"></i> Lihat Toko Publik</a>
        @endif
        <a href="{{ route('home') }}"><i class="fa-solid fa-arrow-left"></i> Kembali ke MoMa.id</a>
        <form method="POST" action="{{ route('logout') }}">
            @csrf
            <button type="submit"><i class="fa-solid fa-arrow-right-from-bracket"></i> Keluar</button>
        </form>
    </div>
</aside>