@extends('layouts.seller')

@section('title', 'Dashboard Penjual | MoMa.id')

@section('seller-content')
<header class="seller-page-heading">
    <div><span class="seller-eyebrow">RINGKASAN TOKO</span><h1>Dashboard Penjual</h1><p>Aktivitas terbaru untuk {{ $store->store_name }}.</p></div>
    <a class="seller-button" href="{{ route('seller.products.create') }}"><i class="fa-solid fa-plus"></i> Tambah Produk</a>
</header>
@if(session('success'))<div class="seller-flash" role="status">{{ session('success') }}</div>@endif
@if(session('error'))<div class="seller-flash seller-flash-error" role="alert">{{ session('error') }}</div>@endif
<section class="seller-metrics" aria-label="Ringkasan penjualan">
    <div class="seller-metric"><span>Produk aktif</span><strong>{{ number_format($metrics['activeProducts'], 0, ',', '.') }}</strong></div>
    <div class="seller-metric"><span>Total stok tersedia</span><strong>{{ number_format($metrics['stock'], 0, ',', '.') }}</strong></div>
    <div class="seller-metric"><span>Pesanan masuk</span><strong>{{ number_format($metrics['orders'], 0, ',', '.') }}</strong></div>
    <div class="seller-metric"><span>Nilai pesanan tercatat</span><strong>Rp {{ number_format($metrics['sales'], 0, ',', '.') }}</strong></div>
</section>
<section class="seller-panel">
    <div class="seller-panel-heading"><h2>Identitas toko</h2><a href="{{ route('seller.settings') }}">Pengaturan toko</a></div>
    <div class="grid gap-2 p-4 text-sm text-[#675a59] sm:grid-cols-2">
        <p><strong class="text-[#4A171D]">Nama:</strong> {{ $store->store_name }}</p>
        <p><strong class="text-[#4A171D]">Kategori:</strong> {{ $store->category }}</p>
        <p><strong class="text-[#4A171D]">Status:</strong> <span class="seller-pill {{ $store->status === 'approved' ? '' : 'seller-pill-muted' }}">{{ $store->status === 'approved' ? 'Disetujui' : ucfirst($store->status) }}</span></p>
        <p><strong class="text-[#4A171D]">URL publik:</strong> @if($store->status === 'approved')<a class="font-semibold text-[#B91C2B]" href="{{ route('shop.show', $store->slug) }}">Lihat toko</a>@else Belum ditampilkan @endif</p>
    </div>
</section>
<section class="seller-panel">
    <div class="seller-panel-heading"><h2>Produk terbaru</h2><a href="{{ route('seller.products.index') }}">Semua produk</a></div>
    @if($recentProducts->isEmpty())
        <div class="seller-empty">Belum ada produk di toko ini. <a class="font-bold text-[#B91C2B]" href="{{ route('seller.products.create') }}">Tambahkan produk pertama</a>.</div>
    @else
        <div class="seller-table-wrap"><table class="seller-table"><thead><tr><th>Produk</th><th>Harga</th><th>Stok</th><th>Ketersediaan</th></tr></thead><tbody>
            @foreach($recentProducts as $product)
                <tr><td><div class="seller-product-cell"><img src="{{ $product->image }}" alt="{{ $product->name }}"><span><strong>{{ $product->name }}</strong><small>{{ $product->category?->name }}</small></span></div></td><td>Rp {{ number_format($product->price, 0, ',', '.') }}</td><td>{{ number_format($product->stock ?? 0, 0, ',', '.') }}</td><td><span class="seller-pill {{ $product->stock === 0 ? 'seller-pill-muted' : '' }}">{{ $product->stock === 0 ? 'Habis' : 'Aktif' }}</span></td></tr>
            @endforeach
        </tbody></table></div>
    @endif
</section>
<section class="seller-panel">
    <div class="seller-panel-heading"><h2>Pesanan terbaru</h2><a href="{{ route('seller.orders') }}">Semua pesanan</a></div>
    @if($recentOrders->isEmpty())
        <div class="seller-empty">Belum ada pesanan untuk produk toko ini.</div>
    @else
        <div class="seller-table-wrap"><table class="seller-table"><thead><tr><th>Nomor pesanan</th><th>Pembeli</th><th>Tanggal</th><th>Nilai produk toko</th><th>Status</th></tr></thead><tbody>
            @foreach($recentOrders as $order)
                <tr><td>{{ $order->order_number }}</td><td>{{ $order->user?->name ?? 'Akun dihapus' }}</td><td>{{ $order->created_at->format('d M Y') }}</td><td>Rp {{ number_format($order->items->sum(fn ($item) => $item->price * $item->quantity), 0, ',', '.') }}</td><td><span class="seller-pill seller-pill-muted">{{ str_replace('_', ' ', ucfirst($order->status)) }}</span></td></tr>
            @endforeach
        </tbody></table></div>
    @endif
</section>
@endsection