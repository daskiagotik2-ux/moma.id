@extends('layouts.app')

@section('title', 'Instruksi Pembayaran | MoMa.id')

@section('content')
<div class="buyer-page">
    <header class="buyer-page-heading">
        <span>PEMBAYARAN PESANAN</span>
        <h1>{{ $order->order_number }}</h1>
        <p>Metode: <strong>{{ $order->payment_method->label() }}</strong></p>
        <p>Status:
            <span class="payment-badge payment-badge-{{ $order->payment_status->value }}">{{ match($order->payment_status->value) { 'unpaid' => 'Belum dibayar', 'waiting_verification' => 'Menunggu verifikasi', 'paid' => 'Lunas', 'failed' => 'Pembayaran ditolak', 'expired' => 'Kedaluwarsa', 'refunded' => 'Dikembalikan' } }}</span>
        </p>
    </header>
    @if(session('success'))<p class="buyer-flash-success" role="status">{{ session('success') }}</p>@endif
    @if($errors->any())<p class="buyer-flash-error" role="alert">{{ $errors->first() }}</p>@endif
    <div class="payment-instructions-layout">
        <section class="buyer-checkout-form payment-instructions-card">
            <h2>Nominal pembayaran</h2>
            <strong class="payment-amount">Rp {{ number_format($order->grand_total, 0, ',', '.') }}</strong>
            @if($order->payment_expires_at)
                <p>Batas pembayaran: {{ $order->payment_expires_at->locale('id')->translatedFormat('d F Y, H:i') }} WIB</p>
                @if($order->payment_status->value !== 'paid' && $order->payment_expires_at->isFuture())
                    <p class="payment-countdown" data-payment-countdown="{{ $order->payment_expires_at->toIso8601String() }}" role="timer" aria-live="polite"></p>
                @endif
            @endif

            @if($order->payment_method === \App\Enums\PaymentMethod::BankTransfer)
                <h3>Rekening tujuan</h3>
                @php($configuredAccounts = collect($bankAccounts)->filter(fn ($account) => filled($account['number'])))
                @forelse($configuredAccounts as $bank => $account)
                    <div class="payment-bank-account"><strong>{{ $bank }}</strong><span>{{ $account['number'] }}</span><small>Atas nama {{ $account['name'] }}</small></div>
                @empty
                    <p class="buyer-flash-error">Rekening belum dikonfigurasi. Silakan hubungi penjual sebelum melakukan transfer.</p>
                @endforelse
            @elseif($order->payment_method === \App\Enums\PaymentMethod::Qris)
                <h3>Bayar dengan QRIS</h3>
                @if($qrisImage)
                    <img class="payment-qris-image" src="{{ \Illuminate\Support\Str::startsWith($qrisImage, ['http://', 'https://']) ? $qrisImage : asset($qrisImage) }}" alt="Kode QRIS MoMa.id">
                @else
                    <p class="buyer-flash-error">Gambar QRIS belum dikonfigurasi. Silakan hubungi penjual sebelum melakukan pembayaran.</p>
                @endif
            @endif

            @if($payment?->proof_path)
                <p>Bukti terakhir: <a href="{{ route('payments.proof', $payment) }}">Unduh bukti pembayaran</a></p>
            @endif
            @if(in_array($order->payment_status->value, ['unpaid', 'failed'], true) && $order->payment_expires_at?->isFuture())
                @if($payment?->note)
                    <p class="buyer-flash-error">Catatan verifikasi: {{ $payment->note }}</p>
                @endif
                <form class="payment-proof-form" method="POST" action="{{ route('orders.payments.upload', $order) }}" enctype="multipart/form-data">
                    @csrf
                    <label for="proof">Unggah bukti pembayaran (JPG, PNG, atau PDF; maks. 2 MB)</label>
                    <input id="proof" name="proof" type="file" accept=".jpg,.jpeg,.png,.pdf,image/jpeg,image/png,application/pdf" required>
                    @error('proof')<small class="buyer-field-error">{{ $message }}</small>@enderror
                    <button class="buyer-primary-button" type="submit">Kirim bukti pembayaran</button>
                </form>
            @elseif($order->payment_status->value === 'waiting_verification')
                <p class="buyer-checkout-note">Bukti diterima. Admin akan memeriksa pembayaran sebelum pesanan dikirim ke penjual.</p>
            @elseif($order->payment_status->value === 'paid')
                <p class="buyer-flash-success">Pembayaran terverifikasi. Pesanan sekarang menunggu konfirmasi penjual.</p>
                <a class="buyer-primary-button" href="{{ route('orders.show', $order) }}">Lihat pesanan</a>
            @elseif($order->payment_status->value === 'expired')
                <p class="buyer-flash-error">Batas pembayaran telah berakhir dan pesanan dibatalkan.</p>
            @endif
        </section>
        <aside class="buyer-summary">
            <h2>Rincian biaya</h2>
            <div class="buyer-summary-item"><span>Subtotal</span><strong>Rp {{ number_format($order->subtotal, 0, ',', '.') }}</strong></div>
            <div class="buyer-summary-item"><span>Ongkir</span><strong>Rp {{ number_format($order->shipping_cost, 0, ',', '.') }}</strong></div>
            @if($order->discount_amount > 0)<div class="buyer-summary-item"><span>Diskon voucher</span><strong>- Rp {{ number_format($order->discount_amount, 0, ',', '.') }}</strong></div>@endif
            <div class="buyer-summary-total"><span>Total bayar</span><strong>Rp {{ number_format($order->grand_total, 0, ',', '.') }}</strong></div>
        </aside>
    </div>
</div>
@endsection
