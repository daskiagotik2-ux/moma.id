@extends('layouts.app')

@section('title', 'Flash Sale MoMa.id')

@section('content')
<div class="flash-sale-page">
    <nav class="flash-sale-breadcrumb" aria-label="Breadcrumb">
        <a href="{{ route('home') }}">Beranda</a>
        <i class="fa-solid fa-chevron-right"></i>
        <span>Flash Sale</span>
    </nav>

    @if (session('error'))
        <p class="buyer-flash-error" role="alert">{{ session('error') }}</p>
    @endif

    <section class="flash-sale-hero">
        <div class="flash-sale-hero-copy">
            <span class="flash-sale-kicker"><i class="fa-solid fa-bolt"></i> PROMO TERBATAS</span>
            <h1>Flash Sale MoMa.id</h1>
            <p>Promo terbatas, harga spesial, jangan sampai kehabisan!</p>
            <div class="flash-sale-countdown" aria-label="Waktu sisa Flash Sale">
                <div><strong id="flash-days">05</strong><span>Hari</span></div>
                <i>:</i>
                <div><strong id="flash-hours">23</strong><span>Jam</span></div>
                <i>:</i>
                <div><strong id="flash-minutes">41</strong><span>Menit</span></div>
                <i>:</i>
                <div><strong id="flash-seconds">12</strong><span>Detik</span></div>
            </div>
        </div>
        <div class="flash-sale-hero-art" aria-hidden="true">
            <span class="flash-sale-orbit orbit-one"></span>
            <span class="flash-sale-orbit orbit-two"></span>
            <div><strong>DISKON</strong><b>30%</b><small>UNTIL SALE</small></div>
        </div>
    </section>

    <section class="flash-sale-content">
        <div class="flash-sale-section-heading">
            <div>
                <span>PRODUK TERPILIH</span>
                <h2>Berita Berkendara</h2>
            </div>
            <div class="flash-sale-live"><i></i> Sale aktif</div>
        </div>

        @if($products->isNotEmpty())
            <div class="flash-sale-grid">
                @foreach($products as $product)
                    <article class="flash-sale-card">
                        <div class="flash-sale-image">
                            @if($product['image'])
                                <img src="https://images.unsplash.com/{{ $product['image'] }}?auto=format&fit=crop&w=700&q=80" alt="{{ $product['name'] }}" loading="lazy">
                            @else
                                <div class="flash-sale-image-placeholder"><i class="fa-solid fa-box-open"></i></div>
                            @endif
                            <span class="flash-sale-badge"><i class="fa-solid fa-bolt"></i> FLASH SALE</span>
                            <span class="flash-sale-discount">-{{ $product['discount'] }}%</span>
                        </div>

                        <div class="flash-sale-card-body">
                            <div class="flash-sale-seller">{{ $product['seller'] }} <span>•</span> {{ $product['location'] }}</div>
                            <h3>{{ $product['name'] }}</h3>
                            <div class="flash-sale-price">
                                <del>Rp {{ number_format($product['normal_price'], 0, ',', '.') }}</del>
                                <strong>Rp {{ number_format($product['sale_price'], 0, ',', '.') }}</strong>
                            </div>
                            <div class="flash-sale-rating">
                                <span class="flash-sale-stars">@for($star = 1; $star <= 5; $star++)<i class="fa-solid fa-star {{ $star <= (int) round($product['rating']) ? 'filled' : '' }}"></i>@endfor</span>
                                <span>{{ number_format($product['rating'], 1) }}</span>
                                <small>({{ number_format($product['review_count']) }} ulasan)</small>
                            </div>
                            <div class="flash-sale-sales">
                                <div><span>{{ $product['sold'] }} terjual</span><span>{{ $product['progress'] }}% terjual</span></div>
                                <div class="flash-sale-progress"><span style="width: {{ $product['progress'] }}%"></span></div>
                            </div>
                            @if($product['slug'])
                                <form method="POST" action="{{ route('cart.add', $product['slug']) }}">
                                    @csrf
                                    <input type="hidden" name="quantity" value="1">
                                    <input type="hidden" name="flash_sale_item_id" value="{{ $product['flash_sale_item_id'] }}">
                                    <input type="hidden" name="redirect_to" value="checkout">
                                    <button class="flash-sale-buy" type="submit"><i class="fa-solid fa-cart-plus"></i> Beli Sekarang</button>
                                </form>
                            @else
                                <button class="flash-sale-buy" type="button" disabled title="Produk contoh belum tersedia untuk dibeli"><i class="fa-solid fa-cart-plus"></i> Belum tersedia</button>
                            @endif
                        </div>
                    </article>
                @endforeach
            </div>
        @else
            <div class="flash-sale-empty">
                <i class="fa-solid fa-box-open"></i>
                <h3>Flash Sale sedang disiapkan</h3>
                <p>Produk baru akan tersedia segera.</p>
            </div>
        @endif
    </section>
</div>
@endsection
