<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sesi Berakhir | MoMa.id</title>
    <style>
        :root { color-scheme: light; font-family: Inter, "Segoe UI", sans-serif; color: #4A171D; background: #F3F0EF; }
        * { box-sizing: border-box; }
        body { display: grid; min-height: 100vh; margin: 0; padding: 24px; place-items: center; }
        main { width: min(100%, 480px); padding: 36px; border: 1px solid #eadfdd; border-radius: 20px; background: #fff; box-shadow: 0 18px 50px rgba(74, 23, 29, .08); text-align: center; }
        .mark { display: grid; width: 54px; height: 54px; margin: 0 auto 20px; place-items: center; border-radius: 16px; background: #FFF4F1; color: #B91C2B; font-size: 23px; font-weight: 800; }
        h1 { margin: 0; font-size: 24px; line-height: 1.3; }
        p { margin: 10px 0 24px; color: #6b6b6b; font-size: 14px; line-height: 1.65; }
        nav { display: flex; flex-wrap: wrap; justify-content: center; gap: 10px; }
        a { display: inline-flex; min-height: 44px; align-items: center; justify-content: center; padding: 0 18px; border: 1px solid #e5e5e5; border-radius: 10px; color: #4A171D; font-size: 13px; font-weight: 700; text-decoration: none; }
        a:first-child { border-color: #B91C2B; background: #B91C2B; color: #fff; }
        a:focus-visible { outline: 3px solid rgba(185, 28, 43, .25); outline-offset: 3px; }
        @media (max-width: 480px) { main { padding: 28px 22px; } h1 { font-size: 21px; } nav { flex-direction: column; } }
    </style>
</head>
<body>
    <main>
        <div class="mark" aria-hidden="true">M</div>
        <h1>Sesi Anda telah berakhir</h1>
        <p>Halaman terlalu lama terbuka atau token keamanan sudah kedaluwarsa. Masuk kembali untuk melanjutkan dengan aman.</p>
        <nav aria-label="Tindakan">
            <a href="{{ route('login') }}">Masuk kembali</a>
            <a href="{{ route('home') }}">Ke beranda</a>
        </nav>
    </main>
</body>
</html>