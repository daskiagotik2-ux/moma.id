@extends('layouts.app')

@section('title', $categoryLabel.' | MoMa.id')

@section('content')
    <div class="category-placeholder-page">
        <nav class="category-breadcrumb" aria-label="Breadcrumb">
            <a href="{{ route('home') }}">Beranda</a>
            <i class="fa-solid fa-chevron-right"></i>
            <a href="{{ route('category', 'semua') }}">Semua Kategori</a>
            <i class="fa-solid fa-chevron-right"></i>
            <span>{{ $categoryLabel }}</span>
        </nav>

        <section class="category-placeholder-card">
            <span class="category-placeholder-icon"><i class="fa-solid fa-box-open"></i></span>
            <span class="category-placeholder-kicker">KATEGORI DALAM PENGEMBANGAN</span>
            <h1>{{ $categoryLabel }}</h1>
            <p>Kategori ini sedang disiapkan untuk katalog produk berikutnya. Kembali ke Semua Kategori untuk menjelajah penawaran yang tersedia.</p>
            <div class="category-placeholder-actions">
                <a href="{{ route('category', 'semua') }}" class="category-placeholder-primary"><i class="fa-solid fa-arrow-left"></i> Kembali ke kategori</a>
                <a href="{{ route('products') }}" class="category-placeholder-secondary">Lihat semua produk</a>
            </div>
        </section>
    </div>
@endsection
