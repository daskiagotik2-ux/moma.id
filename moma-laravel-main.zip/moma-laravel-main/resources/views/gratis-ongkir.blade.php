@extends('layouts.app')

@section('title', 'Promo Gratis Ongkir | Nusantara Mart')

@section('content')
    <main class="gratis-page">
        <div class="gratis-hero">
            <div class="gratis-hero-copy">
                <div class="gratis-kicker"><i class="fa-solid fa-gift"></i> Promo spesial</div>
                <h1>Gratis Ongkir<br><span>tanpa ribet.</span></h1>
                <p>Gunakan kode promo untuk menambah nilai belanja tanpa biaya tambahan. Promo berlaku untuk semua kategori marketplace.</p>
                <div class="gratis-hero-actions">
                    <a href="#voucher" class="gratis-primary-button"><i class="fa-solid fa-tag"></i> Lihat promo</a>
                    <span><i class="fa-solid fa-clock"></i> Berlaku sampai 31 Desember</span>
                </div>
            </div>
            <div class="gratis-hero-art" aria-hidden="true">
                <div class="gratis-orbit orbit-one"></div>
                <div class="gratis-orbit orbit-two"></div>
                <div class="gratis-gift-card">
                    <span>DISKON</span>
                    <strong>ONGKIR</strong>
                    <small> GRATIS</small>
                    <i class="fa-solid fa-gift"></i>
                </div>
                <div class="gratis-spark spark-one"><i class="fa-solid fa-sparkles"></i></div>
                <div class="gratis-spark spark-two"><i class="fa-solid fa-sparkles"></i></div>
            </div>
        </div>

        <section class="gratis-voucher-section" id="voucher">
            <div class="gratis-section-heading">
                <div>
                    <span>Voucher pilihan</span>
                    <h2>Voucher <strong>Gratis Ongkir</strong></h2>
                </div>
                <p>Minimum belanja berbeda-beda sesuai voucher. Klik kode untuk menyalinnya.</p>
            </div>

            <div class="gratis-voucher-grid">
                @foreach ($vouchers as $voucher)
                    <article class="gratis-voucher-card voucher-{{ $voucher['accent'] }}">
                        <div class="voucher-topline">
                            <span>{{ $voucher['label'] }}</span>
                            <i class="fa-solid fa-tag"></i>
                        </div>
                        <div class="voucher-code" data-voucher-code="{{ $voucher['code'] }}">{{ $voucher['code'] }}</div>
                        <div class="voucher-details">
                            <span>Minimum belanja</span>
                            <strong>{{ $voucher['minimum'] > 0 ? 'Rp'.number_format($voucher['minimum']) : 'Tanpa minimum' }}</strong>
                        </div>
                        <div class="voucher-footer">
                            <span><i class="fa-regular fa-calendar"></i> {{ $voucher['valid_until'] }}</span>
                            <form action="{{ route('voucher.claim') }}" method="POST" data-voucher-claim>
                                @csrf
                                <input type="hidden" name="code" value="{{ $voucher['code'] }}">
                                <button type="submit" class="voucher-claim" data-copy-voucher="{{ $voucher['code'] }}">Salin kode</button>
                            </form>
                        </div>
                        <p class="gratis-voucher-claim-status" role="status" aria-live="polite"></p>
                    </article>
                @endforeach
            </div>
        </section>

        <section class="gratis-product-section">
            <div class="gratis-section-heading">
                <div>
                    <span>Rekomendasi pilihan</span>
                    <h2>Temukan penawaran favoritmu</h2>
                </div>
                <a href="{{ route('shop') }}">Lihat semua produk <i class="fa-solid fa-arrow-right"></i></a>
            </div>

            <div class="gratis-product-grid">
                @foreach ($products as $product)
                    <article class="gratis-product-card">
                        <div class="gratis-product-image">
                            @if ($product['image'])
                                <img src="https://images.unsplash.com/{{ $product['image'] }}?auto=format&fit=crop&w=700&q=80" alt="{{ $product['name'] }}" loading="lazy">
                            @else
                                <div class="gratis-product-placeholder"><i class="fa-solid fa-box"></i></div>
                            @endif
                            <span class="gratis-product-category">{{ $product['category'] }}</span>
                            <span class="gratis-product-saving">Hemat {{ number_format($product['old_price'] - $product['price']) }}</span>
                        </div>
                        <div class="gratis-product-body">
                            <div class="gratis-product-seller">{{ $product['seller'] }} · {{ $product['location'] }}</div>
                            <h3>{{ $product['name'] }}</h3>
                            <div class="gratis-product-price">
                                <strong>Rp{{ number_format($product['price']) }}</strong>
                                <del>Rp{{ number_format($product['old_price']) }}</del>
                            </div>
                            <div class="gratis-product-meta">
                                <span><i class="fa-solid fa-star"></i> {{ $product['rating'] }}</span>
                                <span><i class="fa-solid fa-bag-shopping"></i> 1 item</span>
                            </div>
                            <a href="{{ route('shop') }}" class="gratis-product-link">Lihat produk <i class="fa-solid fa-arrow-right"></i></a>
                        </div>
                    </article>
                @endforeach
            </div>
        </section>

        <section class="gratis-note">
            <i class="fa-solid fa-circle-info"></i>
            <div>
                <strong>Syarat & ketentuan</strong>
                <p>Voucher berlaku untuk pembelian minimal seperti yang tercantum. Kode hanya dapat dipakai satu kali per akun dan tidak dapat ditukar menjadi uang.</p>
            </div>
        </section>
    </main>
@endsection
