@props(['product'])

<a class="market-product-card" href="{{ route('products.show', $product->slug) }}">
    <span class="product-image">
        <img src="{{ $product->image }}" alt="{{ $product->name }}" loading="lazy" data-image-fallback>
        <span class="product-image-fallback" hidden aria-hidden="true"><i class="fa-solid fa-box-open"></i></span>
        @if ($product->discount_percent > 0)
            <b>-{{ $product->discount_percent }}%</b>
        @endif
    </span>
    <span class="product-copy">
        <strong>{{ $product->name }}</strong>
        <small>{{ $product->category?->name }} · {{ $product->seller }}</small>
        <span class="product-rating">
            @if ($product->review_count > 0)
                <i class="fa-solid fa-star"></i> {{ number_format($product->rating, 1, ',', '.') }} · {{ number_format($product->review_count, 0, ',', '.') }} ulasan
            @else
                Belum ada ulasan
            @endif
        </span>
        <span class="product-price">
            <b>{{ $product->formatted_price }}</b>
            @if ($product->old_price)
                <del>{{ $product->formatted_old_price }}</del>
            @endif
        </span>
    </span>
</a>