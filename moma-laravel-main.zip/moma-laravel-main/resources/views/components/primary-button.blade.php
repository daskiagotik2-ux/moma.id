<button {{ $attributes->merge(['type' => 'submit', 'class' => 'inline-flex min-h-12 w-full items-center justify-center gap-2 rounded-xl bg-brand-600 px-5 py-3 text-sm font-semibold text-white shadow-sm transition duration-150 hover:bg-brand-700 hover:shadow-md focus:outline-none focus:ring-4 focus:ring-brand-100 active:bg-brand-800 disabled:cursor-not-allowed disabled:opacity-50 sm:w-auto']) }}>
    {{ $slot }}
</button>
