@props([
    'activeRoute' => null,
    'user' => null,
])

@php
    $currentRoute = $activeRoute ?? request()->route()?->getName();
    $accounts = $user ?? auth()->user();
    $store = $accounts?->store;
    $menuGroups = [
        'BELANJA' => [
            ['label' => 'Semua Produk', 'route' => 'products', 'icon' => 'boxes'],
            ['label' => 'Kategori Produk', 'route' => 'category', 'params' => ['category' => 'semua'], 'icon' => 'tags'],
            ['label' => 'Produk Favorit', 'route' => 'wishlist', 'icon' => 'heart'],
        ],
        'TRANSAKSI' => [
            ['label' => 'Riwayat Pesanan', 'route' => 'orders', 'icon' => 'shopping-bag'],
        ],
        'BANTUAN' => [
            ['label' => 'Pusat Bantuan', 'route' => 'help', 'icon' => 'circle-help'],
        ],
        'AKUN' => [
            ['label' => 'Akun Saya', 'route' => 'dashboard', 'icon' => 'user-round'],
            ['label' => 'Pengaturan Akun', 'route' => 'profile.edit', 'icon' => 'settings'],
        ],
    ];

    $menuGroups[$store ? 'TOKO' : 'PENJUAL'] = [[
        'label' => $store ? 'Toko Saya' : 'Mulai berjualan',
        'route' => $store ? 'seller.dashboard' : 'stores.create',
        'icon' => 'store',
    ]];
@endphp

<div x-data="{ open: false, dark: localStorage.getItem('moma-theme') === 'dark' || (!localStorage.getItem('moma-theme') && window.matchMedia('(prefers-color-scheme: dark)').matches) }"
     x-effect="localStorage.setItem('moma-theme', dark ? 'dark' : 'light'); document.documentElement.classList.toggle('dark', dark)"
     x-on:keydown.escape="open = false"
     class="marketplace-sidebar-shell">
    <button type="button"
            x-on:click="open = true"
            class="marketplace-sidebar-trigger lg:hidden"
            aria-label="Buka navigasi akun">
        <i data-lucide="menu" class="h-5 w-5"></i>
    </button>

    <div x-show="open"
         x-cloak
         x-transition:enter="transition duration-200 ease-out"
         x-transition:enter-start="opacity-0"
         x-transition:enter-end="opacity-100"
         x-transition:leave="transition duration-200 ease-in"
         x-transition:leave-start="opacity-100"
         x-transition:leave-end="opacity-0"
         class="marketplace-sidebar-overlay lg:hidden"
         x-on:click="open = false"
         aria-hidden="true"></div>

    <aside x-bind:class="open ? 'marketplace-sidebar-open' : ''"
            class="marketplace-sidebar {{ $accounts ? 'marketplace-sidebar-authenticated' : '' }}"
            aria-label="Navigasi akun MoMa.id">
        <div class="marketplace-sidebar-brand">
            <a href="{{ route('home') }}" class="flex items-center gap-3" aria-label="MoMa.id beranda">
                <x-moma-logo class="h-10 w-10 shrink-0" />
                <span class="text-[22px] font-black tracking-[-0.04em] text-slate-950 dark:text-white">
                    MoMa<span class="text-brand-600">.id</span>
                </span>
            </a>
            <button type="button"
                    x-on:click="open = false"
                    class="marketplace-sidebar-close lg:hidden"
                    aria-label="Tutup navigasi">
                <i data-lucide="x" class="h-5 w-5"></i>
            </button>
        </div>

        @if($accounts)
            <div class="marketplace-account-card">
                <div class="marketplace-account-avatar">
                    {{ strtoupper(substr($accounts->name, 0, 1)) }}
                </div>
                <div class="min-w-0 flex-1">
                    <p class="truncate text-sm font-extrabold text-slate-950 dark:text-white">{{ $accounts->name }}</p>
                    <p class="truncate text-[11px] font-medium text-slate-500 dark:text-slate-400">{{ $accounts->email }}</p>
                </div>
            </div>
        @else
            <a href="{{ route('register') }}" class="marketplace-account-guest">
                <span class="marketplace-account-avatar">M</span>
                <span><strong>Selamat datang</strong><small>Daftar untuk membuat akun</small></span>
            </a>
        @endif

        <div class="marketplace-sidebar-scroll">
            <nav class="marketplace-sidebar-nav" aria-label="Navigasi utama">
                @foreach($menuGroups as $group => $items)
                    <div class="marketplace-menu-group">
                        <p class="marketplace-menu-heading">{{ $group }}</p>
                        <div class="marketplace-menu-card">
                            @foreach($items as $item)
                                @php
                                    $isActive = Str::contains($currentRoute, $item['route'])
                                        || ($item['route'] === 'dashboard' && request()->routeIs('dashboard'))
                                        || ($item['route'] === 'profile.edit' && request()->routeIs('profile.edit'));
                                @endphp
                                <a href="{{ route($item['route'], $item['params'] ?? []) }}"
                                   class="marketplace-menu-link {{ $isActive ? 'marketplace-menu-link-active' : '' }}"
                                   @if($isActive) aria-current="page" @endif>
                                    <span class="marketplace-menu-icon"><i data-lucide="{{ $item['icon'] }}"></i></span>
                                    <span class="marketplace-menu-label">{{ $item['label'] }}</span>
                                    @if(isset($item['badge']))
                                        <span class="marketplace-menu-badge">{{ $item['badge'] }}</span>
                                    @endif
                                </a>
                            @endforeach
                        </div>
                    </div>
                @endforeach
            </nav>

        </div>

        <div class="marketplace-sidebar-footer">
            <a href="{{ route('help') }}" class="marketplace-quick-action">
                <span class="marketplace-quick-action-icon"><i data-lucide="circle-help"></i></span>
                <span><strong>Pusat bantuan</strong><small>Butuh bantuan? Kunjungi pusat bantuan.</small></span>
                <i data-lucide="arrow-up-right" class="ml-auto h-4 w-4"></i>
            </a>

            <div class="marketplace-sidebar-bottom-actions">
                <button type="button"
                        x-on:click="dark = !dark"
                        x-bind:aria-pressed="dark"
                        class="marketplace-theme-toggle"
                        aria-label="Ganti mode warna">
                    <i data-lucide="moon" class="dark:hidden"></i>
                    <i data-lucide="sun" class="hidden dark:block"></i>
                    <span class="dark:hidden">Mode gelap</span>
                    <span class="hidden dark:block">Mode terang</span>
                </button>
                @if($accounts && !request()->routeIs('dashboard'))
                    <form method="POST" action="{{ route('logout') }}" class="marketplace-logout-form">
                        @csrf
                        <button type="submit" class="marketplace-logout-button">
                            <i data-lucide="log-out"></i>
                            <span>Logout</span>
                        </button>
                    </form>
                @endif
            </div>
        </div>
    </aside>
</div>
