@props(['disabled' => false])

<input @disabled($disabled) {{ $attributes->merge(['class' => 'form-input w-full min-h-12 rounded-xl border border-gray-300 bg-white px-4 py-3 text-sm text-gray-900 shadow-sm outline-none transition placeholder:text-gray-400 focus:border-brand-600 focus:ring-4 focus:ring-brand-100 disabled:cursor-not-allowed disabled:bg-gray-50']) }}>
