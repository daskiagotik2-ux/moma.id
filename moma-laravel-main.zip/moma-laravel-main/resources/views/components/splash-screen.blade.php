<div
    id="moma-splash"
    class="moma-splash"
    role="dialog"
    aria-label="Memuat MoMa.id"
    aria-live="polite"
    aria-modal="true"
    tabindex="-1"
    :class="{ 'moma-splash-leaving': closed }"
    x-data="{
        closed: false,
        timer: null,
        close() {
            if (this.closed) return;
            this.closed = true;
            window.clearTimeout(this.timer);
            sessionStorage.setItem('moma-splash-seen', '1');

            window.setTimeout(() => {
                document.getElementById('moma-splash')?.remove();
                document.documentElement.classList.remove('moma-splash-active');
                document.getElementById('main-content')?.focus({ preventScroll: true });
            }, 300);
        }
    }"
    x-init="
        if (sessionStorage.getItem('moma-splash-seen') === '1') {
            document.documentElement.classList.remove('moma-splash-active');
            $el.remove();
        } else {
            $nextTick(() => $el.querySelector('[data-splash-skip]')?.focus({ preventScroll: true }));
            timer = window.setTimeout(() => close(), window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 1000 : 2200);
        }
    "
    @keydown.escape.window="close()"
>
    <button class="moma-splash-skip" type="button" data-splash-skip @click="close()">Lewati</button>
    <div class="moma-splash-content">
        <x-moma-logo variant="white" class="moma-splash-mark" />
        <p class="moma-splash-wordmark">MoMa.id</p>
        <p class="moma-splash-tagline">Belanja Lokal, Bangga Indonesia</p>
    </div>
    <div class="moma-splash-footer" aria-hidden="true">
        <span class="moma-splash-indicator"><i></i><i></i><i></i></span>
        <span>UMKM Indonesia dalam satu aplikasi</span>
    </div>
</div>
