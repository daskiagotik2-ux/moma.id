@props(['variant' => 'color'])

<svg viewBox="0 0 52 58" fill="none" {{ $attributes->merge(['role' => 'img', 'aria-label' => 'Logo MoMa.id']) }}>
	@if ($variant === 'white')
		<path d="M16 19v-4a10 10 0 0 1 20 0v4M11 19h30a4 4 0 0 1 4 4v27a5 5 0 0 1-5 5H12a5 5 0 0 1-5-5V23a4 4 0 0 1 4-4Z" stroke="white" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
		<text x="26" y="43" fill="white" font-family="Arial, sans-serif" font-size="23" font-weight="800" text-anchor="middle">M</text>
	@else
		<path d="M18 20v-5a8 8 0 0 1 16 0v5M13 20h26a4 4 0 0 1 4 4v25a5 5 0 0 1-5 5H14a5 5 0 0 1-5-5V24a4 4 0 0 1 4-4Z" fill="#B91C2B" stroke="#B91C2B" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"/>
		<text x="26" y="43" fill="white" font-family="Arial, sans-serif" font-size="23" font-weight="800" text-anchor="middle">M</text>
	@endif
</svg>
