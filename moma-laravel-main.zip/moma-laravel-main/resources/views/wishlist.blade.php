@extends('layouts.app')

@section('title', 'Wishlist | MoMa.id')

@section('content')
<div class="buyer-page">
    <header class="buyer-page-heading"><span>AKUN PEMBELI</span><h1>Wishlist</h1><p>Produk yang Anda simpan untuk dilihat kembali.</p></header>
    @if (session('success')) <p class="buyer-flash-success" role="status">{{ session('success') }}</p> @endif
    @if ($products->isEmpty())
        <section class="buyer-empty-state"><i class="fa-regular fa-heart" aria-hidden="true"></i><h2>Wishlist masih kosong</h2><p>Simpan produk dari halaman detail untuk menemukannya lagi.</p><a class="buyer-primary-button" href="{{ route('products') }}">Jelajahi produk</a></section>
    @else
        <div class="market-product-grid">
            @foreach ($products as $product)
                <div class="buyer-wishlist-item">
                    <x-product-card :product="$product" />
                    <form method="POST" action="{{ route('wishlist.toggle', $product->slug) }}">
                        @csrf
                        <button class="buyer-wishlist-remove" type="submit"><i class="fa-regular fa-trash-can"></i> Hapus dari wishlist</button>
                    </form>
                </div>
            @endforeach
        </div>
        {{ $products->links() }}
    @endif
</div>
@endsection