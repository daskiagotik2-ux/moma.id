@extends('layouts.app')

@section('title', $store->store_name.' | MoMa.id')

@section('content')
<div class="seller-shell seller-public-page">
    <main class="seller-main">
        <a class="seller-button seller-button-secondary mb-4" href="{{ route('products') }}"><i class="fa-solid fa-arrow-left"></i> Kembali ke marketplace</a>
        <header class="seller-public-header">
            <span class="seller-eyebrow text-white">TOKO UMKM MoMa.ID</span>
            <h1>{{ $store->store_name }}</h1>
            <p>{{ $store->description ?: 'Produk pilihan dari usaha lokal.' }}</p>
            <div class="seller-public-meta"><span><i class="fa-solid fa-tag"></i> {{ $store->category }}</span><span><i class="fa-solid fa-location-dot"></i> {{ $store->address }}</span></div>
        </header>
        <section class="seller-panel">
            <div class="seller-panel-heading"><h2>Produk dari toko ini</h2><span class="text-xs text-gray-500">{{ $products->total() }} produk</span></div>
            @if($products->isEmpty())<div class="seller-empty">Toko ini belum memiliki produk yang tersedia.</div>
            @else
                <div class="seller-store-products">
                    @foreach($products as $product)
                        <article class="seller-store-product">
                            <a href="{{ route('products.show', $product->slug) }}" class="seller-store-product-image"><img src="{{ $product->image }}" alt="{{ $product->name }}" loading="lazy"></a>
                            <div class="seller-store-product-copy">
                                <span>{{ $product->category?->name }}</span>
                                <h3><a href="{{ route('products.show', $product->slug) }}">{{ $product->name }}</a></h3>
                                <strong>Rp {{ number_format($product->price, 0, ',', '.') }}</strong>
                                <small>Stok: {{ $product->stock === null ? 'Hubungi toko' : number_format($product->stock, 0, ',', '.') }}</small>
                                <a class="seller-button seller-button-secondary" href="{{ route('products.show', $product->slug) }}">Lihat detail produk</a>
                            </div>
                        </article>
                    @endforeach
                </div>
                <div class="seller-pagination">{{ $products->links() }}</div>
            @endif
        </section>
    </main>
</div>
@endsection