@extends('layouts.app')

@section('title', 'Voucher Saya | MoMa.id')

@section('content')
    <div class="voucher-page">
        <section class="voucher-hero">
            <div class="voucher-hero-copy">
                <span class="voucher-eyebrow"><i class="fa-solid fa-ticket"></i> Voucher Marketplace</span>
                <h1>Voucher Saya</h1>
                <p>Gunakan voucher untuk mendapatkan harga terbaik.</p>
                <div class="voucher-hero-meta">
                    <span><i class="fa-solid fa-shield-heart"></i> Aman & terpercaya</span>
                    <span><i class="fa-regular fa-clock"></i> Berlaku sesuai periode di setiap voucher</span>
                </div>
            </div>
            <div class="voucher-hero-art" aria-hidden="true">
                <div class="voucher-orbit orbit-one"></div>
                <div class="voucher-orbit orbit-two"></div>
                <div class="voucher-ticket-art">
                    <span>MO</span>
                    <strong>MA</strong>
                    <i class="fa-solid fa-ticket"></i>
                </div>
            </div>
        </section>

        <section class="voucher-market-section">
            <div class="voucher-section-heading">
                <div>
                    <span class="voucher-section-kicker">PENAWARAN TERKINI</span>
                    <h2>Temukan voucher favoritmu</h2>
                </div>
                <p>Gunakan kode promo saat checkout untuk mendapatkan keuntungan terbaik.</p>
            </div>

            <div class="voucher-tabs" role="tablist" aria-label="Filter voucher">
                @php($tabs = [
                    ['semua', 'Semua'],
                    ['gratis-ongkir', 'Gratis Ongkir'],
                    ['diskon', 'Diskon'],
                    ['cashback', 'Cashback'],
                ])
                @foreach($tabs as $tab)
                    <a class="voucher-tab {{ $filter === $tab[0] ? 'active' : '' }}"
                       href="{{ route('voucher', ['filter' => $tab[0]]) }}"
                       role="tab" aria-selected="{{ $filter === $tab[0] ? 'true' : 'false' }}">
                        {{ $tab[1] }}
                    </a>
                @endforeach
            </div>

            @if(session('success'))
                <p class="voucher-feedback" role="status">{{ session('success') }}</p>
            @endif

            @if($vouchers->isNotEmpty())
                <div class="voucher-grid">
                    @foreach($vouchers as $voucher)
                        <article class="voucher-card voucher-card-{{ $voucher['accent'] }}">
                            <div class="voucher-card-cut"></div>
                            <div class="voucher-card-top">
                                <div>
                                    <span class="voucher-card-label">{{ $voucher['label'] }}</span>
                                    <h3>{{ $voucher['title'] }}</h3>
                                </div>
                                <span class="voucher-card-icon"><i class="fa-solid {{ $voucher['icon'] }}"></i></span>
                            </div>

                            <div class="voucher-card-value">
                                @if($voucher['is_percentage'])
                                    <strong>{{ $voucher['amount'] }}%</strong>
                                @else
                                    <strong>Rp{{ number_format($voucher['amount']) }}</strong>
                                @endif
                                <span>Minimum belanja {{ $voucher['minimum'] > 0 ? 'Rp'.number_format($voucher['minimum']) : 'tanpa minimum' }}</span>
                            </div>

                            <p>{{ $voucher['description'] }}</p>

                            <div class="voucher-code-row">
                                <div>
                                    <span>Kode</span>
                                    <strong>{{ $voucher['code'] }}</strong>
                                </div>
                                <form action="{{ route('voucher.claim') }}" method="POST" data-voucher-claim>
                                    @csrf
                                    <input type="hidden" name="code" value="{{ $voucher['code'] }}">
                                    <button type="submit" class="voucher-use-button" data-copy-voucher="{{ $voucher['code'] }}">
                                        <i class="fa-regular fa-copy"></i> Gunakan
                                    </button>
                                </form>
                            </div>

                            <div class="voucher-card-footer">
                                <span><i class="fa-regular fa-calendar"></i> Berlaku sampai {{ $voucher['valid_until'] }}</span>
                                <span class="voucher-status">Aktif</span>
                            </div>
                            <p class="voucher-claim-status" role="status" aria-live="polite"></p>
                        </article>
                    @endforeach
                </div>
            @else
                <div class="voucher-empty">
                    <i class="fa-solid fa-ticket"></i>
                    <h3>Voucher belum tersedia</h3>
                    <p>Silakan coba kategori lain untuk melihat penawaran terbaru.</p>
                </div>
            @endif
        </section>

        <section class="voucher-popular-section">
            <div class="voucher-section-heading compact">
                <div>
                    <span class="voucher-section-kicker">DIPILIH PENGGUNA</span>
                    <h2>Voucher Pilihan</h2>
                </div>
                <a href="{{ route('voucher') }}">Lihat semua voucher <i class="fa-solid fa-arrow-right"></i></a>
            </div>

            <div class="voucher-popular-grid">
                @foreach($popularVouchers as $voucher)
                    <a class="voucher-popular-card" href="{{ route('voucher', ['filter' => $voucher['category']]) }}">
                        <span class="popular-icon"><i class="fa-solid {{ $voucher['icon'] }}"></i></span>
                        <span><small>{{ $voucher['label'] }}</small><strong>{{ $voucher['title'] }}</strong></span>
                        <i class="fa-solid fa-arrow-right"></i>
                    </a>
                @endforeach
            </div>
        </section>
    </div>
@endsection
