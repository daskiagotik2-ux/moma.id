@extends('layouts.app')

@section('title', 'Semua Kategori | MoMa.id')

@section('content')
    @php
        $categoryIcons = [
            'makanan-minuman' => 'fa-utensils',
            'fashion' => 'fa-shirt',
            'kerajinan-tangan' => 'fa-palette',
            'kecantikan-perawatan' => 'fa-spa',
            'elektronik' => 'fa-headphones',
            'rumah-dapur' => 'fa-house',
            'olahraga-hobi' => 'fa-futbol',
            'buku-alat-tulis' => 'fa-book-open',
            'otomotif' => 'fa-car',
            'lainnya' => 'fa-shapes',
        ];
    @endphp
    <div class="category-page">
        <nav class="category-breadcrumb" aria-label="Breadcrumb">
            <a href="{{ route('home') }}">Beranda</a>
            <i class="fa-solid fa-chevron-right"></i>
            <span>Semua Kategori</span>
        </nav>

        <section class="category-hero">
            <div>
                <span class="category-eyebrow"><i class="fa-solid fa-grid-2"></i> Katalog MoMa.id</span>
                <h1>Semua Kategori</h1>
                <p>Jelajahi produk UMKM berdasarkan kategori yang sesuai dengan kebutuhanmu.</p>
            </div>
            <div class="category-hero-stat">
                <strong>{{ count($categories) }}</strong>
                <span>Kategori<br>produk</span>
            </div>
        </section>

        <section class="category-list-section">
            <div class="category-list-heading">
                <div>
                    <span>KATEGORI PRODUK</span>
                    <h2>Pilih sesuai kebutuhan</h2>
                </div>
                <p>Setiap kategori menampilkan produk yang sudah tersedia di marketplace.</p>
            </div>

            <div class="category-grid">
                @foreach($categories as $category)
                    <a class="category-card category-card--{{ $category->slug }}"
                       href="{{ route('category', $category->slug) }}"
                       aria-label="Buka kategori {{ $category->name }}">
                        <span class="category-card-icon" aria-hidden="true">
                            @if(isset($categoryIcons[$category->slug]))
                                <i class="fa-solid {{ $categoryIcons[$category->slug] }}"></i>
                            @else
                                {{ $category->icon ?? '▦' }}
                            @endif
                        </span>
                        <span class="category-card-copy">
                            <strong>{{ $category->name }}</strong>
                            <small>{{ number_format($category->products_count, 0, ',', '.') }} produk tersedia</small>
                        </span>
                        <span class="category-card-arrow"><i class="fa-solid fa-arrow-right"></i></span>
                    </a>
                @endforeach
            </div>
        </section>
    </div>
@endsection
