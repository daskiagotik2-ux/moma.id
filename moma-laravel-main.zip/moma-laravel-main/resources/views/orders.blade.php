@extends('layouts.app')

@section('title', 'Pesanan Saya | MoMa.id')

@section('content')
<div class="buyer-page">
    <header class="buyer-page-heading buyer-orders-heading">
        <div>
            <span>AKUN PEMBELI</span>
            <h1>Riwayat pesanan</h1>
            <p>{{ $status ? 'Daftar pesanan berdasarkan kategori yang dipilih.' : 'Lihat status dan rincian semua pesanan Anda di satu tempat.' }}</p>
        </div>
        @if($orders->total() > 0)
            <span class="buyer-orders-count"><i class="fa-solid fa-receipt" aria-hidden="true"></i> {{ $orders->total() }} pesanan</span>
        @endif
    </header>
    <nav class="buyer-order-filters" aria-label="Filter pesanan">
        <a href="{{ route('orders') }}" @class(['buyer-order-filter-active' => $status === null]) @if($status === null) aria-current="page" @endif>Semua pesanan</a>
        <a href="{{ route('orders', ['status' => 'unpaid']) }}" @class(['buyer-order-filter-active' => $status === 'unpaid']) @if($status === 'unpaid') aria-current="page" @endif>Belum bayar</a>
        <a href="{{ route('orders', ['status' => 'packed']) }}" @class(['buyer-order-filter-active' => $status === 'packed']) @if($status === 'packed') aria-current="page" @endif>Dikemas</a>
        <a href="{{ route('orders', ['status' => 'shipped']) }}" @class(['buyer-order-filter-active' => $status === 'shipped']) @if($status === 'shipped') aria-current="page" @endif>Dikirim</a>
        <a href="{{ route('orders', ['status' => 'completed']) }}" @class(['buyer-order-filter-active' => $status === 'completed']) @if($status === 'completed') aria-current="page" @endif>Selesai</a>
    </nav>
    @if (session('success')) <p class="buyer-flash-success" role="status">{{ session('success') }}</p> @endif
    @if ($orders->isEmpty())
        <section class="buyer-empty-state buyer-orders-empty">
            <span class="buyer-orders-empty-icon"><i class="fa-solid fa-box-open" aria-hidden="true"></i></span>
            <h2>{{ $status ? 'Belum ada pesanan di kategori ini' : 'Belum ada pesanan' }}</h2>
            <p>{{ $status ? 'Pesanan dengan status ini akan muncul di sini.' : 'Setelah Anda berbelanja, status dan rincian pesanan akan muncul di sini.' }}</p>
            @if($status)
                <a class="buyer-primary-button" href="{{ route('orders') }}">Lihat semua pesanan</a>
            @else
                <a class="buyer-primary-button" href="{{ route('products') }}"><i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i> Mulai belanja</a>
            @endif
        </section>
    @else
        <div class="buyer-order-list">
            @foreach ($orders as $order)
                @php
                    [$statusLabel, $statusClass] = match ($order->status) {
                        'awaiting_payment' => ['Menunggu pembayaran', 'pending'],
                        'awaiting_confirmation' => ['Menunggu konfirmasi', 'pending'],
                        'processing' => ['Sedang diproses', 'processing'],
                        'shipped' => ['Dalam pengiriman', 'shipping'],
                        'completed' => ['Selesai', 'completed'],
                        'cancelled' => ['Dibatalkan', 'cancelled'],
                        default => [str($order->status)->replace('_', ' ')->title(), 'default'],
                    };
                @endphp
                <a class="buyer-order-card" href="{{ route('orders.show', $order) }}" aria-label="Lihat rincian pesanan {{ $order->order_number }}">
                    <div class="buyer-order-card-top">
                        <span class="buyer-order-icon"><i class="fa-solid fa-bag-shopping" aria-hidden="true"></i></span>
                        <div class="buyer-order-reference">
                            <span>NO. PESANAN</span>
                            <strong>{{ $order->order_number }}</strong>
                        </div>
                        <span class="buyer-order-status buyer-order-status-{{ $statusClass }}">
                            <i class="fa-solid {{ $statusClass === 'completed' ? 'fa-circle-check' : ($statusClass === 'cancelled' ? 'fa-circle-xmark' : 'fa-clock') }}" aria-hidden="true"></i>
                            {{ $statusLabel }}
                        </span>
                    </div>
                    <div class="buyer-order-payment">
                        <span>Metode: {{ $order->payment_method->label() }}</span>
                        <span class="payment-badge payment-badge-{{ $order->payment_status->value }}">{{ match($order->payment_status->value) { 'unpaid' => 'Belum dibayar', 'waiting_verification' => 'Menunggu verifikasi', 'paid' => 'Lunas', 'failed' => 'Ditolak', 'expired' => 'Kedaluwarsa', 'refunded' => 'Dikembalikan' } }}</span>
                    </div>
                    <div class="buyer-order-card-bottom">
                        <div class="buyer-order-date">
                            <span>TANGGAL PESANAN</span>
                            <strong><i class="fa-regular fa-calendar" aria-hidden="true"></i> {{ $order->created_at->locale('id')->translatedFormat('d M Y') }}</strong>
                        </div>
                        <div class="buyer-order-items">
                            <span>JUMLAH PRODUK</span>
                            <strong>{{ $order->items->sum('quantity') }} item</strong>
                        </div>
                        <div class="buyer-order-total">
                            <span>{{ $order->shipping_cost === null ? 'SUBTOTAL' : 'TOTAL' }}</span>
                            <strong>Rp {{ number_format($order->shipping_cost === null ? $order->subtotal : $order->grand_total, 0, ',', '.') }}</strong>
                        </div>
                        <span class="buyer-order-detail">Lihat rincian <i class="fa-solid fa-arrow-right" aria-hidden="true"></i></span>
                    </div>
                </a>
            @endforeach
        </div>
        {{ $orders->links() }}
    @endif
</div>
@endsection