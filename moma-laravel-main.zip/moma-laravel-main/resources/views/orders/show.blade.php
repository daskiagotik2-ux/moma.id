@extends('layouts.app')

@section('title', 'Rincian Pesanan | MoMa.id')

@section('content')
<div class="buyer-page">
    <nav class="catalog-breadcrumb" aria-label="Breadcrumb"><a href="{{ route('orders') }}">Pesanan saya</a><i class="fa-solid fa-chevron-right"></i><span>{{ $order->order_number }}</span></nav>
    @if (session('success')) <p class="buyer-flash-success" role="status">{{ session('success') }}</p> @endif
    <header class="buyer-page-heading"><span>RINCIAN PESANAN</span><h1>{{ $order->order_number }}</h1><p>Status: {{ match ($order->status) { 'awaiting_payment' => 'Menunggu pembayaran', 'awaiting_confirmation' => 'Menunggu konfirmasi toko', 'processing' => 'Sedang diproses', 'shipped' => 'Dalam pengiriman', 'completed' => 'Selesai', 'cancelled' => 'Dibatalkan', default => str($order->status)->replace('_', ' ')->title() } }}</p>
        <p>Metode: <strong>{{ $order->payment_method->label() }}</strong> · Pembayaran:
            <span class="payment-badge payment-badge-{{ $order->payment_status->value }}">{{ match($order->payment_status->value) { 'unpaid' => 'Belum dibayar', 'waiting_verification' => 'Menunggu verifikasi', 'paid' => 'Lunas', 'failed' => 'Ditolak', 'expired' => 'Kedaluwarsa', 'refunded' => 'Dikembalikan' } }}</span>
        </p>
        @if($order->payment_method->isManual() && in_array($order->payment_status->value, ['unpaid', 'waiting_verification', 'failed'], true))
            <a class="buyer-primary-button" href="{{ route('orders.pay', $order) }}">Instruksi pembayaran</a>
        @endif
        @if($order->status === 'shipped')
            <form method="POST" action="{{ route('orders.confirm-receipt', $order) }}" onsubmit="return confirm('Apakah Anda sudah menerima semua produk dalam pesanan ini?')">
                @csrf
                <button class="buyer-primary-button" type="submit">Konfirmasi barang diterima</button>
            </form>
        @endif
    </header>
    <section class="buyer-cart-items">
        @foreach ($order->items as $item)
            <article class="buyer-cart-row">
                <div class="buyer-cart-image"><img src="{{ $item->image }}" alt="{{ $item->product_name }}"></div>
                <div class="buyer-cart-copy"><strong>{{ $item->product_name }}</strong><small>{{ $item->seller }}</small><small>{{ $item->quantity }} × Rp {{ number_format($item->price, 0, ',', '.') }}</small><small>{{ match ($item->seller_status) { 'accepted' => 'Pesanan disetujui toko', 'shipped' => 'Dalam pengiriman', 'completed' => 'Pesanan diterima', default => 'Menunggu konfirmasi toko' } }}</small></div>
                <strong class="buyer-line-total">Rp {{ number_format($item->quantity * $item->price, 0, ',', '.') }}</strong>
            </article>
        @endforeach
    </section>
    <aside class="buyer-summary buyer-order-address">
        <h2>Pengiriman dan total</h2>
        <p>{{ $order->shipping_address }}</p><p>{{ $order->contact_phone }}</p>
        <div><span>Subtotal</span><strong>Rp {{ number_format($order->subtotal, 0, ',', '.') }}</strong></div>
        <div><span>Ongkir</span><strong>{{ $order->shipping_cost === null ? 'Menunggu konfirmasi toko' : 'Rp '.number_format($order->shipping_cost, 0, ',', '.') }}</strong></div>
        @if($order->voucher_code)
            <div><span>Voucher {{ $order->voucher_code }}</span><strong>- Rp {{ number_format($order->discount_amount, 0, ',', '.') }}</strong></div>
        @endif
        <div><span>Total</span><strong>{{ $order->shipping_cost === null ? 'Menunggu konfirmasi toko' : 'Rp '.number_format($order->grand_total, 0, ',', '.') }}</strong></div>
    </aside>
</div>
@endsection