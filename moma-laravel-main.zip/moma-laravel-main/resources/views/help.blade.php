@extends('layouts.app')

@section('title', 'Pusat Bantuan | MoMa.id')

@section('content')
<div class="help-page">
    <header class="help-heading">
        <span class="help-kicker">PUSAT BANTUAN</span>
        <h1>Ada yang bisa kami bantu?</h1>
        <p>Panduan singkat untuk mulai menggunakan MoMa.id.</p>
    </header>

    <section class="help-faq" aria-label="Pertanyaan umum">
        <details open>
            <summary>Bagaimana cara mencari produk?</summary>
            <p>Gunakan kolom pencarian di bagian atas, atau buka katalog untuk melihat produk yang tersedia.</p>
        </details>
        <details>
            <summary>Bagaimana cara membuat akun?</summary>
            <p>Pilih Daftar pada navbar, lalu lengkapi formulir pendaftaran akun.</p>
        </details>
        <details>
            <summary>Di mana saya bisa melihat pesanan?</summary>
            <p>Masuk ke akun terlebih dahulu. Setelah masuk, buka menu Notifikasi untuk melihat halaman pesanan.</p>
        </details>
        <details>
            <summary>Bagaimana cara mulai berjualan?</summary>
            <p>Buka halaman UMKM untuk melihat langkah pendaftaran toko yang tersedia.</p>
        </details>
    </section>

    <div class="help-actions">
        <a href="{{ route('products') }}">Jelajahi produk</a>
        <a href="{{ route('register') }}">Buat akun</a>
    </div>
</div>
@endsection