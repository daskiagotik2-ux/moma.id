@extends('layouts.app')

@section('title', 'Toko Pilihan | Nusantara Mart')

@section('content')
    <main class="toko-pilihan-page">
        <section class="toko-pilihan-hero">
            <div>
                <div class="toko-pilihan-kicker"><i class="fa-solid fa-store"></i> Toko pilihan</div>
                <h1>Toko Pilihan</h1>
                <p>Temukan toko pilihan dengan produk berkualitas.</p>
            </div>
            <div class="toko-pilihan-hero-stat">
                <span>Daftar toko</span>
                <strong>{{ $stores->count() }}</strong>
                <small>Aktif di marketplace</small>
            </div>
        </section>

        @if ($stores->isNotEmpty())
            <section class="toko-pilihan-list">
                @foreach ($stores as $store)
                    <article class="toko-pilihan-card">
                        <div class="toko-pilihan-header">
                            <div class="toko-logo">
                                @if ($store['products']->first()?->image)
                                    <img src="{{ $store['products']->first()->image }}" alt="{{ $store['name'] }}" loading="lazy">
                                @else
                                    <i class="fa-solid fa-store"></i>
                                @endif
                            </div>
                            <div class="toko-identitas">
                                <div class="toko-name-row">
                                    <h2>{{ $store['name'] }}</h2>
                                    <span class="toko-pilihan-badge"><i class="fa-solid fa-star"></i> Toko Pilihan</span>
                                </div>
                                <div class="toko-detail-row">
                                    <span><i class="fa-solid fa-location-dot"></i> {{ $store['location'] }}</span>
                                    <span><i class="fa-solid fa-star"></i> {{ number_format($store['rating'], 1) }}</span>
                                </div>
                            </div>
                        </div>

                        <div class="toko-stats">
                            <div><strong>{{ $store['product_count'] }}</strong><span>Produk</span></div>
                            <div><strong>{{ $store['category'] }}</strong><span>Kategori</span></div>
                            <div><strong>{{ $store['products']->count() }}</strong><span>Ungulan</span></div>
                        </div>

                        <a href="{{ route('shop.show', $store['slug']) }}" class="toko-kunjungi-button">
                            Kunjungi Toko <i class="fa-solid fa-arrow-right"></i>
                        </a>

                        <div class="toko-produk-section">
                            <div class="toko-produk-heading">
                                <h3>Produk unggulan</h3>
                                <span>{{ $store['products']->count() }} produk</span>
                            </div>
                            <div class="toko-produk-grid">
                                @foreach ($store['products'] as $product)
                                    <article class="toko-produk-card">
                                        <div class="toko-produk-image">
                                            @if ($product['image'])
                                                <img src="{{ $product['image'] }}" alt="{{ $product['name'] }}" loading="lazy">
                                            @else
                                                <div class="toko-produk-placeholder"><i class="fa-solid fa-box"></i></div>
                                            @endif
                                            @if ($product['old_price'])
                                                <span class="toko-diskon">Diskon</span>
                                            @endif
                                        </div>
                                        <div class="toko-produk-body">
                                            <span class="toko-produk-seller">{{ $product['seller'] }}</span>
                                            <h4>{{ $product['name'] }}</h4>
                                            <div class="toko-produk-rating"><i class="fa-solid fa-star"></i> {{ number_format($product['rating'], 1) }} <span>({{ number_format($product['review_count']) }})</span></div>
                                            <div class="toko-produk-price">
                                                <strong>Rp{{ number_format($product['price']) }}</strong>
                                                @if ($product['old_price'])
                                                    <del>Rp{{ number_format($product['old_price']) }}</del>
                                                @endif
                                            </div>
                                        </div>
                                    </article>
                                @endforeach
                                @if ($store['products']->isEmpty())
                                    <p class="toko-produk-empty">Belum ada produk unggulan untuk toko ini.</p>
                                @endif
                            </div>
                        </div>
                    </article>
                @endforeach
            </section>
        @else
            <div class="toko-pilihan-empty">
                <i class="fa-solid fa-store"></i>
                <h2>Toko belum tersedia</h2>
                <p>Data toko akan muncul setelah produk tersedia di database.</p>
            </div>
        @endif
    </main>
@endsection
