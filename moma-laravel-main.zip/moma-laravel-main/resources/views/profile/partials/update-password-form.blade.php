<section>
    <header>
        <h2 class="account-profile-title">
            <span class="account-profile-icon"><i class="fa-solid fa-shield-halved" aria-hidden="true"></i></span>
            Ubah kata sandi
        </h2>

        <p class="account-profile-description">
            Gunakan kata sandi yang kuat dan tidak digunakan pada akun lain.
        </p>
    </header>

    <form method="post" action="{{ route('password.update') }}" class="account-profile-form mt-6 space-y-6">
        @csrf
        @method('put')

        <div class="account-profile-field">
            <x-input-label for="update_password_current_password" value="Kata sandi saat ini" />
            <x-text-input id="update_password_current_password" name="current_password" type="password" class="mt-1 block w-full" autocomplete="current-password" />
            <x-input-error :messages="$errors->updatePassword->get('current_password')" class="mt-2" />
        </div>

        <div class="account-profile-field">
            <x-input-label for="update_password_password" value="Kata sandi baru" />
            <x-text-input id="update_password_password" name="password" type="password" class="mt-1 block w-full" autocomplete="new-password" />
            <x-input-error :messages="$errors->updatePassword->get('password')" class="mt-2" />
        </div>

        <div class="account-profile-field">
            <x-input-label for="update_password_password_confirmation" value="Konfirmasi kata sandi baru" />
            <x-text-input id="update_password_password_confirmation" name="password_confirmation" type="password" class="mt-1 block w-full" autocomplete="new-password" />
            <x-input-error :messages="$errors->updatePassword->get('password_confirmation')" class="mt-2" />
        </div>

        <div class="flex items-center gap-4">
            <x-primary-button class="account-profile-save"><i class="fa-solid fa-lock" aria-hidden="true"></i> Perbarui kata sandi</x-primary-button>

            @if (session('status') === 'password-updated')
                <p
                    x-data="{ show: true }"
                    x-show="show"
                    x-transition
                    x-init="setTimeout(() => show = false, 2000)"
                    class="text-sm text-gray-600"
                >Kata sandi berhasil diperbarui.</p>
            @endif
        </div>
    </form>
</section>
