<section class="account-delete-section space-y-6">
    <header>
        <h2 class="account-profile-title">
            <span class="account-profile-icon danger"><i class="fa-solid fa-triangle-exclamation" aria-hidden="true"></i></span>
            Hapus akun
        </h2>

        <p class="account-profile-description">
            Tindakan ini akan menghapus akun dan data secara permanen. Pastikan Anda sudah menyimpan informasi yang masih diperlukan.
        </p>
    </header>

    <x-danger-button
        x-data=""
        x-on:click.prevent="$dispatch('open-modal', 'confirm-user-deletion')"
    >Hapus akun saya</x-danger-button>

    <x-modal name="confirm-user-deletion" :show="$errors->userDeletion->isNotEmpty()" focusable>
        <form method="post" action="{{ route('profile.destroy') }}" class="p-6">
            @csrf
            @method('delete')

            <h2 class="text-lg font-medium text-gray-900">
                Apakah Anda yakin ingin menghapus akun?
            </h2>

            <p class="mt-1 text-sm text-gray-600">
                Akun dan data Anda akan dihapus secara permanen. Masukkan kata sandi untuk mengonfirmasi tindakan ini.
            </p>

            <div class="mt-6">
                <x-input-label for="password" value="Kata sandi" class="sr-only" />

                <x-text-input
                    id="password"
                    name="password"
                    type="password"
                    class="mt-1 block w-3/4"
                    placeholder="Masukkan kata sandi"
                />

                <x-input-error :messages="$errors->userDeletion->get('password')" class="mt-2" />
            </div>

            <div class="mt-6 flex justify-end">
                <x-secondary-button x-on:click="$dispatch('close')">
                    Batal
                </x-secondary-button>

                <x-danger-button class="ms-3">
                    Ya, hapus akun
                </x-danger-button>
            </div>
        </form>
    </x-modal>
</section>
