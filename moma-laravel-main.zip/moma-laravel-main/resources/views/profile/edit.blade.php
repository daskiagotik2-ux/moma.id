@extends('layouts.app')

@section('title', 'Profil Saya | MoMa.id')

@section('content')
<div class="account-dashboard account-profile">
    <section class="account-welcome">
        <span class="account-avatar" aria-hidden="true">{{ strtoupper(substr($user->name, 0, 1)) }}</span>
        <div class="account-welcome-copy">
            <span class="dashboard-eyebrow">PENGATURAN AKUN</span>
            <h1>Profil Saya</h1>
            <p>Kelola informasi pribadi dan keamanan akun Anda.</p>
        </div>
    </section>

    <section class="account-panel">
        @include('profile.partials.update-profile-information-form')
    </section>

    <section class="account-panel">
        @include('profile.partials.update-password-form')
    </section>

    <section class="account-panel account-danger-panel">
        @include('profile.partials.delete-user-form')
    </section>
</div>
@endsection
