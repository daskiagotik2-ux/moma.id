@extends('layouts.app')

@section('title', 'Checkout | MoMa.id')

@section('content')
<div class="buyer-page">
    <header class="buyer-page-heading"><span>LANGKAH TERAKHIR</span><h1>Checkout</h1><p>Masukkan alamat dan nomor yang dapat dihubungi toko.</p></header>
    @if ($errors->any()) <p class="buyer-flash-error" role="alert">{{ $errors->first() }}</p> @endif
    <div class="buyer-cart-layout">
        <form class="buyer-checkout-form" method="POST" action="{{ route('checkout.store') }}">
            @csrf
            <h2>Informasi pengiriman</h2>
            <label for="shipping_address">Alamat lengkap</label>
            <textarea id="shipping_address" name="shipping_address" rows="4" maxlength="1000" required>{{ old('shipping_address') }}</textarea>
            @error('shipping_address') <small class="buyer-field-error">{{ $message }}</small> @enderror
            <label for="contact_phone">Nomor telepon</label>
            <input id="contact_phone" name="contact_phone" type="tel" maxlength="25" value="{{ old('contact_phone') }}" required>
            @error('contact_phone') <small class="buyer-field-error">{{ $message }}</small> @enderror
            <fieldset class="payment-method-fieldset">
                <legend>Metode Pembayaran</legend>
                <div class="payment-method-options">
                    @foreach($paymentMethods as $method)
                        <label class="payment-method-card">
                            <input type="radio" name="payment_method" value="{{ $method['value'] }}" @checked(old('payment_method', 'cod') === $method['value']) required>
                            <span class="payment-method-icon" aria-hidden="true"><i class="fa-solid {{ match($method['value']) { 'cod' => 'fa-hand-holding-dollar', 'bank_transfer' => 'fa-building-columns', 'qris' => 'fa-qrcode' } }}"></i></span>
                            <span class="payment-method-copy">
                                <strong>{{ $method['label'] }}</strong>
                                <small>{{ $method['description'] }}</small>
                            </span>
                            <span class="payment-method-check" aria-hidden="true"></span>
                        </label>
                    @endforeach
                </div>
                @error('payment_method') <small class="buyer-field-error" role="alert">{{ $message }}</small> @enderror
            </fieldset>
            <label for="checkout_voucher">Voucher pilihan</label>
            <input id="checkout_voucher" type="text" value="{{ $voucherCode ?? 'Belum ada voucher dipilih' }}" readonly>
            @if($voucherCode)
                <p class="buyer-checkout-note">Kode {{ $voucherCode }} sudah disiapkan untuk checkout.</p>
                @if($voucherError)
                    <p class="buyer-flash-error" role="alert">{{ $voucherError }}</p>
                @endif
                <button class="buyer-secondary-button" type="submit" form="voucher-clear-form">Hapus voucher</button>
            @else
                <p class="buyer-checkout-note"><a href="{{ route('voucher') }}">Pilih voucher</a> untuk menyiapkan kode di checkout.</p>
            @endif
            <p class="buyer-checkout-note">Ongkir dasar Rp {{ number_format($shippingCost, 0, ',', '.') }} per pesanan.</p>
            <button class="buyer-primary-button" type="submit">Buat pesanan</button>
        </form>
        @if($voucherCode)
            <form id="voucher-clear-form" method="POST" action="{{ route('voucher.clear') }}" hidden>
                @csrf
                @method('DELETE')
            </form>
        @endif
        <aside class="buyer-summary">
            <h2>Pesanan Anda</h2>
            @foreach ($items as $item)
                <div class="buyer-summary-item"><span>{{ $item['product']->name }} × {{ $item['quantity'] }}@if($item['is_flash_sale']) <small>Flash Sale</small>@endif</span><strong>Rp {{ number_format($item['price'] * $item['quantity'], 0, ',', '.') }}</strong></div>
            @endforeach
            <div class="buyer-summary-total"><span>Subtotal</span><strong>Rp {{ number_format($subtotal, 0, ',', '.') }}</strong></div>
            <div class="buyer-summary-item"><span>Ongkir</span><strong>Rp {{ number_format($shippingCost, 0, ',', '.') }}</strong></div>
            <div class="buyer-summary-item"><span>Diskon voucher{{ $voucherCode ? ' ('.$voucherCode.')' : '' }}</span><strong>- Rp {{ number_format($discountAmount, 0, ',', '.') }}</strong></div>
            <div class="buyer-summary-total"><span>Total</span><strong>Rp {{ number_format($total, 0, ',', '.') }}</strong></div>
        </aside>
    </div>
</div>
@endsection