<x-guest-layout>
    <div class="auth-layout">
        <section class="auth-story" aria-labelledby="register-story-title">
            <div class="auth-story-copy">
                <span class="auth-eyebrow"><span></span> KOMUNITAS MoMa.id</span>
                <h1 id="register-story-title">Mulai dari karya lokal</h1>
                <p>Buat akun untuk menemukan produk pilihan dan mendukung UMKM Indonesia.</p>
            </div>

            <div class="auth-product-collage" aria-label="Pilihan produk lokal Indonesia">
                <figure class="auth-product-tile auth-product-food">
                    <img src="https://images.unsplash.com/photo-1604908176997-125f25cc6f3d?auto=format&amp;fit=crop&amp;w=700&amp;q=82" alt="Hidangan lokal yang disiapkan dengan bahan segar" fetchpriority="high">
                    <figcaption>Makanan lokal</figcaption>
                </figure>
                <figure class="auth-product-tile auth-product-fashion">
                    <img src="https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&amp;fit=crop&amp;w=500&amp;q=78" alt="Pilihan busana dari brand lokal" loading="lazy">
                    <figcaption>Fashion</figcaption>
                </figure>
                <figure class="auth-product-tile auth-product-craft">
                    <img src="https://images.unsplash.com/photo-1452860606245-08befc0ff44b?auto=format&amp;fit=crop&amp;w=500&amp;q=78" alt="Kerajinan tangan buatan pengrajin" loading="lazy">
                    <figcaption>Kerajinan</figcaption>
                </figure>
                <figure class="auth-product-tile auth-product-beauty">
                    <img src="https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&amp;fit=crop&amp;w=500&amp;q=78" alt="Produk perawatan dan kecantikan" loading="lazy">
                    <figcaption>Kecantikan</figcaption>
                </figure>
                <figure class="auth-product-tile auth-product-accessories">
                    <img src="https://images.unsplash.com/photo-1511499767150-a48a237f0083?auto=format&amp;fit=crop&amp;w=500&amp;q=78" alt="Aksesori pilihan untuk melengkapi gaya" loading="lazy">
                    <figcaption>Aksesori</figcaption>
                </figure>
            </div>

            <p class="auth-story-note"><span aria-hidden="true">01</span> Satu akun untuk belanja produk lokal.</p>
        </section>

        <section class="auth-panel" aria-labelledby="register-title">
            <div class="auth-card">
                <div class="auth-card-heading">
                    <span class="auth-card-kicker">AKUN MoMa.id</span>
                    <h2 id="register-title">Buat akun baru</h2>
                    <p>Setelah daftar, kamu langsung masuk ke akun MoMa.id.</p>
                </div>

                <form method="POST" action="{{ route('register') }}">
                    @csrf

                    <div class="auth-field">
                        <label class="auth-label" for="name">Nama lengkap</label>
                        <input id="name" class="auth-input" type="text" name="name" value="{{ old('name') }}" required autofocus autocomplete="name" placeholder="Nama kamu" @if ($errors->has('name')) aria-invalid="true" aria-describedby="name-error" @endif>
                        @error('name')
                            <p class="auth-field-error" id="name-error">{{ $message }}</p>
                        @enderror
                    </div>

                    <div class="auth-field">
                        <label class="auth-label" for="email">Email</label>
                        <input id="email" class="auth-input" type="email" name="email" value="{{ old('email') }}" required autocomplete="username" placeholder="nama@email.com" @if ($errors->has('email')) aria-invalid="true" aria-describedby="email-error" @endif>
                        @error('email')
                            <p class="auth-field-error" id="email-error">{{ $message }}</p>
                        @enderror
                    </div>

                    <div class="auth-field">
                        <label class="auth-label" for="password">Kata sandi</label>
                        <input id="password" class="auth-input" type="password" name="password" required autocomplete="new-password" placeholder="Buat kata sandi" @if ($errors->has('password')) aria-invalid="true" aria-describedby="password-error" @endif>
                        @error('password')
                            <p class="auth-field-error" id="password-error">{{ $message }}</p>
                        @enderror
                    </div>

                    <div class="auth-field">
                        <label class="auth-label" for="password_confirmation">Konfirmasi kata sandi</label>
                        <input id="password_confirmation" class="auth-input" type="password" name="password_confirmation" required autocomplete="new-password" placeholder="Ulangi kata sandi" @if ($errors->has('password_confirmation')) aria-invalid="true" aria-describedby="password-confirmation-error" @endif>
                        @error('password_confirmation')
                            <p class="auth-field-error" id="password-confirmation-error">{{ $message }}</p>
                        @enderror
                    </div>

                    <button class="auth-submit" type="submit">
                        <span>Daftar sekarang</span>
                        <svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="M4 10h12m-5-5 5 5-5 5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    </button>
                </form>

                <p class="auth-register">Sudah punya akun? <a href="{{ route('login') }}">Masuk</a></p>
            </div>
        </section>
    </div>
</x-guest-layout>
