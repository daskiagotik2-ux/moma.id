<x-guest-layout>
    <div class="auth-layout">
        <section class="auth-story" aria-labelledby="auth-story-title">
            <div class="auth-story-copy">
                <span class="auth-eyebrow"><span></span> PASAR LOKAL PILIHAN</span>
                <h1 id="auth-story-title">Belanja Lokal,<br>Lebih Berarti</h1>
                <p>Masuk ke MoMa.id dan temukan produk favoritmu dari UMKM pilihan Indonesia.</p>
            </div>

            <div class="auth-product-collage" aria-label="Pilihan produk lokal Indonesia">
                <figure class="auth-product-tile auth-product-food">
                    <img src="https://images.unsplash.com/photo-1604908176997-125f25cc6f3d?auto=format&amp;fit=crop&amp;w=700&amp;q=82" alt="Hidangan lokal yang disiapkan dengan bahan segar" fetchpriority="high">
                    <figcaption>Makanan lokal</figcaption>
                </figure>
                <figure class="auth-product-tile auth-product-fashion">
                    <img src="https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&amp;fit=crop&amp;w=500&amp;q=78" alt="Pilihan busana dari brand lokal" loading="lazy">
                    <figcaption>Fashion</figcaption>
                </figure>
                <figure class="auth-product-tile auth-product-craft">
                    <img src="https://images.unsplash.com/photo-1452860606245-08befc0ff44b?auto=format&amp;fit=crop&amp;w=500&amp;q=78" alt="Kerajinan tangan buatan pengrajin" loading="lazy">
                    <figcaption>Kerajinan</figcaption>
                </figure>
                <figure class="auth-product-tile auth-product-beauty">
                    <img src="https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&amp;fit=crop&amp;w=500&amp;q=78" alt="Produk perawatan dan kecantikan" loading="lazy">
                    <figcaption>Kecantikan</figcaption>
                </figure>
                <figure class="auth-product-tile auth-product-accessories">
                    <img src="https://images.unsplash.com/photo-1511499767150-a48a237f0083?auto=format&amp;fit=crop&amp;w=500&amp;q=78" alt="Aksesori pilihan untuk melengkapi gaya" loading="lazy">
                    <figcaption>Aksesori</figcaption>
                </figure>
            </div>

            <p class="auth-story-note"><span aria-hidden="true">01</span> Temukan karya, dukung usaha lokal.</p>
        </section>

        <section class="auth-panel" aria-labelledby="login-title">
            <div class="auth-card">
                <div class="auth-card-heading">
                    <span class="auth-card-kicker">AKUN MoMa.id</span>
                    <h2 id="login-title">Masuk ke MoMa.id</h2>
                    <p>Selamat datang kembali! Silakan masuk ke akunmu.</p>
                </div>

                <form method="POST" action="{{ route('login') }}" data-login-form>
                    @csrf

                    <div class="auth-field">
                        <label class="auth-label" for="email">Email</label>
                        <input id="email" class="auth-input" type="email" name="email" value="{{ old('email') }}" required autofocus autocomplete="username" placeholder="nama@email.com" @if ($errors->has('email')) aria-invalid="true" aria-describedby="email-error" @endif>
                        @error('email')
                            <p class="auth-field-error" id="email-error">{{ $message }}</p>
                        @enderror
                    </div>

                    <div class="auth-field">
                        <label class="auth-label" for="password">Kata sandi</label>
                        <div class="auth-password-wrap">
                            <input id="password" class="auth-input" type="password" name="password" required autocomplete="current-password" placeholder="Masukkan kata sandi" @if ($errors->has('password')) aria-invalid="true" aria-describedby="password-error" @endif>
                            <button class="auth-password-toggle" type="button" data-password-toggle aria-label="Tampilkan kata sandi" aria-controls="password">
                                <svg data-eye-icon viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M2.5 12s3.4-6 9.5-6 9.5 6 9.5 6-3.4 6-9.5 6-9.5-6-9.5-6Z" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/><circle cx="12" cy="12" r="2.7" stroke="currentColor" stroke-width="1.7"/></svg>
                                <svg data-eye-off-icon viewBox="0 0 24 24" fill="none" aria-hidden="true" hidden><path d="m3 3 18 18M10.6 6.2A10.8 10.8 0 0 1 12 6c6.1 0 9.5 6 9.5 6a15.8 15.8 0 0 1-3 3.5M6.2 6.9C3.8 8.5 2.5 12 2.5 12s3.4 6 9.5 6c1 0 1.9-.2 2.7-.4" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/><path d="M9.9 9.9a3 3 0 0 0 4.2 4.2" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>
                            </button>
                        </div>
                        @error('password')
                            <p class="auth-field-error" id="password-error">{{ $message }}</p>
                        @enderror
                    </div>

                    <div class="auth-form-options">
                        <label class="auth-remember" for="remember_me">
                            <input id="remember_me" type="checkbox" name="remember" @checked(old('remember'))>
                            <span>Ingat saya</span>
                        </label>
                        @if (Route::has('password.request'))
                            <a class="auth-text-link" href="{{ route('password.request') }}">Lupa password?</a>
                        @endif
                    </div>

                    <button class="auth-submit" type="submit" data-login-submit>
                        <span class="auth-spinner" data-login-spinner aria-hidden="true" hidden></span>
                        <span data-login-submit-label>Masuk</span>
                        <svg viewBox="0 0 20 20" fill="none" aria-hidden="true"><path d="M4 10h12m-5-5 5 5-5 5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    </button>
                </form>

                <p class="auth-register">Belum punya akun? <a href="{{ route('register') }}">Daftar sekarang</a></p>
            </div>
        </section>
    </div>
</x-guest-layout>
