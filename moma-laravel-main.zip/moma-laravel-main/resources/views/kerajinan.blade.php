@extends('layouts.app')

@section('title', 'Kerajinan Lokal | MoMa.id')

@section('content')
<div class="kerajinan-page">
    <nav class="kerajinan-breadcrumb" aria-label="Breadcrumb">
        <a href="{{ route('home') }}">Beranda</a>
        <i class="fa-solid fa-chevron-right"></i>
        <span>Kerajinan</span>
    </nav>

    <section class="kerajinan-hero">
        <div class="kerajinan-hero-copy">
            <span class="kerajinan-kicker"><i class="fa-solid fa-hand-sparkles"></i> KARYA DARI TANGAN</span>
            <h1>Kerajinan Lokal</h1>
            <p>Karya unik buatan tangan dari pengrajin Indonesia.</p>
            <div class="kerajinan-hero-stats">
                <span><strong>100%</strong> handmade</span>
                <span><strong>7</strong> kategori</span>
                <span><strong>Local</strong> artisan</span>
            </div>
        </div>
        <div class="kerajinan-hero-art" aria-hidden="true">
            <span class="kerajinan-pattern pattern-one"></span>
            <span class="kerajinan-pattern pattern-two"></span>
            <span class="kerajinan-hero-object"><i class="fa-solid fa-hands"></i></span>
            <span class="kerajinan-caption">BUATAN<br>TANGAN</span>
        </div>
    </section>

    <section class="kerajinan-category-section">
        <div class="kerajinan-section-heading">
            <div><span>JELAJAHI KATEGORI</span><h2>Temukan karyamu</h2></div>
            <p>Setiap bentuk punya cerita.</p>
        </div>
        <div class="kerajinan-category-grid">
            @php($categories = [
                ['Kerajinan Aceh', 'fa-map-location-dot', '#d94b3d'],
                ['Anyaman', 'fa-weave', '#8e5fc2'],
                ['Kayu', 'fa-tree', '#c77b2b'],
                ['Batik', 'fa-ribbon', '#2f83a9'],
                ['Souvenir', 'fa-gift', '#4e9f78'],
                ['Dekorasi Rumah', 'fa-house', '#c06a83'],
                ['Handmade', 'fa-hand-sparkles', '#da7d35'],
            ])
            @foreach($categories as $category)
                <a class="kerajinan-category-card {{ request('category') === $category[0] ? 'active' : '' }}" href="{{ route('kerajinan', ['category' => $category[0]]) }}">
                    <span style="--category-color: {{ $category[2] }}"><i class="fa-solid {{ $category[1] }}"></i></span>
                    <strong>{{ $category[0] }}</strong>
                </a>
            @endforeach
        </div>
    </section>

    <section class="kerajinan-products-section">
        <div class="kerajinan-products-heading">
            <div><span>PRODUK BERKARYA</span><h2>Kerajinan pilihan</h2></div>
            <span>{{ $productCards->count() }} produk</span>
        </div>

        <div class="kerajinan-filter-bar">
            <form action="{{ route('kerajinan') }}" method="GET">
                <label><i class="fa-solid fa-magnifying-glass"></i><input type="search" name="category" value="{{ request('category') }}" placeholder="Cari kategori..." aria-label="Cari kategori"></label>
                <label><span>Harga maksimal</span><select name="price" onchange="this.form.submit()"><option value="">Semua harga</option><option value="100000" {{ request('price') === '100000' ? 'selected' : '' }}>Dibawah Rp100 ribu</option><option value="200000" {{ request('price') === '200000' ? 'selected' : '' }}>Dibawah Rp200 ribu</option><option value="300000" {{ request('price') === '300000' ? 'selected' : '' }}>Dibawah Rp300 ribu</option></select></label>
                <label><span>Rating</span><select name="rating" onchange="this.form.submit()"><option value="">Semua rating</option><option value="4.8" {{ request('rating') === '4.8' ? 'selected' : '' }}>4.8 ke atas</option><option value="4.7" {{ request('rating') === '4.7' ? 'selected' : '' }}>4.7 ke atas</option></select></label>
            </form>
        </div>

        @if($productCards->isNotEmpty())
            <div class="kerajinan-product-grid">
                @foreach($productCards as $product)
                    <article class="kerajinan-product-card">
                        <div class="kerajinan-product-image">
                            @if($product['image'])
                                <img src="{{ $product['image'] }}" alt="{{ $product['name'] }}" loading="lazy">
                            @else
                                <div class="kerajinan-product-placeholder"><i class="fa-solid fa-hand-sparkles"></i></div>
                            @endif
                            <span class="kerajinan-handmade-badge"><i class="fa-solid fa-gem"></i> Handmade</span>
                            @if($product['old_price'] > $product['price'])
                                <span class="kerajinan-discount">-{{ round((1 - $product['price'] / $product['old_price']) * 100) }}%</span>
                            @endif
                        </div>
                        <div class="kerajinan-product-body">
                            <div class="kerajinan-product-seller">{{ $product['seller'] }} <span>•</span> {{ $product['location'] }}</div>
                            <h3>{{ $product['name'] }}</h3>
                            <div class="kerajinan-price"><strong>Rp {{ number_format($product['price'], 0, ',', '.') }}</strong>@if($product['old_price'] > $product['price'])<del>Rp {{ number_format($product['old_price'], 0, ',', '.') }}</del>@endif</div>
                            <div class="kerajinan-product-meta">
                                <span><i class="fa-solid fa-star"></i> {{ number_format($product['rating'], 1) }}</span>
                                <span><i class="fa-solid fa-bag-shopping"></i> {{ number_format($product['sold']) }} terjual</span>
                            </div>
                            <a href="{{ route('products.show', $product['slug']) }}" class="kerajinan-view-button">Lihat Produk <i class="fa-solid fa-arrow-right"></i></a>
                        </div>
                    </article>
                @endforeach
            </div>
        @else
            <div class="kerajinan-empty">
                <i class="fa-solid fa-search"></i>
                <h3>Karya belum ditemukan</h3>
                <p>Coba kategori lain atau hapus filter.</p>
                <a href="{{ route('kerajinan') }}">Lihat semua kerajinan</a>
            </div>
        @endif
    </section>

    <section class="kerajinan-featured-section">
        <div class="kerajinan-featured-heading">
            <div><span>PRODUK PILIHAN</span><h2>Produk Pilihan Pengrajin Lokal</h2><p>Legenda dari petani, pengrajin, dan kreator lokal.</p></div>
            <a href="{{ route('kerajinan') }}">Lihat semua <i class="fa-solid fa-arrow-right"></i></a>
        </div>
        <div class="kerajinan-featured-grid">
            @foreach($productCards->take(3) as $product)
                <a class="kerajinan-featured-card" href="{{ route('products') }}">
                    <img src="{{ $product['image'] }}" alt="{{ $product['name'] }}" loading="lazy">
                    <span><small>{{ $product['seller'] }}</small><strong>{{ $product['name'] }}</strong><b>Rp {{ number_format($product['price'], 0, ',', '.') }}</b></span>
                </a>
            @endforeach
        </div>
    </section>
</div>
@endsection
