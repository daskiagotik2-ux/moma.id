@extends('layouts.app')
@section('title', $title.' — MoMa.id')
@section('content')
<div class="app-shell">
    @include('partials.header')
    <div class="simple-page">
        <div class="simple-card">
            <div class="simple-icon">🍃</div>
            <h1>{{ $title ?? 'Halaman' }}</h1>
            <p>{{ $message ?? 'Halaman ini sedang dalam pengembangan.' }}</p>
            <a class="primary-btn" href="{{ route('home') }}">← Kembali ke Beranda</a>
        </div>
    </div>
    @include('partials.footer')
</div>
@endsection