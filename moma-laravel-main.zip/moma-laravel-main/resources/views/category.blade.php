@extends('layouts.app')

@section('title', ($selectedCategory?->name ?? 'Semua Kategori').' | MoMa.id')

@section('content')
<div class="catalog-page category-platform-page">
    <nav class="catalog-breadcrumb" aria-label="Breadcrumb">
        <a href="{{ route('home') }}">Beranda</a>
        <i class="fa-solid fa-chevron-right"></i>
        <span>{{ $selectedCategory?->name ?? 'Semua kategori' }}</span>
    </nav>

    <section class="catalog-hero category-hero category-platform-{{ $selectedCategory?->slug ?? 'all' }}">
        <div class="catalog-hero-copy">
            <span class="catalog-eyebrow"><i class="fa-solid {{ $categoryPlatform['icon'] }}"></i> KATEGORI PRODUK</span>
            <h1>{{ $selectedCategory?->name ?? 'Semua kategori' }}</h1>
            <p>{{ $categoryPlatform['description'] }}</p>
            <div class="catalog-hero-meta"><span><i class="fa-solid fa-box-open"></i> {{ number_format($products->total(), 0, ',', '.') }} produk</span></div>
        </div>
        <aside class="category-platform-feature">
            <span class="category-platform-feature-icon"><i class="fa-solid {{ $categoryPlatform['icon'] }}"></i></span>
            <small>KOLEKSI KATEGORI</small>
            <strong>{{ $categoryPlatform['label'] }}</strong>
            <span>Produk terkurasi dari penjual MoMa.id</span>
        </aside>
    </section>

    <form class="catalog-toolbar" method="GET" action="{{ route('category', $selectedCategory?->slug ?? 'semua') }}" aria-label="Cari dan urutkan produk kategori">
        <label class="sr-only" for="category-search">Cari produk dalam kategori</label>
        <input id="category-search" class="catalog-sort" type="search" name="search" value="{{ request('search') }}" placeholder="Cari {{ $selectedCategory ? strtolower($selectedCategory->name) : 'produk' }}...">

        <label class="sr-only" for="category-sort">Urutkan produk</label>
        <select class="catalog-sort" id="category-sort" name="sort">
            <option value="newest" @selected(request('sort', 'newest') === 'newest')>Terbaru</option>
            <option value="popular" @selected(request('sort') === 'popular')>Rating tertinggi</option>
            <option value="price_asc" @selected(request('sort') === 'price_asc')>Harga terendah</option>
            <option value="price_desc" @selected(request('sort') === 'price_desc')>Harga tertinggi</option>
        </select>

        <button class="catalog-filter active" type="submit"><i class="fa-solid fa-sliders"></i> Terapkan</button>
        @if (request()->hasAny(['search', 'sort']) && (request('search') || request('sort') !== 'newest'))
            <a class="catalog-filter" href="{{ route('category', $selectedCategory?->slug ?? 'semua') }}">Reset</a>
        @endif
    </form>

    <nav class="catalog-toolbar category-platform-nav" aria-label="Jelajahi kategori lain">
        <a class="catalog-filter {{ $selectedCategory ? '' : 'active' }}" href="{{ route('category', 'semua') }}">Semua</a>
        @foreach ($categories as $category)
            <a class="catalog-filter {{ $selectedCategory?->id === $category->id ? 'active' : '' }}" href="{{ route('category', $category->slug) }}">{{ $category->name }}</a>
        @endforeach
    </nav>

    <section class="catalog-section">
        <div class="catalog-section-header">
            <div>
                <span class="catalog-section-kicker">{{ $selectedCategory?->name ?? 'SEMUA KATEGORI' }}</span>
                <h2>{{ number_format($products->total(), 0, ',', '.') }} produk</h2>
            </div>
        </div>

        @if ($products->isNotEmpty())
            <div class="catalog-product-grid">
                @foreach ($products as $product)
                    <x-product-card :product="$product" />
                @endforeach
            </div>
            <div class="catalog-pagination">{{ $products->links() }}</div>
        @else
            <div class="catalog-empty-state">
                <h2>Belum ada produk di {{ $selectedCategory ? strtolower($selectedCategory->name) : 'katalog' }}</h2>
                <p>Produk yang sesuai kategori ini akan tampil di sini setelah tersedia.</p>
                <a href="{{ route('products') }}">Jelajahi semua produk</a>
            </div>
        @endif
    </section>
</div>
@endsection