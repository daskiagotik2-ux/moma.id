@extends('layouts.app')

@section('title', 'MoMa.id | Belanja Produk Lokal')

@section('content')
<x-splash-screen />

<div class="marketplace-home">
    <section class="market-hero-grid" aria-label="Promo pilihan MoMa.id">
        <a class="market-hero-main" href="{{ route('products') }}">
            <img src="https://images.unsplash.com/photo-1442512595331-e89e73853f31?auto=format&fit=crop&w=1500&q=85" alt="Kopi lokal pilihan dari UMKM Indonesia" fetchpriority="high">
            <span class="market-hero-shade"></span>
            <span class="market-hero-copy">
                <span class="market-hero-kicker">FESTIVAL PRODUK LOKAL</span>
                <strong>Belanja Lokal,<br>Bangga Indonesia</strong>
                <span>Temukan karya terbaik dari UMKM pilihan</span>
                <span class="market-hero-cta">Jelajahi sekarang <i class="fa-solid fa-arrow-right"></i></span>
            </span>
        </a>
        <div class="market-promo-stack">
            <a class="market-promo-card promo-mall" href="{{ route('products') }}">
                <img src="https://images.unsplash.com/photo-1590874103328-eac38a683ce7?auto=format&fit=crop&w=760&q=80" alt="Tas anyaman lokal" loading="lazy">
                <span><small>KOLEKSI PILIHAN</small><strong>Aksesori lokal<br>pilihan</strong><b>LIHAT PRODUK <i class="fa-solid fa-arrow-right"></i></b></span>
            </a>
            <a class="market-promo-card promo-umkm" href="{{ route('shop') }}">
                <img src="https://images.unsplash.com/photo-1599599810694-b5b37304c041?auto=format&fit=crop&w=760&q=80" alt="Camilan khas UMKM" loading="lazy">
                <span><small>RASA NUSANTARA</small><strong>Camilan khas<br>buat harimu</strong><b>JELAJAHI <i class="fa-solid fa-arrow-right"></i></b></span>
            </a>
        </div>
    </section>

    <nav class="market-shortcuts" aria-label="Menu populer">
        @php
            $shortcuts = [
                ['Flash Sale', 'fa-bolt', '#B91C2B', route('flash-sale')],
                ['MoMa Mall', 'fa-bag-shopping', '#4A171D', route('moma-mall')],
                ['Makanan Lokal', 'fa-bowl-food', '#B91C2B', route('makanan-lokal')],
                ['Fashion', 'fa-shirt', '#4A171D', route('fashion')],
                ['Kerajinan', 'fa-palette', '#B91C2B', route('kerajinan')],
                ['Promo Gratis Ongkir', 'fa-truck-fast', '#4A171D', route('gratis-ongkir')],
                ['Produk Terlaris', 'fa-chart-line', '#B91C2B', route('produk-terlaris')],
                ['Toko Pilihan', 'fa-store', '#4A171D', route('toko-pilihan')],
                ['Voucher', 'fa-ticket', '#B91C2B', route('promo')],
                ['Semua Kategori', 'fa-border-all', '#4A171D', route('category', 'semua')],
            ];
        @endphp
        @foreach($shortcuts as $shortcut)
            <a class="market-shortcut" href="{{ $shortcut[3] }}">
                <span class="shortcut-icon" style="--shortcut-color: {{ $shortcut[2] }}"><i class="fa-solid {{ $shortcut[1] }}"></i></span>
                <span>{{ $shortcut[0] }}</span>
            </a>
        @endforeach
    </nav>

    <section class="market-section category-section">
        <div class="market-section-heading">
            <div><span class="market-section-kicker">PILIHAN UNTUKMU</span><h2>Belanja berdasarkan kategori</h2></div>
            <a href="{{ route('category', 'semua') }}">Lihat semua <i class="fa-solid fa-chevron-right"></i></a>
        </div>
        <div class="market-category-grid">
            @foreach($categories as $category)
                <a class="market-category" href="{{ route('category', $category->slug) }}">
                    <span><i>{{ $category->icon }}</i></span>
                    <strong>{{ $category->name }}</strong>
                </a>
            @endforeach
        </div>
    </section>

    <section class="market-section product-section">
        <div class="market-section-heading">
            <div><span class="market-section-kicker">DARI PESANAN SELESAI</span><h2>Produk terlaris</h2></div>
        </div>
        @if ($bestSellingProducts->isNotEmpty())
            <div class="market-product-grid">
                @foreach ($bestSellingProducts as $product)
                    <x-product-card :product="$product" />
                @endforeach
            </div>
        @else
            <p class="market-empty-inline">Belum ada data pesanan selesai untuk menentukan produk terlaris.</p>
        @endif
    </section>

    <section class="market-section product-section">
        <div class="market-section-heading">
            <div><span class="market-section-kicker">BARU DITAMBAHKAN</span><h2>Produk terbaru</h2></div>
            <a href="{{ route('products', ['sort' => 'newest']) }}">Lihat semua <i class="fa-solid fa-chevron-right"></i></a>
        </div>
        <div class="market-product-grid">
            @forelse($latestProducts as $product)
                <x-product-card :product="$product" />
            @empty
                <p>Belum ada produk yang tersedia.</p>
            @endforelse
        </div>
    </section>

    <section class="market-section product-section">
        <div class="market-section-heading">
            <div><span class="market-section-kicker">PILIHAN TOKO</span><h2>Rekomendasi untukmu</h2></div>
            <a href="{{ route('products') }}">Jelajahi produk <i class="fa-solid fa-chevron-right"></i></a>
        </div>
        <div class="market-product-grid">
            @forelse($recommendedProducts as $product)
                <x-product-card :product="$product" />
            @empty
                <p>Belum ada produk rekomendasi.</p>
            @endforelse
        </div>
    </section>
</div>
@endsection
