@extends('layouts.app')

@section('title', 'Toko Saya — MoMa.id')

@section('content')
<div class="shop-center-page">
    <section class="shop-center-header">
        <div>
            <span class="shop-center-eyebrow">SELLER CENTER</span>
            <h1>Toko Saya</h1>
            <p>Atur identitas toko, informasi penjualan, dan data kontak Anda.</p>
        </div>
        <div class="shop-center-status"><span></span> Toko sedang aktif</div>
    </section>

    <div class="shop-center-layout">
        <aside class="shop-center-sidebar">
            <div class="shop-profile-summary">
                <div class="shop-logo">N</div>
                <div><strong>Nama Toko</strong><span>Belum terdaftar</span></div>
            </div>
            <nav aria-label="Menu toko">
                <a class="active" href="#identitas"><i class="fa-regular fa-store"></i> Identitas Toko</a>
                <a href="#produk"><i class="fa-solid fa-boxes-stacked"></i> Produk</a>
                <a href="#pesanan"><i class="fa-solid fa-receipt"></i> Pesanan</a>
                <a href="#keuangan"><i class="fa-solid fa-wallet"></i> Keuangan</a>
                <a href="#pengaturan"><i class="fa-solid fa-gear"></i> Pengaturan</a>
            </nav>
            <div class="shop-help-card">
                <i class="fa-solid fa-circle-question"></i>
                <strong>Butuh bantuan?</strong>
                <p>Ikuti prosedur pendaftaran toko di MoMa.id.</p>
                <a href="#">Lihat bantuan <i class="fa-solid fa-arrow-right"></i></a>
            </div>
        </aside>

        <main class="shop-center-main">
            <section class="shop-form-card" id="identitas">
                <div class="shop-form-heading">
                    <div>
                        <span class="shop-form-number">01</span>
                        <div><h2>Identitas Toko</h2><p>Data yang digunakan untuk menampilkan toko Anda di marketplace.</p></div>
                    </div>
                    <span class="shop-required">* Wajib diisi</span>
                </div>

                <form id="shop-identity-form" novalidate>
                    <div class="shop-form-grid">
                        <div class="shop-field shop-field-wide">
                            <label for="shop-name">Nama toko <span>*</span></label>
                            <input id="shop-name" name="shop_name" type="text" autocomplete="organization" placeholder="Contoh: Dapur Bunda Aceh" minlength="3" required>
                            <small>Gunakan nama yang jelas dan mudah dikenali pembeli.</small>
                        </div>
                        <div class="shop-field">
                            <label for="shop-category">Kategori toko <span>*</span></label>
                            <select id="shop-category" name="category" required>
                                <option value="">Pilih kategori</option>
                                <option>Makanan & Minuman</option>
                                <option>Fashion</option>
                                <option>Kecantikan</option>
                                <option>Rumah & Dapur</option>
                                <option>Kerajinan Tangan</option>
                                <option>Kopi & Teh</option>
                                <option>Elektronik</option>
                                <option>Lainnya</option>
                            </select>
                        </div>
                        <div class="shop-field">
                            <label for="shop-phone">Nomor telepon <span>*</span></label>
                            <div class="shop-phone-input"><span>+62</span><input id="shop-phone" name="phone" type="tel" autocomplete="tel" placeholder="81234567890" required pattern="[0-9+()\-\s]{8,}"></div>
                        </div>
                        <div class="shop-field">
                            <label for="shop-email">Email toko <span>*</span></label>
                            <input id="shop-email" name="email" type="email" autocomplete="email" placeholder="toko@example.com" required>
                        </div>
                        <div class="shop-field">
                            <label for="shop-location">Kabupaten / kota <span>*</span></label>
                            <select id="shop-location" name="location" required>
                                <option value="">Pilih lokasi</option>
                                <option>ACEH</option>
                                <option>Bandung</option>
                                <option>Jakarta</option>
                                <option>Medan</option>
                                <option>Palembang</option>
                                <option>Surabaya</option>
                                <option>Yogyakarta</option>
                            </select>
                        </div>
                        <div class="shop-field shop-field-wide">
                            <label for="shop-address">Alamat toko <span>*</span></label>
                            <textarea id="shop-address" name="address" rows="3" placeholder="Masukkan alamat lengkap, termasuk nomor rumah atau toko" minlength="8" required></textarea>
                        </div>
                        <div class="shop-field shop-field-wide">
                            <label for="shop-description">Deskripsi toko</label>
                            <textarea id="shop-description" name="description" rows="4" maxlength="300" placeholder="Deskripsikan produk, keunggulan, dan cerita belakang toko Anda..."></textarea>
                            <small class="shop-character-count">0 / 300 karakter</small>
                        </div>
                    </div>

                    <div class="shop-form-actions">
                        <button class="shop-reset-button" type="reset">Hapus</button>
                        <button class="shop-save-button" type="submit"><i class="fa-solid fa-floppy-disk"></i> Simpan perubahan</button>
                    </div>
                    <p class="shop-form-status" role="status" aria-live="polite"></p>
                </form>
            </section>

            <section class="shop-preview-card" aria-label="Pratinjau identitas toko">
                <div class="shop-preview-heading"><span>PRATINJAU TOKO</span><i class="fa-solid fa-eye"></i></div>
                <div class="shop-preview-banner">
                    <div class="shop-preview-logo">N</div>
                    <div><strong id="preview-name">Nama Toko Anda</strong><span id="preview-category">Kategori Toko</span></div>
                </div>
                <p id="preview-description">Deskripsi toko Anda akan muncul di sini setelah disimpan.</p>
                <div class="shop-preview-meta"><span><i class="fa-solid fa-location-dot"></i><b id="preview-location">Lokasi</b></span><span><i class="fa-solid fa-star"></i> 4.9</span></div>
            </section>
        </main>
    </div>
</div>
@endsection