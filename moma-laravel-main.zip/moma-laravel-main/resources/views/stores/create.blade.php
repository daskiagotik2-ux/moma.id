
@extends('layouts.app')

@section('title', 'Buka Toko — MoMa.id')

@section('content')
<div class="mx-auto max-w-3xl px-4 py-10">
    <div class="mb-8">
        <a href="{{ route('dashboard') }}"
           class="text-sm text-gray-500 hover:text-red-600">
            &larr; Kembali ke Akun Saya
        </a>

        <h1 class="mt-4 text-3xl font-bold text-gray-900">
            Buka Toko di MoMa.id
        </h1>

        <p class="mt-2 text-gray-600">
            Lengkapi informasi toko kamu. Toko akan langsung dikonfirmasi setelah formulir dikirim.
        </p>
    </div>

    @if (session('success'))
        <div class="mb-5 rounded-lg bg-green-50 p-4 text-green-700">
            {{ session('success') }}
        </div>
    @endif

    @if (session('error'))
        <div class="mb-5 rounded-lg bg-red-50 p-4 text-red-700">
            {{ session('error') }}
        </div>
    @endif

    @if ($errors->any())
        <div class="mb-5 rounded-lg bg-red-50 p-4 text-red-700">
            <p class="font-semibold">Periksa kembali formulir kamu:</p>
            <ul class="mt-2 list-disc pl-5">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    @if ($store)
        <div class="space-y-5 rounded-xl border border-gray-200 bg-white p-6 shadow-sm">
            <div>
                <h2 class="text-xl font-semibold text-gray-900">{{ $store->store_name }}</h2>
                <p class="mt-2 text-gray-600">
                    Status toko:
                    <span class="font-semibold">
                    @switch($store->status)
                        @case('pending')
                            Menunggu verifikasi admin
                            @break
                        @case('approved')
                            Disetujui
                            @break
                        @case('revision')
                            Perlu perbaikan
                            @break
                        @case('rejected')
                            Ditolak
                            @break
                        @default
                            {{ ucfirst($store->status) }}
                    @endswitch
                    </span>
                </p>
                <dl class="mt-4 grid gap-3 text-sm text-gray-700 sm:grid-cols-2">
                    <div><dt class="font-semibold">Kategori</dt><dd>{{ $store->category }}</dd></div>
                    <div><dt class="font-semibold">Telepon</dt><dd>{{ $store->phone }}</dd></div>
                    <div class="sm:col-span-2"><dt class="font-semibold">Alamat</dt><dd>{{ $store->address }}</dd></div>
                    @if ($store->description)<div class="sm:col-span-2"><dt class="font-semibold">Deskripsi</dt><dd>{{ $store->description }}</dd></div>@endif
                </dl>
            </div>

            @if ($store->admin_note)
                <p class="mt-3 text-sm text-gray-600">
                    Catatan admin: {{ $store->admin_note }}
                </p>
            @endif

            <div class="flex flex-wrap gap-3">
                <a href="{{ route('seller.dashboard') }}" class="rounded-lg bg-[#B91C2B] px-5 py-3 font-semibold text-white hover:bg-[#4A171D]">Masuk ke Seller Center</a>
                @if ($store->status === 'approved')
                    <a href="{{ route('shop.show', $store->slug) }}" class="rounded-lg border border-gray-300 px-5 py-3 font-semibold text-gray-700 hover:border-[#B91C2B] hover:text-[#B91C2B]">Lihat Toko Publik</a>
                @endif
            </div>
        </div>
    @else
        <form action="{{ route('stores.store') }}"
              method="POST"
              class="space-y-6 rounded-xl border border-gray-200 bg-white p-6 shadow-sm">

            @csrf

            <div>
                <label for="store_name"
                       class="mb-2 block font-medium text-gray-800">
                    Nama Toko *
                </label>
                <input id="store_name" name="store_name" type="text"
                       value="{{ old('store_name') }}"
                       maxlength="100" required
                       placeholder="Contoh: Toko Wilda"
                       class="w-full rounded-lg border border-gray-300 px-4 py-3 focus:border-red-500 focus:outline-none">
                @error('store_name')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label for="category"
                       class="mb-2 block font-medium text-gray-800">
                    Kategori Toko *
                </label>
                <select id="category" name="category" required
                        class="w-full rounded-lg border border-gray-300 px-4 py-3 focus:border-red-500 focus:outline-none">
                    <option value="">Pilih kategori</option>
                    @foreach (['Makanan & Minuman', 'Fashion', 'Kerajinan Lokal', 'Kecantikan', 'Elektronik', 'Rumah Tangga', 'Lainnya'] as $category)
                        <option value="{{ $category }}"
                            @selected(old('category') === $category)>
                            {{ $category }}
                        </option>
                    @endforeach
                </select>
                @error('category')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label for="description"
                       class="mb-2 block font-medium text-gray-800">
                    Deskripsi Toko
                </label>
                <textarea id="description" name="description" rows="4"
                          maxlength="1000"
                          placeholder="Ceritakan produk yang kamu jual..."
                          class="w-full rounded-lg border border-gray-300 px-4 py-3 focus:border-red-500 focus:outline-none">{{ old('description') }}</textarea>
                @error('description')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label for="phone"
                       class="mb-2 block font-medium text-gray-800">
                    Nomor HP / WhatsApp *
                </label>
                <input id="phone" name="phone" type="tel"
                       value="{{ old('phone') }}"
                       maxlength="25" required
                       placeholder="Contoh: 08xxxxxxxxxx"
                       class="w-full rounded-lg border border-gray-300 px-4 py-3 focus:border-red-500 focus:outline-none">
                @error('phone')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label for="address"
                       class="mb-2 block font-medium text-gray-800">
                    Alamat Toko *
                </label>
                <textarea id="address" name="address" rows="3"
                          maxlength="1000" required
                          placeholder="Masukkan alamat lengkap..."
                          class="w-full rounded-lg border border-gray-300 px-4 py-3 focus:border-red-500 focus:outline-none">{{ old('address') }}</textarea>
                @error('address')
                    <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                @enderror
            </div>

            <div class="rounded-lg bg-orange-50 p-4 text-sm text-orange-800">
                <strong>Perhatian:</strong>
                Setelah dikirim, toko langsung dikonfirmasi tanpa menunggu pemeriksaan tambahan.
            </div>

            <button type="submit"
                    class="w-full rounded-lg bg-red-600 px-5 py-3 font-semibold text-white transition hover:bg-red-700">
                Buat dan Konfirmasi Toko
            </button>
        </form>
    @endif
</div>
@endsection
