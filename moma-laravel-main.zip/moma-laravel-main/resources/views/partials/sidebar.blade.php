<aside class="sidebar">
    <nav>
        <a class="{{ request()->routeIs('home') ? 'active' : '' }}" href="{{ route('home') }}">
            <span class="nav-mark">⌂</span>
            <span>Beranda</span>
        </a>
        <a class="{{ request()->routeIs('products') ? 'active' : '' }}" href="{{ route('products') }}">
            <span class="nav-mark">▦</span>
            <span>Semua Produk</span>
        </a>
        <a href="{{ route('category', 'semua') }}">
            <span class="nav-mark">◫</span>
            <span>Kategori</span>
            <i>›</i>
        </a>
        <a href="#">
            <span class="nav-mark">◎</span>
            <span>UMKM Lokal</span>
        </a>
        <a class="{{ request()->routeIs('voucher') ? 'active' : '' }}" href="{{ route('voucher') }}">
            <span class="nav-mark">◈</span>
            <span>Voucher</span>
        </a>

        @auth
            <a class="{{ request()->routeIs('orders') ? 'active' : '' }}" href="{{ route('orders') }}">
                <span class="nav-mark">▣</span>
                <span>Pesanan Saya</span>
            </a>
            <a class="{{ request()->routeIs('wishlist') ? 'active' : '' }}" href="{{ route('wishlist') }}">
                <span class="nav-mark">♡</span>
                <span>Wishlist</span>
            </a>
            <a class="{{ request()->routeIs('seller.*') ? 'active' : '' }}" href="{{ auth()->user()->store ? route('seller.dashboard') : route('stores.create') }}">
                <span class="nav-mark">◬</span>
                <span>Toko Saya</span>
            </a>
        @else
            <a href="{{ route('orders') }}">
                <span class="nav-mark">▣</span>
                <span>Pesanan Saya</span>
            </a>
            <a href="{{ route('wishlist') }}">
                <span class="nav-mark">♡</span>
                <span>Wishlist</span>
            </a>
        @endauth
    </nav>

    <div class="sidebar-promo">
        <x-moma-logo class="leaf" />
        <h3>Dukung<br>UMKM Lokal</h3>
        <p>Bersama Kami</p>
        <div class="heart">♡</div>
        <div class="promo-art">KULINER</div>
    </div>
</aside>