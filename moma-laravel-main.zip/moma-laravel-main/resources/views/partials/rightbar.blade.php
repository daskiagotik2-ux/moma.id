<aside class="rightbar">
    <div class="app-card">
        <div>
            <h2>Download<br>Aplikasi MoMa.id</h2>
            <p>Belanja lebih mudah,<br>lebih cepat, dan banyak promo!</p>
            <div class="store-buttons"><span>▶ Google Play</span><span> App Store</span></div>
        </div>
        <div class="phone">📱</div>
    </div>

    <div class="voucher-card">
        <h2>Voucher Spesial<br>Untuk Kamu!</h2>
        <p>Diskon hingga<br><strong>Rp 50.000</strong></p>
        <button type="button">Ambil Sekarang →</button>
        <span class="voucher-art">%</span>
    </div>

    <div class="umkm-card">
        <div class="side-title"><h2>UMKM Pilihan</h2><a href="#">Lihat Semua →</a></div>
        <div class="seller">
            <div class="seller-head">
                <span class="seller-logo">N</span>
                <div><strong>Dapur Bunda Aceh ✓</strong><small>● Banda Aceh</small></div>
                <button type="button">＋ Ikuti</button>
            </div>
            <div class="seller-meta">⭐ 4.9 &nbsp; • &nbsp; 2.8k Pengikut</div>
            <div class="mini-products"><span>🍪</span><span>🥟</span><span>🥬</span><span>🍘</span></div>
            <p>Produk khas Aceh dengan cita rasa autentik dan kualitas terbaik.</p>
        </div>
    </div>

    <div class="why-card">
        <h2>🌿 Mengapa Belanja di MoMa.id?</h2>
        <div class="why-grid">
            <div><span>🛡</span><p>100% Produk<br>Lokal</p></div>
            <div><span>⚙</span><p>Pembayaran<br>Aman</p></div>
            <div><span>🚚</span><p>Pengiriman<br>Cepat</p></div>
            <div><span>◉</span><p>Customer<br>Service 24/7</p></div>
        </div>
    </div>
</aside>