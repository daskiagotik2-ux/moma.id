<article class="product-card">
    <div class="product-image">
        @if($product->discount_percent > 0)
            <span class="product-badge">-{{ $product->discount_percent }}%</span>
        @endif
        <button class="wish-btn"
                data-wish-id="{{ $product->id }}"
                onclick="toggleWish({{ $product->id }}, this)">♡</button>
        @if($product->image)
            <img src="{{ $product->image }}" alt="{{ $product->name }}">
        @else
            <span>{{ $product->category->icon ?? '🛍️' }}</span>
        @endif
    </div>
    <div class="product-info">
        <span class="cat">{{ $product->category->name ?? 'Lainnya' }}</span>
        <h3>{{ $product->name }}</h3>
        <span class="loc">📍 {{ $product->location }}</span>
        <span class="rating">★ {{ number_format($product->rating, 1) }}
            <span>({{ $product->review_count }})</span></span>
        <div class="price-row">
            <div>
                <div class="price">{{ $product->formatted_price }}</div>
                @if($product->old_price)
                    <div class="price-old">{{ $product->formatted_old_price }}</div>
                @endif
            </div>
            <button class="add-cart"
                    onclick="addToCart({{ $product->id }}, @js($product->name), {{ $product->price }})">＋</button>
        </div>
    </div>
</article>