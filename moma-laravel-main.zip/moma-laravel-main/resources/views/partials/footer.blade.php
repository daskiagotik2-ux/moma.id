<footer class="market-footer">
    <div class="footer-main">
        <div class="footer-brand">
            <svg class="brand-mark" viewBox="0 0 52 58" fill="none" aria-hidden="true">
                <path d="M16 19v-4a10 10 0 0 1 20 0v4M11 19h30a4 4 0 0 1 4 4v27a5 5 0 0 1-5 5H12a5 5 0 0 1-5-5V23a4 4 0 0 1 4-4Z" stroke="white" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
                <text x="26" y="43" fill="white" font-family="Arial, sans-serif" font-size="23" font-weight="800" text-anchor="middle">M</text>
            </svg>
            <div>
                <strong>MoMa<span>.id</span></strong>
                <small>Belanja dari UMKM Indonesia</small>
                <p>Temukan produk lokal yang hebat, dari UMKM hingga toko pilihan.</p>
            </div>
        </div>

        <div class="footer-column">
            <h4>Belanja</h4>
            <a href="#">Cara Belanja</a>
            <a href="#">Pembayaran</a>
            <a href="#">Pengiriman</a>
            <a href="#">Pengembalian Barang</a>
            <a href="#">Pusat Bantuan</a>
        </div>

        <div class="footer-column">
            <h4>Tentang Kami</h4>
            <a href="#">Tentang Kami</a>
            <a href="#">Karier</a>
            <a href="#">Blog</a>
            <a href="#">Hubungi Kami</a>
            <a href="#">Partner UMKM</a>
        </div>

        <div class="footer-column">
            <h4>Bantuan</h4>
            <a href="#">Pusat Bantuan</a>
            <a href="#">Syarat & Ketentuan</a>
            <a href="#">Kebijakan Privasi</a>
            <a href="#">Keamanan</a>
            <a href="#">FAQ</a>
        </div>

        <div class="footer-column footer-social">
            <h4>Ikuti Kami</h4>
            <div class="social-links">
                <span title="Akun Instagram belum tersedia"><i class="fa-brands fa-instagram"></i><span>Instagram</span></span>
                <span title="Akun Facebook belum tersedia"><i class="fa-brands fa-facebook-f"></i><span>Facebook</span></span>
                <span title="Akun TikTok belum tersedia"><i class="fa-brands fa-tiktok"></i><span>TikTok</span></span>
                <span title="Akun YouTube belum tersedia"><i class="fa-brands fa-youtube"></i><span>YouTube</span></span>
                <span title="Akun WhatsApp belum tersedia"><i class="fa-brands fa-whatsapp"></i><span>WhatsApp</span></span>
            </div>
        </div>

        <div class="footer-newsletter">
            <div>
                <span class="footer-kicker">NEWSLETTER & PROMO</span>
                <h4>Dapatkan info terbaru & promo menarik</h4>
                <p>Promo lokal, produk baru, dan penawaran terbaik untukmu.</p>
            </div>
            <form class="footer-newsletter-form" onsubmit="return subscribeNewsletter(event)">
                <label class="sr-only" for="footer-email">Email</label>
                <input id="footer-email" type="email" required placeholder="Masukkan email kamu">
                <button type="submit">Daftar <i class="fa-solid fa-arrow-right"></i></button>
            </form>
        </div>

        <div class="footer-app" id="app-download">
            <div class="footer-app-copy">
                <span class="footer-kicker">APLIKASI MoMa.id</span>
                <h4>Belanja lebih cepat</h4>
                <p>Aplikasi MoMa.id untuk Android dan iOS segera hadir.</p>
            </div>
            <div class="app-downloads">
                <span class="app-store-button app-store-unavailable" aria-disabled="true" title="Aplikasi segera hadir">
                    <i class="fa-brands fa-google-play"></i>
                    <span><small>SEGERA HADIR</small><strong>Google Play</strong></span>
                </span>
                <span class="app-store-button app-store-unavailable" aria-disabled="true" title="Aplikasi segera hadir">
                    <i class="fa-brands fa-apple-pay"></i>
                    <span><small>SEGERA HADIR</small><strong>App Store</strong></span>
                </span>
            </div>
            <div class="footer-qr" aria-label="Aplikasi MoMa.id segera hadir">
                <i class="fa-solid fa-mobile-screen-button" aria-hidden="true"></i>
                <span>Segera hadir</span>
            </div>
        </div>
    </div>

    <div class="footer-bottom">
        <div class="footer-copyright">© 2026 MoMa.id. Semua hak cipta dilindungi.</div>
        <div class="footer-bottom-links">
            <span class="footer-language"><i class="fa-solid fa-globe"></i> Indonesia</span>
            <span>Bahasa Indonesia</span>
            <span class="footer-security"><i class="fa-solid fa-shield-halved"></i> Keamanan pembayaran</span>
        </div>
        <div class="footer-community">Bersama UMKM Indonesia <span>♡</span></div>
    </div>
</footer>