@php
    $headerStore = auth()->user()?->store;
    $sellerCenterTarget = auth()->guest() ? route('login') : ($headerStore ? route('seller.dashboard') : route('stores.create'));
    $currentHeaderNav = [
        'home' => request()->routeIs('home'),
        'categories' => request()->routeIs('kategori', 'category', 'kategori.placeholder'),
        'umkm' => request()->routeIs('shop', 'shop.show', 'moma-mall', 'makanan-lokal', 'fashion', 'kerajinan', 'toko-pilihan'),
        'promo' => request()->routeIs('promo', 'flash-sale', 'gratis-ongkir', 'voucher'),
        'selling' => request()->routeIs('stores.create', 'seller.*'),
    ];
@endphp
<header class="market-header sticky top-0 z-50" x-data="{ mobileMenuOpen: window.matchMedia('(min-width: 1024px)').matches }" @keydown.escape.window="mobileMenuOpen = false" @resize.window.debounce.150ms="mobileMenuOpen = window.matchMedia('(min-width: 1024px)').matches">
    <div class="hidden border-b border-white/10 bg-[#B91C2B] sm:block">
        <div class="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-1.5 text-[10px] font-semibold text-white/95 sm:px-6 lg:px-8">
            <nav class="flex flex-wrap items-center gap-x-3 gap-y-1" aria-label="Tautan informasi">
                <a href="{{ $sellerCenterTarget }}" class="transition-opacity hover:opacity-80">Seller Centre</a>
                <a href="{{ $sellerCenterTarget }}" class="transition-opacity hover:opacity-80">{{ $headerStore ? 'Toko Saya' : 'Mulai Berjualan' }}</a>
                <a href="{{ route('home') }}#app-download" class="transition-opacity hover:opacity-80">Download</a>
                <span class="text-white/85">Ikuti kami</span>
                <div class="flex items-center gap-2">
                    <span title="Akun Facebook belum tersedia" class="flex h-4 w-4 items-center justify-center rounded-full bg-white/10 text-[9px]"><i class="fa-brands fa-facebook-f"></i></span>
                    <span title="Akun Instagram belum tersedia" class="flex h-4 w-4 items-center justify-center rounded-full bg-white/10 text-[9px]"><i class="fa-brands fa-instagram"></i></span>
                    <span title="Akun TikTok belum tersedia" class="flex h-4 w-4 items-center justify-center rounded-full bg-white/10 text-[9px]"><i class="fa-brands fa-tiktok"></i></span>
                </div>
            </nav>

            <nav class="flex flex-wrap items-center gap-x-3 gap-y-1" aria-label="Akun pengguna">
                <a href="{{ route('orders') }}" class="inline-flex items-center gap-1 transition-opacity hover:opacity-80"><i class="fa-regular fa-bell"></i> Notifikasi</a>
                <a href="{{ route('help') }}" class="inline-flex items-center gap-1 transition-opacity hover:opacity-80"><i class="fa-regular fa-circle-question"></i> Bantuan</a>
                <span aria-current="true" class="inline-flex items-center gap-1"><i class="fa-solid fa-globe"></i> Bahasa Indonesia</span>
                @guest
                    <a href="{{ route('register') }}" class="transition-opacity hover:opacity-80">Daftar</a>
                @endguest
            </nav>
        </div>
    </div>

    <div class="bg-[#B91C2B]">
        <div class="mx-auto grid max-w-7xl grid-cols-[minmax(0,1fr)_auto] items-center gap-2 px-4 py-2 sm:px-6 lg:grid-cols-[180px_minmax(0,1fr)_auto] lg:gap-3 lg:px-8">
            <a href="{{ route('home') }}" class="order-1 inline-flex min-w-0 items-center gap-2.5 justify-self-start" aria-label="MoMa.id beranda">
                <x-moma-logo variant="white" class="h-10 w-10 shrink-0" aria-hidden="true" />
                <span class="whitespace-nowrap text-2xl font-extrabold leading-none text-white sm:text-[28px]">MoMa.id</span>
            </a>

            <div class="order-3 col-span-2 min-w-0 w-full lg:order-2 lg:col-span-1">
                <form action="{{ route('products') }}" method="GET" class="flex items-center overflow-hidden rounded-xl bg-white shadow-sm ring-1 ring-white/50">
                    <input
                        name="search"
                        type="search"
                        value="{{ request('search') }}"
                        placeholder="Cari produk, UMKM, atau kategori..."
                        autocomplete="off"
                        class="w-full border-0 bg-transparent px-3 py-2 text-sm text-slate-700 placeholder:text-slate-400 focus:outline-none sm:text-[13px]"
                    >
                    <button type="submit" aria-label="Cari" class="flex h-10 w-10 items-center justify-center border-0 bg-transparent text-base text-[#B91C2B] transition-colors hover:text-[#4A171D] sm:h-11 sm:w-11">
                        <i class="fa-solid fa-magnifying-glass"></i>
                    </button>
                </form>
            </div>

            <div class="order-2 flex items-center justify-end gap-2 sm:gap-3 lg:order-3">
                @auth
                    <a href="{{ route('wishlist') }}" aria-label="Wishlist" class="header-action">
                        <i class="fa-regular fa-heart"></i>
                    </a>
                    <a href="{{ route('cart.index') }}" aria-label="Keranjang" class="header-action relative">
                        <i class="fa-solid fa-cart-shopping"></i>
                        <span class="header-badge" id="cartCount">{{ array_sum(session('cart', [])) }}</span>
                    </a>
                    <div class="relative hidden sm:block" x-data="{ open: false }">
                        <button type="button" @click="open = !open" class="flex items-center gap-2 rounded-full border border-white/30 bg-white/5 px-2 py-1.5 text-white transition-colors hover:bg-white/10">
                            <span class="flex h-8 w-8 items-center justify-center rounded-full bg-white text-xs font-bold text-[#B91C2B]">{{ strtoupper(substr(Auth::user()->name, 0, 1)) }}</span>
                            <i class="fa-solid fa-chevron-down text-[10px]"></i>
                        </button>
                        <div x-show="open" @click.outside="open = false" x-cloak class="absolute right-0 top-full z-50 mt-2 w-44 rounded-xl border border-slate-200 bg-white p-2 shadow-xl">
                            <a href="{{ route('dashboard') }}" class="block rounded-lg px-3 py-2 text-sm text-slate-700 transition hover:bg-[#FFF4F1] hover:text-[#B91C2B]">Dashboard</a>
                            <a href="{{ route('orders') }}" class="block rounded-lg px-3 py-2 text-sm text-slate-700 transition hover:bg-[#FFF4F1] hover:text-[#B91C2B]">Pesanan Saya</a>
                            <a href="{{ route('profile.edit') }}" class="block rounded-lg px-3 py-2 text-sm text-slate-700 transition hover:bg-[#FFF4F1] hover:text-[#B91C2B]">Profil</a>
                            <form method="POST" action="{{ route('logout') }}">
                                @csrf
                                <button type="submit" class="mt-1 w-full rounded-lg px-3 py-2 text-left text-sm text-slate-700 transition hover:bg-red-50 hover:text-red-600">Keluar</button>
                            </form>
                        </div>
                    </div>
                    <button type="button" class="header-action mobile-menu-toggle inline-flex !h-10 !w-10 shrink-0 items-center justify-center" aria-controls="primary-navigation" :aria-expanded="mobileMenuOpen" :aria-label="mobileMenuOpen ? 'Tutup menu' : 'Buka menu'" @click="mobileMenuOpen = !mobileMenuOpen">
                        <i class="fa-solid" :class="mobileMenuOpen ? 'fa-xmark' : 'fa-bars'" aria-hidden="true"></i>
                    </button>
                @else
                    <a href="{{ route('wishlist') }}" aria-label="Daftar atau masuk untuk melihat wishlist" title="Daftar atau masuk untuk melihat wishlist" class="header-action">
                        <i class="fa-regular fa-heart"></i>
                    </a>
                    <a href="{{ route('cart.index') }}" aria-label="Keranjang" class="header-action relative">
                        <i class="fa-solid fa-cart-shopping"></i>
                        <span class="header-badge" id="cartCount">{{ array_sum(session('cart', [])) }}</span>
                    </a>
                    <button type="button" class="header-action mobile-menu-toggle inline-flex !h-10 !w-10 shrink-0 items-center justify-center" aria-controls="primary-navigation" :aria-expanded="mobileMenuOpen" :aria-label="mobileMenuOpen ? 'Tutup menu' : 'Buka menu'" @click="mobileMenuOpen = !mobileMenuOpen">
                        <i class="fa-solid" :class="mobileMenuOpen ? 'fa-xmark' : 'fa-bars'" aria-hidden="true"></i>
                    </button>
                @endauth
            </div>
        </div>
    </div>

    <div class="primary-navigation-shell border-t border-white/10 bg-[#B91C2B]" :class="{ 'navigation-shell-open': mobileMenuOpen }">
        <nav id="primary-navigation" class="primary-navigation mx-auto max-w-7xl items-center gap-5 overflow-x-auto px-4 py-3 text-sm font-semibold text-white sm:px-6 lg:gap-8 lg:px-8" :class="{ 'navigation-open': mobileMenuOpen }" aria-label="Navigasi utama">
            <a href="{{ route('home') }}" @click="mobileMenuOpen = false" @class(['header-nav-link', 'header-nav-link-active' => $currentHeaderNav['home']]) @if($currentHeaderNav['home']) aria-current="page" @endif>Beranda</a>
            <a href="{{ route('kategori') }}" @click="mobileMenuOpen = false" @class(['header-nav-link', 'header-nav-link-active' => $currentHeaderNav['categories']]) @if($currentHeaderNav['categories']) aria-current="page" @endif>Kategori</a>
            <a href="{{ route('shop') }}" @click="mobileMenuOpen = false" @class(['header-nav-link', 'header-nav-link-active' => $currentHeaderNav['umkm']]) @if($currentHeaderNav['umkm']) aria-current="page" @endif>UMKM</a>
            <a href="{{ route('promo') }}" @click="mobileMenuOpen = false" @class(['header-nav-link', 'header-nav-link-active' => $currentHeaderNav['promo']]) @if($currentHeaderNav['promo']) aria-current="page" @endif>Promo</a>
            <a href="{{ $sellerCenterTarget }}" @click="mobileMenuOpen = false" @class(['header-nav-link', 'header-nav-link-active' => $currentHeaderNav['selling']]) @if($currentHeaderNav['selling']) aria-current="page" @endif>{{ $headerStore ? 'Seller Center' : 'Mulai Berjualan' }}</a>
            @guest
                <a href="{{ route('login') }}" @click="mobileMenuOpen = false" class="mobile-auth-link header-nav-link">Masuk</a>
                <a href="{{ route('register') }}" @click="mobileMenuOpen = false" class="mobile-auth-link header-nav-link">Daftar</a>
            @endguest
        </nav>
    </div>
</header>