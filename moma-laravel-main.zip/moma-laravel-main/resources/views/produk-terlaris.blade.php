@extends('layouts.app')

@section('title', 'Produk Terlaris | Nusantara Mart')

@section('content')
    <main class="terlaris-page">
        <section class="terlaris-hero">
            <div class="terlaris-hero-copy">
                <div class="terlaris-kicker"><i class="fa-solid fa-chart-line"></i> Ranking marketplace</div>
                <h1>Produk Terlaris</h1>
                <p>Produk yang paling banyak dibeli oleh pelanggan MoMa.id.</p>
                <div class="terlaris-hero-stats">
                    <div><strong>{{ $products->count() }}</strong><span> Produk ranked</span></div>
                    <div><strong>Top 5</strong><span> Paling populer</span></div>
                    <div><strong>30 hari</strong><span> Data terakhir</span></div>
                </div>
            </div>
            <div class="terlaris-hero-visual" aria-hidden="true">
                <div class="terlaris-chart-card">
                    <span>TOP SELLING</span>
                    <strong>5</strong>
                    <small>PRODUK</small>
                    <i class="fa-solid fa-arrow-trend-up"></i>
                </div>
                <div class="terlaris-badge"><i class="fa-solid fa-crown"></i> #1 Terlaris</div>
            </div>
        </section>

        <section class="terlaris-ranking-section">
            <div class="terlaris-section-heading">
                <div>
                    <span>Top products</span>
                    <h2>Daftar penjualan paling populer</h2>
                </div>
                <p>Ranking disusun berdasarkan rating dan volume ulasan dari data produk terkini.</p>
            </div>

            <div class="terlaris-filter-bar" aria-label="Filter periode produk terlaris">
                <div class="terlaris-filter-label">
                    <i class="fa-solid fa-sliders"></i>
                    <span>Filter periode</span>
                </div>
                <div class="terlaris-filter-options">
                    @foreach ([
                        'hari' => 'Terlaris hari ini',
                        'minggu' => 'Minggu ini',
                        'bulan' => 'Bulan ini',
                    ] as $key => $label)
                        <a href="{{ route('produk-terlaris', ['filter' => $key]) }}"
                           class="terlaris-filter-button {{ $filter === $key ? 'active' : '' }}">
                            {{ $label }}
                        </a>
                    @endforeach
                </div>
            </div>

            @if ($products->isNotEmpty())
                <div class="terlaris-rank-list">
                    @foreach ($products as $product)
                        <article class="terlaris-product-card rank-{{ $product['rank'] }}">
                            <div class="terlaris-rank-number">
                                <span>#{{ $product['rank'] }}</span>
                                @if ($product['rank'] === 1)
                                    <i class="fa-solid fa-crown"></i>
                                @endif
                            </div>
                            <div class="terlaris-product-image">
                                @if ($product['image'])
                                    <img src="https://images.unsplash.com/{{ $product['image'] }}?auto=format&fit=crop&w=700&q=80" alt="{{ $product['name'] }}" loading="lazy">
                                @else
                                    <div class="terlaris-product-placeholder"><i class="fa-solid fa-box"></i></div>
                                @endif
                                <span class="terlaris-badge"><i class="fa-solid fa-fire"></i> Terlaris</span>
                            </div>
                            <div class="terlaris-product-content">
                                <div class="terlaris-product-topline">
                                    <span>{{ $product['seller'] }}</span>
                                    <span class="terlaris-location"><i class="fa-solid fa-location-dot"></i> {{ $product['location'] }}</span>
                                </div>
                                <h3>{{ $product['name'] }}</h3>
                                <div class="terlaris-product-meta">
                                    <span class="terlaris-rating"><i class="fa-solid fa-star"></i> {{ number_format($product['rating'], 1) }}</span>
                                    <span><i class="fa-solid fa-bag-shopping"></i> {{ number_format($product['sold']) }} terjual</span>
                                </div>
                                <div class="terlaris-product-price">
                                    <strong>Rp{{ number_format($product['price']) }}</strong>
                                    @if ($product['old_price'])
                                        <del>Rp{{ number_format($product['old_price']) }}</del>
                                    @endif
                                </div>
                            </div>
                            <a href="{{ route('shop') }}" class="terlaris-view-button">
                                Lihat toko <i class="fa-solid fa-arrow-right"></i>
                            </a>
                        </article>
                    @endforeach
                </div>
            @else
                <div class="terlaris-empty">
                    <i class="fa-solid fa-chart-line"></i>
                    <h3>Belum ada data ranking</h3>
                    <p>Produk akan muncul di sini setelah tersedia di database.</p>
                    <a href="{{ route('products') }}">Lihat semua produk</a>
                </div>
            @endif
        </section>
    </main>
@endsection
