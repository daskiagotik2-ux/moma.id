<?php

namespace App\Services;

use App\Contracts\PaymentGateway;
use App\Enums\PaymentMethod;
use App\Enums\PaymentRecordStatus;
use App\Models\Order;
use App\Models\Payment;

class ManualPayment implements PaymentGateway
{
    public function createPayment(Order $order, PaymentMethod $method): Payment
    {
        return $order->payments()->create([
            'method' => $method->value,
            'amount' => $order->grand_total,
            'status' => PaymentRecordStatus::Pending->value,
        ]);
    }
}
