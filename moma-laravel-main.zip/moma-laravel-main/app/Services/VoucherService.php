<?php

namespace App\Services;

use App\Models\Voucher;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Str;

class VoucherService
{
    public const BASE_SHIPPING_COST = 15000;

    public function availableVouchers(): Builder
    {
        return $this->availableQuery()->orderBy('ends_at')->orderBy('id');
    }

    public function findAvailable(string $code, bool $lock = false): ?Voucher
    {
        $query = $this->availableQuery()->whereRaw('UPPER(code) = ?', [Str::upper($code)]);

        if ($lock) {
            $query->lockForUpdate();
        }

        return $query->first();
    }

    public function unavailableMessage(): string
    {
        return 'Voucher tidak aktif, sudah kedaluwarsa, atau kuotanya habis.';
    }

    public function minimumSpendMessage(Voucher $voucher): string
    {
        return 'Voucher ini membutuhkan minimum belanja Rp'.number_format($voucher->min_spend, 0, ',', '.').'.';
    }

    public function discountAmount(Voucher $voucher, int $subtotal): int
    {
        if ($subtotal < $voucher->min_spend) {
            return 0;
        }

        $discount = match ($voucher->type) {
            'discount' => min($subtotal, $voucher->amount),
            'shipping' => min(self::BASE_SHIPPING_COST, $voucher->amount),
            'cashback' => min($subtotal, intdiv($subtotal * $voucher->amount, 100)),
            default => 0,
        };

        return $voucher->max_discount === null
            ? $discount
            : min($discount, $voucher->max_discount);
    }

    private function availableQuery(): Builder
    {
        $now = now();

        return Voucher::query()
            ->where('is_active', true)
            ->where(fn (Builder $query) => $query->whereNull('starts_at')->orWhere('starts_at', '<=', $now))
            ->where(fn (Builder $query) => $query->whereNull('ends_at')->orWhere('ends_at', '>', $now))
            ->where(fn (Builder $query) => $query->whereNull('quota')->orWhereColumn('used_count', '<', 'quota'));
    }
}
