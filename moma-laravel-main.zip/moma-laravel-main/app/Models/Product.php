<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Product extends Model
{
    protected $fillable = [
        'store_id', 'category_id', 'name', 'slug', 'description', 'seller',
        'location', 'price', 'old_price', 'discount_percent',
        'rating', 'review_count', 'image', 'is_featured', 'stock',
    ];

    protected $casts = [
        'price' => 'integer',
        'old_price' => 'integer',
        'discount_percent' => 'integer',
        'rating' => 'float',
        'review_count' => 'integer',
        'is_featured' => 'boolean',
        'stock' => 'integer',
    ];

    protected static function booted(): void
    {
        static::addGlobalScope('marketplace_approved_store', function (Builder $query) {
            $query->where(function (Builder $visible) {
                $visible->whereNull('store_id')
                    ->orWhereHas('store', fn (Builder $store) => $store->where('status', 'approved'));
            });
        });
    }

    public function category(): BelongsTo
    {
        return $this->belongsTo(Category::class);
    }

    public function store(): BelongsTo
    {
        return $this->belongsTo(Store::class);
    }

    public function orderItems(): HasMany
    {
        return $this->hasMany(OrderItem::class);
    }

    public function flashSaleItems(): HasMany
    {
        return $this->hasMany(FlashSaleItem::class);
    }

    public function flashSales(): BelongsToMany
    {
        return $this->belongsToMany(FlashSale::class, 'flash_sale_items')
            ->withPivot(['id', 'sale_price', 'stock_limit', 'sold_count'])
            ->withTimestamps();
    }

    public function getFormattedPriceAttribute(): string
    {
        return 'Rp '.number_format($this->price, 0, ',', '.');
    }

    public function getFormattedOldPriceAttribute(): string
    {
        return $this->old_price ? 'Rp '.number_format($this->old_price, 0, ',', '.') : '';
    }

    public function getImageAttribute(?string $value): ?string
    {
        if ($value === null || preg_match('/^(https?:)?\/\//i', $value) || str_starts_with($value, 'data:')) {
            return $value;
        }

        $path = ltrim($value, '/');
        if (str_starts_with($path, 'storage/')) {
            $path = substr($path, strlen('storage/'));
        }

        return '/storage/'.$path;
    }
}
