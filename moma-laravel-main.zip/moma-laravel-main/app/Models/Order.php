<?php

namespace App\Models;

use App\Enums\PaymentMethod;
use App\Enums\PaymentStatus;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Order extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'order_number',
        'status',
        'subtotal',
        'shipping_cost',
        'shipping_address',
        'contact_phone',
        'voucher_code',
        'discount_amount',
        'payment_method',
        'payment_status',
        'payment_expires_at',
        'paid_at',
        'grand_total',
    ];

    protected $casts = [
        'subtotal' => 'integer',
        'shipping_cost' => 'integer',
        'discount_amount' => 'integer',
        'payment_method' => PaymentMethod::class,
        'payment_status' => PaymentStatus::class,
        'payment_expires_at' => 'datetime',
        'paid_at' => 'datetime',
        'grand_total' => 'integer',
    ];

    protected static function booted(): void
    {
        static::creating(function (Order $order): void {
            if ($order->grand_total === null) {
                $order->grand_total = max(0, (int) $order->subtotal + (int) ($order->shipping_cost ?? 0) - (int) ($order->discount_amount ?? 0));
            }
        });
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function items(): HasMany
    {
        return $this->hasMany(OrderItem::class);
    }

    public function payments(): HasMany
    {
        return $this->hasMany(Payment::class);
    }
}