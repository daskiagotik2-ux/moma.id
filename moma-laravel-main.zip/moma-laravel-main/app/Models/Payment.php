<?php

namespace App\Models;

use App\Enums\PaymentMethod;
use App\Enums\PaymentRecordStatus;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Payment extends Model
{
    use HasFactory;

    protected $fillable = [
        'order_id',
        'method',
        'amount',
        'proof_path',
        'status',
        'reference',
        'verified_by',
        'verified_at',
        'note',
    ];

    protected $casts = [
        'method' => PaymentMethod::class,
        'amount' => 'integer',
        'status' => PaymentRecordStatus::class,
        'verified_at' => 'datetime',
    ];

    public function order(): BelongsTo
    {
        return $this->belongsTo(Order::class);
    }

    public function verifier(): BelongsTo
    {
        return $this->belongsTo(User::class, 'verified_by');
    }

    public function approvals(): HasMany
    {
        return $this->hasMany(PaymentApproval::class);
    }
}
