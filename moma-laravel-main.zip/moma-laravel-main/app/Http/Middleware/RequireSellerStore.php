<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class RequireSellerStore
{
    public function handle(Request $request, Closure $next): Response
    {
        if (! $request->user()->store) {
            return redirect()->route('stores.create')->with('error', 'Buka toko terlebih dahulu untuk mengakses Seller Center.');
        }

        return $next($request);
    }
}
