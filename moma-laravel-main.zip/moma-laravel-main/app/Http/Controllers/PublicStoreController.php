<?php

namespace App\Http\Controllers;

use App\Models\Store;
use Illuminate\View\View;

class PublicStoreController extends Controller
{
    public function show(Store $store): View
    {
        abort_unless($store->status === 'approved', 404);

        $products = $store->products()
            ->with('category')
            ->latest()
            ->paginate(12);

        return view('store-public', compact('store', 'products'));
    }
}
