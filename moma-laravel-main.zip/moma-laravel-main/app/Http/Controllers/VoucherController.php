<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\FlashSaleItem;
use App\Models\Voucher;
use App\Services\VoucherService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;

class VoucherController extends Controller
{
    public function index(Request $request, VoucherService $voucherService): View
    {
        $filter = $request->query('filter', 'semua');
        if (! in_array($filter, ['semua', 'gratis-ongkir', 'diskon', 'cashback'], true)) {
            $filter = 'semua';
        }

        $vouchers = $voucherService->availableVouchers()
            ->get()
            ->map(fn (Voucher $voucher) => $this->presentVoucher($voucher))
            ->when($filter !== 'semua', fn (Collection $vouchers) => $vouchers->where('category', $filter))
            ->values();

        $popularVouchers = $vouchers->take(3);

        return view('voucher', compact('vouchers', 'popularVouchers', 'filter'));
    }

    public function claim(Request $request, VoucherService $voucherService): RedirectResponse|JsonResponse
    {
        $validated = $request->validate([
            'code' => ['required', 'string', 'max:100'],
        ]);
        $code = Str::upper(trim($validated['code']));
        $voucher = $voucherService->findAvailable($code);

        if (! $voucher) {
            throw ValidationException::withMessages(['code' => $voucherService->unavailableMessage()]);
        }

        $cart = $request->session()->get('cart', []);
        if ($cart !== []) {
            $subtotal = $this->cartSubtotal($request);

            if ($subtotal < $voucher->min_spend) {
                throw ValidationException::withMessages(['code' => $voucherService->minimumSpendMessage($voucher)]);
            }
        }

        $request->session()->put('checkout_voucher_code', $code);

        if ($request->expectsJson()) {
            return response()->json([
                'message' => 'Kode voucher disimpan dan siap digunakan saat checkout.',
                'checkoutUrl' => empty($cart) ? null : route('checkout.create'),
            ]);
        }

        return back()->with('success', 'Kode voucher disimpan dan siap digunakan saat checkout.');
    }

    private function cartSubtotal(Request $request): int
    {
        $cart = $request->session()->get('cart', []);
        $products = Product::query()->whereKey(array_keys($cart))->get()->keyBy('id');
        $flashSaleItemsByProduct = $request->session()->get('flash_sale_items', []);
        $flashSaleItems = FlashSaleItem::with('flashSale')
            ->whereIn('id', array_values($flashSaleItemsByProduct))
            ->get()
            ->keyBy('id');
        $now = now();
        $subtotal = 0;

        foreach ($cart as $productId => $quantity) {
            $product = $products->get($productId);
            if (! $product) {
                continue;
            }

            $flashSaleItem = $flashSaleItems->get($flashSaleItemsByProduct[$productId] ?? null);
            $flashSale = $flashSaleItem?->flashSale;
            $isFlashSale = $flashSaleItem
                && (int) $flashSaleItem->product_id === (int) $productId
                && $flashSale
                && $flashSale->is_active
                && $flashSale->starts_at->lte($now)
                && $flashSale->ends_at->gt($now);

            $subtotal += ($isFlashSale ? $flashSaleItem->sale_price : $product->price) * (int) $quantity;
        }

        return $subtotal;
    }

    public function clear(Request $request): RedirectResponse
    {
        $request->session()->forget('checkout_voucher_code');

        return redirect()->route('checkout.create')->with('success', 'Voucher dihapus dari checkout.');
    }

    private function presentVoucher(Voucher $voucher): array
    {
        return [
            'category' => match ($voucher->type) {
                'shipping' => 'gratis-ongkir',
                default => $voucher->type,
            },
            'label' => match ($voucher->type) {
                'shipping' => 'GRATIS ONGKIR',
                'cashback' => 'CASHBACK',
                default => 'DISKON',
            },
            'title' => match ($voucher->type) {
                'shipping' => 'Potongan ongkir Rp'.number_format($voucher->amount, 0, ',', '.'),
                'cashback' => 'Cashback '.$voucher->amount.'%',
                default => 'Diskon Rp'.number_format($voucher->amount, 0, ',', '.'),
            },
            'amount' => $voucher->amount,
            'is_percentage' => $voucher->type === 'cashback',
            'minimum' => $voucher->min_spend,
            'code' => $voucher->code,
            'valid_until' => $voucher->ends_at?->locale('id')->translatedFormat('d F Y') ?? 'tanpa batas waktu',
            'description' => match ($voucher->type) {
                'shipping' => 'Potongan biaya pengiriman untuk belanja lokalmu.',
                'cashback' => 'Cashback dihitung sebagai potongan saat checkout.',
                default => 'Potongan harga untuk belanja lokalmu.',
            },
            'accent' => match ($voucher->type) {
                'shipping' => 'orange',
                'cashback' => 'gold',
                default => 'red',
            },
            'icon' => match ($voucher->type) {
                'shipping' => 'fa-truck-fast',
                'cashback' => 'fa-wallet',
                default => 'fa-percent',
            },
        ];
    }
}
