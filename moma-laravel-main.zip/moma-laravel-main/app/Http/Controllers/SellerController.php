<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\OrderItem;
use App\Enums\PaymentMethod;
use App\Enums\PaymentRecordStatus;
use App\Enums\PaymentStatus;
use App\Models\Payment;
use App\Models\PaymentApproval;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;

class SellerController extends Controller
{
    public function dashboard(Request $request): View
    {
        $store = $request->user()->store;

        if (! $store) {
            return view('seller.no-store');
        }

        $products = $store->products()->withoutGlobalScope('marketplace_approved_store');
        $storeProduct = fn (Builder $product) => $product->withoutGlobalScope('marketplace_approved_store')->where('store_id', $store->id);
        $orderQuery = Order::query()->whereHas('items.product', $storeProduct);
        $recentOrders = (clone $orderQuery)->with([
            'user',
            'items' => fn ($items) => $items->whereHas('product', $storeProduct),
        ])->latest()->take(5)->get();

        $metrics = [
            'activeProducts' => (clone $products)->where(fn ($query) => $query->whereNull('stock')->orWhere('stock', '>', 0))->count(),
            'stock' => (int) (clone $products)->sum('stock'),
            'orders' => (clone $orderQuery)->count(),
            'sales' => (int) OrderItem::query()
                ->whereHas('product', fn (Builder $product) => $product->withoutGlobalScope('marketplace_approved_store')->where('store_id', $store->id))
                ->selectRaw('COALESCE(SUM(quantity * price), 0) as total')
                ->value('total'),
        ];

        $recentProducts = $store->products()->withoutGlobalScope('marketplace_approved_store')->with('category')->latest()->take(5)->get();

        return view('seller.dashboard', compact('store', 'metrics', 'recentProducts', 'recentOrders'));
    }

    public function orders(Request $request): View
    {
        $store = $request->user()->store;
        if (! $store) {
            return view('seller.no-store');
        }

        $storeProduct = fn (Builder $product) => $product->withoutGlobalScope('marketplace_approved_store')->where('store_id', $store->id);
        $orders = Order::query()
            ->whereHas('items.product', $storeProduct)
            ->with([
                'user',
                'items' => fn ($items) => $items->whereHas('product', $storeProduct),
                'payments' => fn ($payments) => $payments->with('approvals')->latest('id'),
            ])
            ->latest()
            ->paginate(15);

        return view('seller.orders', compact('store', 'orders'));
    }

    public function verifyPayment(Request $request, Order $order, Payment $payment): RedirectResponse
    {
        abort_unless($payment->order_id === $order->id, 404);
        $this->authorize('verify', $payment);

        $validated = $request->validate([
            'decision' => ['required', 'in:approve,reject'],
            'note' => ['nullable', 'string', 'max:1000'],
        ], [
            'decision.required' => 'Pilih keputusan verifikasi.',
            'decision.in' => 'Keputusan verifikasi tidak valid.',
        ]);

        $result = DB::transaction(function () use ($request, $order, $payment, $validated) {
            $lockedOrder = Order::query()->whereKey($order->id)->lockForUpdate()->firstOrFail();
            $lockedPayment = Payment::query()->whereKey($payment->id)->lockForUpdate()->firstOrFail();
            $this->authorize('verify', $lockedPayment);

            if (
                $lockedPayment->status !== PaymentRecordStatus::Pending
                || $lockedOrder->payment_status !== PaymentStatus::WaitingVerification
            ) {
                return 'processed';
            }
            if ($lockedOrder->payment_expires_at?->isPast()) {
                throw ValidationException::withMessages(['payment' => 'Batas waktu pembayaran telah berakhir.']);
            }
            if (! $lockedPayment->proof_path) {
                throw ValidationException::withMessages(['payment' => 'Bukti pembayaran tidak ditemukan.']);
            }

            $store = $request->user()->store;
            $approved = $validated['decision'] === 'approve';
            if (! $approved) {
                $lockedPayment->update([
                    'status' => PaymentRecordStatus::Rejected,
                    'verified_by' => $request->user()->id,
                    'verified_at' => now(),
                    'note' => $validated['note'] ?? null,
                ]);
                $lockedOrder->update(['payment_status' => PaymentStatus::Failed]);

                return 'rejected';
            }

            PaymentApproval::query()->firstOrCreate(
                ['payment_id' => $lockedPayment->id, 'store_id' => $store->id],
                [
                    'approved_by' => $request->user()->id,
                    'note' => $validated['note'] ?? null,
                ],
            );

            $participatingStoreIds = $lockedOrder->items()
                ->join('products', 'order_items.product_id', '=', 'products.id')
                ->whereNotNull('products.store_id')
                ->distinct()
                ->pluck('products.store_id');
            $approvedStoreCount = $lockedPayment->approvals()
                ->whereIn('store_id', $participatingStoreIds)
                ->count();

            if ($participatingStoreIds->isEmpty()) {
                throw ValidationException::withMessages(['payment' => 'Pesanan ini tidak memiliki toko yang dapat memverifikasi pembayaran.']);
            }

            if ($approvedStoreCount === $participatingStoreIds->count()) {
                $lockedPayment->update([
                    'status' => PaymentRecordStatus::Verified,
                    'verified_by' => $request->user()->id,
                    'verified_at' => now(),
                ]);
                $lockedOrder->update([
                    'payment_status' => PaymentStatus::Paid,
                    'status' => 'awaiting_confirmation',
                    'paid_at' => now(),
                ]);

                return 'verified';
            }

            return 'approved';
        });

        $message = match ($result) {
            'rejected' => 'Bukti pembayaran ditolak. Pembeli dapat mengunggah ulang sebelum batas waktu.',
            'verified' => 'Toko Anda menyetujui bukti. Semua toko telah menyetujui; pesanan kini dapat diproses.',
            'approved' => 'Persetujuan toko Anda tercatat. Menunggu persetujuan toko lain pada pesanan ini.',
            default => 'Pembayaran ini sudah diproses sebelumnya.',
        };

        return redirect()->route('seller.orders')->with('success', $message);
    }

    public function approveOrder(Request $request, Order $order): RedirectResponse
    {
        $store = $request->user()->store;
        $this->authorize('approve', $order);

        DB::transaction(function () use ($order, $store) {
            $lockedOrder = Order::query()->whereKey($order->id)->lockForUpdate()->firstOrFail();
            $this->authorize('approve', $lockedOrder);
            $storeProduct = fn (Builder $product) => $product
                ->withoutGlobalScope('marketplace_approved_store')
                ->where('store_id', $store->id);
            $storeItems = $lockedOrder->items()
                ->whereHas('product', $storeProduct)
                ->lockForUpdate()
                ->get();

            abort_if($storeItems->isEmpty(), 404);

            if ($lockedOrder->status !== 'awaiting_confirmation') {
                abort(422, $lockedOrder->status === 'awaiting_payment'
                    ? 'Pesanan belum dapat diproses. Bukti pembayaran masih menunggu verifikasi toko.'
                    : 'Pesanan ini tidak lagi menunggu konfirmasi.');
            }

            if ($lockedOrder->payment_method !== PaymentMethod::Cod && $lockedOrder->payment_status !== PaymentStatus::Paid) {
                abort(422, 'Pesanan belum dapat diproses. Pembayaran non-COD harus disetujui seluruh toko terlebih dahulu.');
            }

            $pendingItems = $storeItems->where('seller_status', 'pending');

            if ($pendingItems->isEmpty()) {
                abort(422, 'Pesanan dari toko Anda sudah disetujui.');
            }

            $lockedOrder->items()
                ->whereIn('id', $pendingItems->pluck('id'))
                ->update(['seller_status' => 'accepted']);

            $hasPendingSellerItems = $lockedOrder->items()
                ->where('seller_status', 'pending')
                ->exists();

            if (! $hasPendingSellerItems) {
                $lockedOrder->update(['status' => 'processing']);
            }
        });

        return redirect()->route('seller.orders')->with('success', 'Pesanan toko Anda berhasil disetujui.');
    }

    public function shipOrder(Request $request, Order $order): RedirectResponse
    {
        $store = $request->user()->store;
        $this->authorize('approve', $order);

        $allItemsShipped = DB::transaction(function () use ($request, $order, $store) {
            $lockedOrder = Order::query()->whereKey($order->id)->lockForUpdate()->firstOrFail();
            $this->authorize('approve', $lockedOrder);

            if (! in_array($lockedOrder->status, ['processing', 'shipped'], true)) {
                abort(422, 'Pesanan harus disetujui semua toko sebelum dikirim.');
            }

            if ($lockedOrder->payment_method !== PaymentMethod::Cod && $lockedOrder->payment_status !== PaymentStatus::Paid) {
                abort(422, 'Pembayaran harus lunas sebelum pesanan dikirim.');
            }

            $storeProduct = fn (Builder $product) => $product
                ->withoutGlobalScope('marketplace_approved_store')
                ->where('store_id', $store->id);
            $storeItems = $lockedOrder->items()
                ->whereHas('product', $storeProduct)
                ->lockForUpdate()
                ->get();
            abort_if($storeItems->isEmpty(), 404);

            $acceptedItems = $storeItems->where('seller_status', 'accepted');
            if ($acceptedItems->isEmpty()) {
                abort(422, 'Tidak ada produk toko yang siap dikirim.');
            }

            $lockedOrder->items()
                ->whereIn('id', $acceptedItems->pluck('id'))
                ->update(['seller_status' => 'shipped']);

            $allShipped = ! $lockedOrder->items()
                ->whereNotIn('seller_status', ['shipped', 'completed'])
                ->exists();

            if ($allShipped) {
                $lockedOrder->update(['status' => 'shipped']);
            }

            return $allShipped;
        });

        $message = $allItemsShipped
            ? 'Semua produk sudah dikirim. Pembeli dapat mengonfirmasi penerimaan.'
            : 'Produk toko Anda ditandai sudah dikirim. Menunggu toko lain mengirim.';

        return redirect()->route('seller.orders')->with('success', $message);
    }

    public function statistics(Request $request): View
    {
        $store = $request->user()->store;
        if (! $store) {
            return view('seller.no-store');
        }

        $storeProduct = fn (Builder $product) => $product->withoutGlobalScope('marketplace_approved_store')->where('store_id', $store->id);
        $orders = Order::query()
            ->whereHas('items.product', $storeProduct)
            ->with(['user', 'items' => fn ($items) => $items->whereHas('product', $storeProduct)])
            ->latest()
            ->paginate(15);
        $sales = (int) OrderItem::query()
            ->whereHas('product', fn (Builder $product) => $product->withoutGlobalScope('marketplace_approved_store')->where('store_id', $store->id))
            ->selectRaw('COALESCE(SUM(quantity * price), 0) as total')
            ->value('total');

        return view('seller.statistics', compact('store', 'orders', 'sales'));
    }

    public function settings(Request $request): View
    {
        $store = $request->user()->store;

        return $store ? view('seller.settings', compact('store')) : view('seller.no-store');
    }
}
