<?php

namespace App\Http\Controllers;

use App\Models\Voucher;
use App\Services\VoucherService;
use Illuminate\Http\Request;
use Illuminate\View\View;

class GratisOngkirController extends Controller
{
    public function index(Request $request, VoucherService $voucherService): View
    {
        $vouchers = $voucherService->availableVouchers()
            ->where('type', 'shipping')
            ->get()
            ->map(fn (Voucher $voucher) => [
                'code' => $voucher->code,
                'label' => 'Potongan ongkir Rp'.number_format($voucher->amount, 0, ',', '.'),
                'minimum' => $voucher->min_spend,
                'maximum' => min($voucher->amount, VoucherService::BASE_SHIPPING_COST),
                'valid_until' => $voucher->ends_at?->locale('id')->translatedFormat('d F Y') ?? 'tanpa batas waktu',
                'accent' => 'orange',
            ]);

        $products = [
            [
                'name' => 'Kopi Gayo Arabica',
                'seller' => 'Kopi Nusantara',
                'location' => 'Aceh',
                'price' => 45000,
                'old_price' => 60000,
                'rating' => 4.9,
                'image' => 'photo-1442512595331-e89e73853f31',
                'category' => 'Kopi & Teh',
            ],
            [
                'name' => 'Tenun Motif Nusantara',
                'seller' => 'Tenun Lokal',
                'location' => 'Yogyakarta',
                'price' => 120000,
                'old_price' => 150000,
                'rating' => 4.8,
                'image' => 'photo-1523381210434-271e8be1f52b',
                'category' => 'Kerajinan',
            ],
            [
                'name' => 'Camilan Khas Daerah',
                'seller' => 'UMKM Rasa Nusantara',
                'location' => 'Bandung',
                'price' => 35000,
                'old_price' => 50000,
                'rating' => 4.7,
                'image' => 'photo-1599599810694-b5b37304c041',
                'category' => 'Makanan Lokal',
            ],
            [
                'name' => 'Tas Anyaman Lokal',
                'seller' => 'Kerajinan Tangan',
                'location' => 'Aceh',
                'price' => 89000,
                'old_price' => 110000,
                'rating' => 4.8,
                'image' => 'photo-1590874103328-eac38a683ce7',
                'category' => 'Fashion',
            ],
        ];

        return view('gratis-ongkir', compact('vouchers', 'products'));
    }
}
