<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\View\View;

class FashionController extends Controller
{
    public function index(Request $request): View
    {
        $subcategories = [
            'pria' => ['label' => 'Pria', 'icon' => 'fa-person', 'keywords' => ['pria', 'cowok', 'men']],
            'wanita' => ['label' => 'Wanita', 'icon' => 'fa-person-dress', 'keywords' => ['wanita', 'perempuan', 'cewek', 'women']],
            'anak' => ['label' => 'Anak', 'icon' => 'fa-child', 'keywords' => ['anak', 'bayi', 'kids']],
            'hijab' => ['label' => 'Hijab', 'icon' => 'fa-mosque', 'keywords' => ['hijab', 'jilbab', 'kerudung']],
            'sepatu' => ['label' => 'Sepatu', 'icon' => 'fa-shoe-prints', 'keywords' => ['sepatu', 'sandal', 'alas kaki']],
            'tas' => ['label' => 'Tas', 'icon' => 'fa-bag-shopping', 'keywords' => ['tas', 'ransel', 'dompet']],
            'aksesoris' => ['label' => 'Aksesoris', 'icon' => 'fa-gem', 'keywords' => ['aksesoris', 'aksesori', 'perhiasan', 'jam tangan']],
        ];

        $request->validate([
            'subcategory' => ['nullable', Rule::in(array_keys($subcategories))],
        ]);

        $selectedSubcategory = $request->query('subcategory');
        $search = trim((string) $request->input('search', ''));
        $maxPrice = $request->integer('price');
        $minimumRating = (float) $request->input('rating', 0);
        $location = trim((string) $request->input('location', ''));
        $subcategoryKeywords = $selectedSubcategory
            ? $subcategories[$selectedSubcategory]['keywords']
            : [];

        $products = Product::query()
            ->with('category')
            ->whereHas('category', fn ($query) => $query->where('slug', 'fashion'))
            ->where('price', '>', 0)
            ->when($subcategoryKeywords, fn ($query) => $query->where(function ($query) use ($subcategoryKeywords) {
                foreach ($subcategoryKeywords as $keyword) {
                    foreach (['name', 'description'] as $column) {
                        $query->orWhere(function ($query) use ($column, $keyword) {
                            $query->where($column, 'like', $keyword)
                                ->orWhere($column, 'like', $keyword.' %')
                                ->orWhere($column, 'like', '% '.$keyword)
                                ->orWhere($column, 'like', '% '.$keyword.' %');
                        });
                    }
                }
            }))
            ->when($search, fn ($query) => $query->where(function ($query) use ($search) {
                $query->where('name', 'like', '%'.$search.'%')
                    ->orWhere('description', 'like', '%'.$search.'%')
                    ->orWhere('seller', 'like', '%'.$search.'%');
            }))
            ->when($maxPrice > 0, fn ($query) => $query->where('price', '<=', $maxPrice))
            ->when($minimumRating > 0, fn ($query) => $query->where('rating', '>=', $minimumRating))
            ->when($location, fn ($query) => $query->where('location', 'like', '%'.$location.'%'))
            ->when($request->query('sort') === 'price_asc', fn ($query) => $query->orderBy('price'))
            ->when($request->query('sort') === 'price_desc', fn ($query) => $query->orderByDesc('price'))
            ->when(! in_array($request->query('sort'), ['price_asc', 'price_desc'], true), fn ($query) => $query->orderByDesc('rating'))
            ->get();

        $productCards = $products->map(function (Product $product) {
            $discount = $product->old_price > $product->price
                ? max(0, round((1 - $product->price / $product->old_price) * 100))
                : 0;

            return [
                'id' => $product->id,
                'slug' => $product->slug,
                'name' => $product->name,
                'seller' => $product->seller,
                'location' => $product->location,
                'image' => $product->image,
                'price' => (int) $product->price,
                'old_price' => (int) $product->old_price,
                'discount' => $discount,
                'rating' => (float) $product->rating,
                'review_count' => (int) $product->review_count,
                'sold' => max(1, (int) $product->review_count * 9 + (int) $product->id * 12),
                'category' => $product->category?->name ?? 'Fashion',
            ];
        });

        $categories = Category::withCount('products')->orderBy('sort_order')->get();
        $locations = Product::query()
            ->whereHas('category', fn ($query) => $query->where('slug', 'fashion'))
            ->whereNotNull('location')
            ->distinct()
            ->orderBy('location')
            ->pluck('location');

        return view('fashion', compact(
            'productCards',
            'categories',
            'locations',
            'subcategories',
            'selectedSubcategory',
        ));
    }
}
