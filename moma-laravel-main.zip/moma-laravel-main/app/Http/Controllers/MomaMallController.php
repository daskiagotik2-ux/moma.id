<?php

namespace App\Http\Controllers;

use App\Models\Store;
use Illuminate\View\View;

class MomaMallController extends Controller
{
    public function index(): View
    {
        $storeNames = [
            'toko-gotik' => 'Toko Gotik',
            'toko-wilda' => 'Toko Wilda',
        ];
        $stores = Store::query()
            ->whereIn('slug', array_keys($storeNames))
            ->where('status', 'approved')
            ->withCount('products')
            ->withAvg('products', 'rating')
            ->with(['products' => fn ($products) => $products
                ->orderByDesc('is_featured')
                ->orderByDesc('rating')
                ->limit(4)])
            ->get()
            ->sortBy(fn (Store $store) => array_search($store->slug, array_keys($storeNames), true))
            ->values();

        $officialStores = $stores->map(fn (Store $store) => [
            'name' => $storeNames[$store->slug],
            'slug' => $store->slug,
            'logo' => collect(explode(' ', $storeNames[$store->slug]))
                ->map(fn (string $part) => strtoupper(substr($part, 0, 1)))
                ->implode(''),
            'rating' => (float) ($store->products_avg_rating ?? 0),
            'products' => $store->products_count,
            'location' => $store->address,
        ]);

        $productCards = $stores->flatMap(fn (Store $store) => $store->products->map(fn ($product) => [
            'slug' => $product->slug,
            'name' => $product->name,
            'seller' => $storeNames[$store->slug],
            'image' => $product->image,
            'price' => (int) $product->price,
            'normal_price' => max((int) $product->old_price, (int) $product->price),
            'rating' => (float) $product->rating,
            'sold' => (int) $product->review_count,
        ]))->values();

        return view('moma-mall', compact('officialStores', 'productCards'));
    }
}
