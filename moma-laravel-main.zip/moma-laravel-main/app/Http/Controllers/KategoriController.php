<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\View\View;

class KategoriController extends Controller
{
    public function index(): View
    {
        $categories = [
            ['name' => 'Flash Sale', 'icon' => '⚡', 'products' => 48, 'route' => 'flash-sale', 'route_parameter' => null, 'tone' => 'red'],
            ['name' => 'MoMa Mall', 'icon' => '🛍️', 'products' => 126, 'route' => 'moma-mall', 'route_parameter' => null, 'tone' => 'orange'],
            ['name' => 'Makanan Lokal', 'icon' => '🍜', 'products' => 84, 'route' => 'makanan-lokal', 'route_parameter' => null, 'tone' => 'gold'],
            ['name' => 'Fashion', 'icon' => '👕', 'products' => 96, 'route' => 'fashion', 'route_parameter' => null, 'tone' => 'pink'],
            ['name' => 'Kerajinan', 'icon' => '🎨', 'products' => 62, 'route' => 'kerajinan', 'route_parameter' => null, 'tone' => 'blue'],
            ['name' => 'Gratis Ongkir', 'icon' => '🚚', 'products' => 31, 'route' => 'gratis-ongkir', 'route_parameter' => null, 'tone' => 'green'],
            ['name' => 'Produk Terlaris', 'icon' => '📈', 'products' => 57, 'route' => 'produk-terlaris', 'route_parameter' => null, 'tone' => 'navy'],
            ['name' => 'Toko Pilihan', 'icon' => '🏪', 'products' => 73, 'route' => 'toko-pilihan', 'route_parameter' => null, 'tone' => 'violet'],
            ['name' => 'Voucher', 'icon' => '🎟️', 'products' => 18, 'route' => 'voucher', 'route_parameter' => null, 'tone' => 'amber'],
            ['name' => 'Elektronik', 'icon' => '🎧', 'products' => 42, 'route' => 'kategori.placeholder', 'route_parameter' => 'elektronik', 'tone' => 'indigo'],
            ['name' => 'Kecantikan', 'icon' => '🌿', 'products' => 36, 'route' => 'kategori.placeholder', 'route_parameter' => 'kecantikan', 'tone' => 'mint'],
            ['name' => 'Kesehatan', 'icon' => '💚', 'products' => 52, 'route' => 'kategori.placeholder', 'route_parameter' => 'kesehatan', 'tone' => 'teal'],
            ['name' => 'Rumah Tangga', 'icon' => '🏠', 'products' => 44, 'route' => 'kategori.placeholder', 'route_parameter' => 'rumah-tangga', 'tone' => 'sand'],
            ['name' => 'Ibu & Anak', 'icon' => '👶', 'products' => 39, 'route' => 'kategori.placeholder', 'route_parameter' => 'ibu-anak', 'tone' => 'rose'],
            ['name' => 'Otomotif', 'icon' => '🚗', 'products' => 28, 'route' => 'kategori.placeholder', 'route_parameter' => 'otomotif', 'tone' => 'cyan'],
            ['name' => 'Olahraga', 'icon' => '🏃', 'products' => 34, 'route' => 'kategori.placeholder', 'route_parameter' => 'olahraga', 'tone' => 'lime'],
            ['name' => 'Buku', 'icon' => '📚', 'products' => 47, 'route' => 'kategori.placeholder', 'route_parameter' => 'buku', 'tone' => 'purple'],
            ['name' => 'Hobi', 'icon' => '🎲', 'products' => 29, 'route' => 'kategori.placeholder', 'route_parameter' => 'hobi', 'tone' => 'coral'],
            ['name' => 'Komputer & Aksesoris', 'icon' => '💻', 'products' => 51, 'route' => 'kategori.placeholder', 'route_parameter' => 'komputer-aksesoris', 'tone' => 'slate'],
            ['name' => 'Sepatu', 'icon' => '👟', 'products' => 63, 'route' => 'kategori.placeholder', 'route_parameter' => 'sepatu', 'tone' => 'blue'],
            ['name' => 'Tas', 'icon' => '👜', 'products' => 58, 'route' => 'kategori.placeholder', 'route_parameter' => 'tas', 'tone' => 'orange'],
            ['name' => 'Aksesoris', 'icon' => '🔧', 'products' => 35, 'route' => 'kategori.placeholder', 'route_parameter' => 'aksesoris', 'tone' => 'gray'],
            ['name' => 'Makanan & Minuman', 'icon' => '🥤', 'products' => 76, 'route' => 'kategori.placeholder', 'route_parameter' => 'makanan-minuman', 'tone' => 'green'],
            ['name' => 'Produk Lokal', 'icon' => '🧶', 'products' => 69, 'route' => 'kategori.placeholder', 'route_parameter' => 'produk-lokal', 'tone' => 'red'],
        ];

        return view('kategori', compact('categories'));
    }

    public function placeholder(string $category): View
    {
        $categoryLabel = str_replace('-', ' ', ucwords($category));

        return view('category-placeholder', compact('categoryLabel'));
    }
}
