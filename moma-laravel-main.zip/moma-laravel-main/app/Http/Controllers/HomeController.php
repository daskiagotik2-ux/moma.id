<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Banner;
use App\Models\FlashSale;
use App\Models\OrderItem;
use App\Models\Product;
use App\Models\Store;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;

class HomeController extends Controller
{
    // Halaman Utama (Home)
    public function index()
    {
        $now = now();
        $banners = Cache::remember('home.active-banners', 300, fn () => Banner::query()
            ->where('is_active', true)
            ->where(fn ($query) => $query->whereNull('starts_at')->orWhere('starts_at', '<=', $now))
            ->where(fn ($query) => $query->whereNull('ends_at')->orWhere('ends_at', '>', $now))
            ->orderBy('sort_order')
            ->get());
        $categories = Cache::remember('home.categories', 300, fn () => Category::query()
            ->orderBy('sort_order')
            ->get());
        $flashSales = FlashSale::query()
            ->with(['items.product.category', 'items.product.store'])
            ->where('is_active', true)
            ->where('starts_at', '<=', $now)
            ->where('ends_at', '>', $now)
            ->orderBy('ends_at')
            ->get();

        $flashSales->each(fn (FlashSale $flashSale) => $flashSale->setAttribute(
            'remaining_seconds',
            max(0, $flashSale->ends_at->getTimestamp() - $now->getTimestamp())
        ));

        $officialStores = Store::query()
            ->where('status', 'approved')
            ->where('is_official', true)
            ->withCount('products')
            ->orderBy('store_name')
            ->take(8)
            ->get();
        $featuredStores = Store::query()
            ->where('status', 'approved')
            ->where('is_featured', true)
            ->withCount('products')
            ->orderBy('store_name')
            ->take(8)
            ->get();
        $latestProducts = Product::with(['category', 'store'])->latest()->take(8)->get();
        $recommendedProducts = Product::with(['category', 'store'])
            ->where('is_featured', true)
            ->latest()
            ->take(8)
            ->get();
        $bestSellingIds = OrderItem::query()
            ->whereNotNull('product_id')
            ->whereHas('order', fn ($orders) => $orders->where('status', 'completed'))
            ->select('product_id')
            ->groupBy('product_id')
            ->orderByRaw('SUM(quantity) DESC')
            ->limit(8)
            ->pluck('product_id');
        $rank = $bestSellingIds->flip();
        $bestSellingProducts = Product::with(['category', 'store'])
            ->whereIn('id', $bestSellingIds)
            ->get()
            ->sortBy(fn ($product) => $rank[$product->id] ?? PHP_INT_MAX)
            ->values();

        return view('home', compact(
            'banners',
            'flashSales',
            'officialStores',
            'featuredStores',
            'categories',
            'latestProducts',
            'recommendedProducts',
            'bestSellingProducts',
        ));
    }

    // Semua Produk
    public function products(Request $request)
    {
        $query = Product::with('category');

        if ($search = trim((string) $request->query('search'))) {
            $query->where(function ($products) use ($search) {
                $products->where('name', 'like', "%{$search}%")
                    ->orWhere('seller', 'like', "%{$search}%")
                    ->orWhereHas('category', fn ($category) => $category->where('name', 'like', "%{$search}%"));
            });
        }

        if ($categorySlug = $request->query('category')) {
            $query->whereHas('category', fn ($category) => $category->where('slug', $categorySlug));
        }

        match ($request->query('sort')) {
            'price_asc' => $query->orderBy('price'),
            'price_desc' => $query->orderByDesc('price'),
            'popular' => $query->orderByDesc('review_count')->orderByDesc('rating'),
            default => $query->latest(),
        };

        $products = $query->paginate(12)->withQueryString();
        $categories = Category::orderBy('sort_order')->get();

        return view('products', compact('products', 'categories'));
    }

    public function categories()
    {
        $categories = Category::withCount('products')->orderBy('sort_order')->get();

        return view('kategori', compact('categories'));
    }

    // Filter berdasarkan Kategori
    public function category(Request $request, $category)
    {
        $categories = Category::orderBy('sort_order')->get();
        $selectedCategory = $category === 'semua'
            ? null
            : Category::where('slug', $category)->firstOrFail();
        $categoryPlatforms = [
            'makanan-minuman' => ['icon' => 'fa-utensils', 'description' => 'Jelajahi makanan, minuman, dan cita rasa lokal dari UMKM Indonesia.', 'label' => 'Rasa lokal pilihan'],
            'fashion' => ['icon' => 'fa-shirt', 'description' => 'Temukan busana dan produk fashion pilihan dari UMKM Indonesia.', 'label' => 'Gaya lokal pilihan'],
            'kerajinan-tangan' => ['icon' => 'fa-palette', 'description' => 'Jelajahi karya kerajinan tangan unik dari para pengrajin lokal.', 'label' => 'Karya buatan lokal'],
            'kecantikan-perawatan' => ['icon' => 'fa-spa', 'description' => 'Temukan produk kecantikan dan perawatan dari brand lokal.', 'label' => 'Perawatan pilihan'],
            'elektronik' => ['icon' => 'fa-headphones', 'description' => 'Jelajahi perangkat elektronik pilihan dari penjual marketplace.', 'label' => 'Elektronik pilihan'],
            'rumah-dapur' => ['icon' => 'fa-house', 'description' => 'Lengkapi rumah dan dapur dengan produk pilihan.', 'label' => 'Kebutuhan rumah'],
            'olahraga-hobi' => ['icon' => 'fa-futbol', 'description' => 'Temukan perlengkapan olahraga dan hobi untuk aktivitasmu.', 'label' => 'Aktif dan kreatif'],
            'buku-alat-tulis' => ['icon' => 'fa-book-open', 'description' => 'Jelajahi buku dan alat tulis untuk belajar maupun berkarya.', 'label' => 'Teman belajar'],
            'otomotif' => ['icon' => 'fa-car', 'description' => 'Temukan kebutuhan dan perlengkapan otomotif pilihan.', 'label' => 'Untuk perjalananmu'],
            'lainnya' => ['icon' => 'fa-shapes', 'description' => 'Jelajahi berbagai produk menarik dari UMKM Indonesia.', 'label' => 'Pilihan lainnya'],
        ];
        $categoryPlatform = $selectedCategory
            ? ($categoryPlatforms[$selectedCategory->slug] ?? [
                'icon' => 'fa-tag',
                'description' => 'Jelajahi produk '.strtolower($selectedCategory->name).' pilihan dari UMKM Indonesia.',
                'label' => $selectedCategory->name.' pilihan',
            ])
            : ['icon' => 'fa-layer-group', 'description' => 'Temukan produk pilihan dari semua kategori UMKM Indonesia.', 'label' => 'Pilihan UMKM'];

        $query = Product::with('category')
            ->when($selectedCategory, fn ($query) => $query->where('category_id', $selectedCategory->id))
            ->when(trim((string) $request->query('search')), function ($query) use ($request) {
                $search = trim((string) $request->query('search'));
                $query->where(function ($products) use ($search) {
                    $products->where('name', 'like', "%{$search}%")
                        ->orWhere('description', 'like', "%{$search}%")
                        ->orWhere('seller', 'like', "%{$search}%");
                });
            });

        match ($request->query('sort')) {
            'price_asc' => $query->orderBy('price'),
            'price_desc' => $query->orderByDesc('price'),
            'popular' => $query->orderByDesc('rating')->orderByDesc('review_count'),
            default => $query->latest(),
        };

        $products = $query->paginate(12)->withQueryString();

        return view('category', compact('categories', 'products', 'selectedCategory', 'categoryPlatform'));
    }

    public function categoryPlaceholder($category)
    {
        abort_unless(Category::where('slug', $category)->exists(), 404);

        return redirect()->route('category', $category);
    }

    public function showProduct(Product $product)
    {
        return view('products.show', compact('product'));
    }

    // Halaman Promo & Voucher
    public function promo()
    {
        return view('promo');
    }

    // Toko Saya / UMKM Lokal
    public function shop()
    {
        return view('shop');
    }

    // Pesanan Saya (Auth)
    public function orders()
    {
        return view('orders');
    }

    // Wishlist (Auth)
    public function wishlist()
    {
        return view('wishlist');
    }
}