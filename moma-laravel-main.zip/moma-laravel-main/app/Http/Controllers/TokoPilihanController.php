<?php

namespace App\Http\Controllers;

use App\Models\Store;
use Illuminate\View\View;

class TokoPilihanController extends Controller
{
    public function index(): View
    {
        $storeLabels = [
            'toko-gotik' => 'Toko Gotik',
            'toko-wilda' => 'Toko Wilda',
        ];

        $stores = Store::query()
            ->whereIn('slug', array_keys($storeLabels))
            ->where('status', 'approved')
            ->withCount('products')
            ->withAvg('products', 'rating')
            ->with(['products' => fn ($products) => $products
                ->orderByDesc('rating')
                ->orderByDesc('review_count')
                ->limit(4)])
            ->get()
            ->sortBy(fn (Store $store) => array_search($store->slug, array_keys($storeLabels), true))
            ->map(fn (Store $store) => [
                'name' => $storeLabels[$store->slug],
                'slug' => $store->slug,
                'location' => $store->address,
                'category' => $store->category,
                'product_count' => $store->products_count,
                'rating' => (float) ($store->products_avg_rating ?? 0),
                'products' => $store->products,
            ])
            ->values();

        return view('toko-pilihan', compact('stores'));
    }
}
