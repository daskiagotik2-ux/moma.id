<?php

namespace App\Http\Controllers;

use App\Contracts\PaymentGateway;
use App\Enums\PaymentMethod;
use App\Models\Order;
use App\Models\Product;
use App\Models\FlashSale;
use App\Models\FlashSaleItem;
use App\Services\VoucherService;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;

class BuyerController extends Controller
{
    public function cart(Request $request): View
    {
        $cart = $request->session()->get('cart', []);
        $products = Product::with('category')->whereIn('id', array_keys($cart))->get()->keyBy('id');
        $items = collect($cart)->map(function ($quantity, $productId) use ($products) {
            $product = $products->get($productId);

            return $product ? ['product' => $product, 'quantity' => (int) $quantity] : null;
        })->filter()->values();

        return view('cart.index', [
            'items' => $items,
            'subtotal' => $items->sum(fn ($item) => $item['product']->price * $item['quantity']),
        ]);
    }

    public function addToCart(Request $request, Product $product): RedirectResponse
    {
        $quantity = max(1, min((int) $request->input('quantity', 1), 99));
        $cart = $request->session()->get('cart', []);
        $nextQuantity = ($cart[$product->id] ?? 0) + $quantity;
        $flashSaleItems = $request->session()->get('flash_sale_items', []);

        if ($product->stock === 0) {
            return back()->with('error', 'Produk ini sedang habis.');
        }

        if ($product->stock !== null && $nextQuantity > $product->stock) {
            return back()->with('error', 'Jumlah melebihi stok yang tersedia.');
        }

        $flashSaleItemId = $request->filled('flash_sale_item_id')
            ? (int) $request->input('flash_sale_item_id')
            : ($flashSaleItems[$product->id] ?? null);

        if ($flashSaleItemId !== null) {
            $this->assertFlashSaleCapacity((int) $flashSaleItemId, $product->id, $nextQuantity);
            $flashSaleItems[$product->id] = (int) $flashSaleItemId;
            $request->session()->put('flash_sale_items', $flashSaleItems);
        }

        $cart[$product->id] = $nextQuantity;
        $request->session()->put('cart', $cart);

        return $request->input('redirect_to') === 'checkout'
            ? redirect()->route('checkout.create')
            : redirect()->route('cart.index')->with('success', 'Produk ditambahkan ke keranjang.');
    }

    public function updateCart(Request $request, Product $product): RedirectResponse
    {
        $validated = $request->validate(['quantity' => ['required', 'integer', 'min:1', 'max:99']]);

        if ($product->stock === 0 || ($product->stock !== null && $validated['quantity'] > $product->stock)) {
            throw ValidationException::withMessages(['quantity' => 'Jumlah melebihi stok yang tersedia.']);
        }

        $cart = $request->session()->get('cart', []);
        $flashSaleItemId = $request->session()->get("flash_sale_items.{$product->id}");

        if ($flashSaleItemId !== null) {
            $this->assertFlashSaleCapacity((int) $flashSaleItemId, $product->id, $validated['quantity']);
        }

        $cart[$product->id] = $validated['quantity'];
        $request->session()->put('cart', $cart);

        return redirect()->route('cart.index')->with('success', 'Jumlah produk diperbarui.');
    }

    public function removeFromCart(Request $request, Product $product): RedirectResponse
    {
        $cart = $request->session()->get('cart', []);
        $flashSaleItems = $request->session()->get('flash_sale_items', []);
        unset($cart[$product->id]);
        unset($flashSaleItems[$product->id]);
        $request->session()->put('cart', $cart);
        $request->session()->put('flash_sale_items', $flashSaleItems);

        return redirect()->route('cart.index')->with('success', 'Produk dihapus dari keranjang.');
    }

    public function checkout(Request $request, VoucherService $voucherService): View|RedirectResponse
    {
        $cart = $request->session()->get('cart', []);

        if (empty($cart)) {
            return redirect()->route('cart.index')->with('error', 'Keranjang masih kosong.');
        }

        $products = Product::with('category')->whereIn('id', array_keys($cart))->get()->keyBy('id');
        $flashSaleItems = FlashSaleItem::with('flashSale')
            ->whereIn('id', array_values($request->session()->get('flash_sale_items', [])))
            ->get()
            ->keyBy('id');
        $items = collect($cart)->map(function ($quantity, $id) use ($products, $flashSaleItems, $request) {
            if (! $products->has($id)) {
                return null;
            }

            $product = $products->get($id);
            $flashSaleItemId = $request->session()->get("flash_sale_items.{$id}");
            $flashSaleItem = $flashSaleItems->get($flashSaleItemId);
            $isFlashSale = $flashSaleItem
                && (int) $flashSaleItem->product_id === (int) $product->id
                && $flashSaleItem->flashSale
                && $flashSaleItem->flashSale->is_active
                && $flashSaleItem->flashSale->starts_at->lte(now())
                && $flashSaleItem->flashSale->ends_at->gt(now());

            return [
                'product' => $product,
                'quantity' => (int) $quantity,
                'price' => $isFlashSale ? $flashSaleItem->sale_price : $product->price,
                'is_flash_sale' => $isFlashSale,
            ];
        })->filter()->values();

        $subtotal = $items->sum(fn ($item) => $item['price'] * $item['quantity']);
        $voucherCode = $request->session()->get('checkout_voucher_code');
        $voucher = $voucherCode ? $voucherService->findAvailable($voucherCode) : null;
        $voucherError = null;
        $discountAmount = 0;

        if ($voucherCode && ! $voucher) {
            $voucherError = $voucherService->unavailableMessage();
        } elseif ($voucher && $subtotal < $voucher->min_spend) {
            $voucherError = $voucherService->minimumSpendMessage($voucher);
        } elseif ($voucher) {
            $discountAmount = $voucherService->discountAmount($voucher, $subtotal);
        }

        $shippingCost = VoucherService::BASE_SHIPPING_COST;

        return view('checkout.index', [
            'items' => $items,
            'subtotal' => $subtotal,
            'voucherCode' => $voucherCode,
            'voucherError' => $voucherError,
            'discountAmount' => $discountAmount,
            'shippingCost' => $shippingCost,
            'total' => max(0, $subtotal + $shippingCost - $discountAmount),
            'paymentMethods' => collect(config('payment.methods'))
                ->filter(fn (array $method, string $key) => $method['enabled']
                    && in_array($key, config('payment.active_methods', []), true)
                    && $this->isPaymentMethodConfigured(PaymentMethod::from($key)))
                ->map(fn (array $method, string $key) => [
                    'value' => $key,
                    'label' => PaymentMethod::from($key)->label(),
                    'description' => $method['description'],
                ])->values(),
        ]);
    }

    public function placeOrder(Request $request, VoucherService $voucherService, PaymentGateway $paymentGateway): RedirectResponse
    {
        $validated = $request->validate([
            'shipping_address' => ['required', 'string', 'max:1000'],
            'contact_phone' => ['required', 'string', 'max:25'],
            'payment_method' => ['required', 'string', 'in:cod,bank_transfer,qris'],
        ], [
            'shipping_address.required' => 'Alamat pengiriman wajib diisi.',
            'contact_phone.required' => 'Nomor telepon wajib diisi.',
            'payment_method.required' => 'Pilih metode pembayaran terlebih dahulu.',
            'payment_method.in' => 'Metode pembayaran yang dipilih tidak tersedia.',
        ]);
        $paymentMethod = PaymentMethod::from($validated['payment_method']);
        if (! $this->isPaymentMethodConfigured($paymentMethod)) {
            throw ValidationException::withMessages(['payment_method' => 'Metode pembayaran ini belum tersedia atau belum dikonfigurasi administrator.']);
        }
        $cart = $request->session()->get('cart', []);

        if (empty($cart)) {
            return redirect()->route('cart.index')->with('error', 'Keranjang masih kosong.');
        }

        $flashSaleItemsByProduct = $request->session()->get('flash_sale_items', []);
        $voucherCode = $request->session()->get('checkout_voucher_code');

        $order = DB::transaction(function () use ($request, $validated, $cart, $flashSaleItemsByProduct, $voucherCode, $voucherService, $paymentMethod, $paymentGateway) {
            $products = Product::whereIn('id', array_keys($cart))->lockForUpdate()->get()->keyBy('id');

            if ($products->count() !== count($cart)) {
                throw ValidationException::withMessages(['cart' => 'Ada produk dalam keranjang yang sudah tidak tersedia.']);
            }

            $flashSaleItemIds = collect($flashSaleItemsByProduct)->map(fn ($id) => (int) $id)->unique()->sort()->values();
            $flashSaleItems = FlashSaleItem::query()
                ->whereIn('id', $flashSaleItemIds)
                ->orderBy('id')
                ->lockForUpdate()
                ->get()
                ->keyBy('id');

            if ($flashSaleItems->count() !== $flashSaleItemIds->count()) {
                throw ValidationException::withMessages(['cart' => 'Flash sale yang dipilih sudah tidak tersedia.']);
            }

            $flashSales = FlashSale::query()
                ->whereIn('id', $flashSaleItems->pluck('flash_sale_id')->unique())
                ->orderBy('id')
                ->lockForUpdate()
                ->get()
                ->keyBy('id');
            $now = now();

            foreach ($flashSaleItemsByProduct as $productId => $flashSaleItemId) {
                $flashSaleItem = $flashSaleItems->get((int) $flashSaleItemId);
                $flashSale = $flashSaleItem ? $flashSales->get($flashSaleItem->flash_sale_id) : null;

                if (
                    ! array_key_exists($productId, $cart)
                    || ! $flashSaleItem
                    || (int) $flashSaleItem->product_id !== (int) $productId
                    || ! $flashSale
                    || ! $flashSale->is_active
                    || $flashSale->starts_at->gt($now)
                    || $flashSale->ends_at->lte($now)
                ) {
                    throw ValidationException::withMessages(['cart' => 'Flash sale yang dipilih sudah berakhir atau tidak tersedia.']);
                }
            }

            $subtotal = 0;
            foreach ($cart as $productId => $quantity) {
                $product = $products->get($productId);
                if ($product->stock === 0 || ($product->stock !== null && $quantity > $product->stock)) {
                    throw ValidationException::withMessages(['cart' => "Stok {$product->name} tidak mencukupi."]);
                }

                $flashSaleItemId = $flashSaleItemsByProduct[$productId] ?? null;
                $flashSaleItem = $flashSaleItemId !== null ? $flashSaleItems->get((int) $flashSaleItemId) : null;

                if ($flashSaleItem && $flashSaleItem->sold_count + $quantity > $flashSaleItem->stock_limit) {
                    throw ValidationException::withMessages(['cart' => "Stok Flash Sale {$product->name} tidak mencukupi."]);
                }

                $subtotal += ($flashSaleItem?->sale_price ?? $product->price) * $quantity;
            }

            $voucher = $voucherCode ? $voucherService->findAvailable($voucherCode, lock: true) : null;
            if ($voucherCode && ! $voucher) {
                throw ValidationException::withMessages(['voucher' => $voucherService->unavailableMessage()]);
            }

            if ($voucher && $subtotal < $voucher->min_spend) {
                throw ValidationException::withMessages(['voucher' => $voucherService->minimumSpendMessage($voucher)]);
            }

            $discountAmount = $voucher ? $voucherService->discountAmount($voucher, $subtotal) : 0;
            $shippingCost = VoucherService::BASE_SHIPPING_COST;
            $grandTotal = max(0, $subtotal + $shippingCost - $discountAmount);
            $isManualPayment = $paymentMethod->isManual();
            $order = $request->user()->orders()->create([
                'order_number' => 'NM-'.Str::upper(Str::random(10)),
                'status' => $isManualPayment ? 'awaiting_payment' : 'awaiting_confirmation',
                'subtotal' => $subtotal,
                'shipping_cost' => $shippingCost,
                'shipping_address' => $validated['shipping_address'],
                'contact_phone' => $validated['contact_phone'],
                'voucher_code' => $voucher?->code,
                'discount_amount' => $discountAmount,
                'grand_total' => $grandTotal,
                'payment_method' => $paymentMethod,
                'payment_status' => 'unpaid',
                'payment_expires_at' => $isManualPayment ? now()->addHours(config('payment.expiration_hours', 24)) : null,
            ]);

            foreach ($cart as $productId => $quantity) {
                $product = $products->get($productId);
                $flashSaleItemId = $flashSaleItemsByProduct[$productId] ?? null;
                $flashSaleItem = $flashSaleItemId !== null ? $flashSaleItems->get((int) $flashSaleItemId) : null;
                $order->items()->create([
                    'product_id' => $product->id,
                    'flash_sale_item_id' => $flashSaleItem?->id,
                    'product_name' => $product->name,
                    'seller' => $product->seller,
                    'image' => $product->image,
                    'quantity' => $quantity,
                    'price' => $flashSaleItem?->sale_price ?? $product->price,
                ]);

                if ($product->stock !== null) {
                    $product->decrement('stock', $quantity);
                }

                if ($flashSaleItem) {
                    $flashSaleItem->increment('sold_count', $quantity);
                }
            }

            if ($voucher) {
                $voucher->increment('used_count');
            }

            if ($isManualPayment) {
                $paymentGateway->createPayment($order, $paymentMethod);
            }

            return $order;
        });

        $request->session()->forget(['cart', 'checkout_voucher_code', 'flash_sale_items']);

        return $order->payment_method->isManual()
            ? redirect()->route('orders.pay', $order)->with('success', 'Pesanan dibuat. Silakan selesaikan pembayaran dan unggah bukti bayar.')
            : redirect()->route('orders.show', $order)->with('success', 'Pesanan COD dibuat dan menunggu konfirmasi toko.');
    }

    public function orders(Request $request): View
    {
        $validated = $request->validate([
            'status' => ['nullable', 'in:unpaid,packed,shipped,completed'],
        ]);
        $status = $validated['status'] ?? null;
        $ordersQuery = $request->user()->orders()->with('items');

        match ($status) {
            'unpaid' => $ordersQuery->where('status', 'awaiting_payment'),
            'packed' => $ordersQuery->whereIn('status', ['awaiting_confirmation', 'processing']),
            'shipped' => $ordersQuery->where('status', 'shipped'),
            'completed' => $ordersQuery->where('status', 'completed'),
            default => null,
        };

        $orders = $ordersQuery->latest()->paginate(10)->withQueryString();

        return view('orders', compact('orders', 'status'));
    }

    public function showOrder(Request $request, Order $order): View
    {
        $this->authorize('view', $order);
        $order->load(['items', 'payments' => fn ($query) => $query->latest()]);

        return view('orders.show', compact('order'));
    }

    public function confirmReceipt(Request $request, Order $order): RedirectResponse
    {
        $this->authorize('view', $order);

        DB::transaction(function () use ($order) {
            $lockedOrder = Order::query()->whereKey($order->id)->lockForUpdate()->firstOrFail();
            $this->authorize('view', $lockedOrder);

            if ($lockedOrder->status !== 'shipped') {
                abort(422, 'Pesanan belum siap dikonfirmasi.');
            }

            $items = $lockedOrder->items()->lockForUpdate()->get();
            if ($items->isEmpty() || $items->contains(fn ($item) => $item->seller_status !== 'shipped')) {
                abort(422, 'Semua toko harus mengirim pesanan sebelum Anda mengonfirmasi penerimaan.');
            }

            $lockedOrder->items()->update(['seller_status' => 'completed']);
            $lockedOrder->update(['status' => 'completed']);
        });

        return redirect()->route('orders.show', $order)->with('success', 'Pesanan dikonfirmasi selesai. Terima kasih sudah berbelanja!');
    }

    public function wishlist(Request $request): View
    {
        $products = $request->user()->wishlistProducts()->with('category')->latest('wishlist_items.created_at')->paginate(12);

        return view('wishlist', compact('products'));
    }

    public function toggleWishlist(Request $request, Product $product): RedirectResponse
    {
        $request->user()->wishlistProducts()->toggle($product->id);

        return back()->with('success', 'Wishlist diperbarui.');
    }

    private function assertFlashSaleCapacity(int $flashSaleItemId, int $productId, int $quantity): void
    {
        DB::transaction(function () use ($flashSaleItemId, $productId, $quantity) {
            $flashSaleItem = FlashSaleItem::query()->lockForUpdate()->find($flashSaleItemId);
            $flashSale = $flashSaleItem
                ? FlashSale::query()->lockForUpdate()->find($flashSaleItem->flash_sale_id)
                : null;
            $now = now();

            if (
                ! $flashSaleItem
                || (int) $flashSaleItem->product_id !== $productId
                || ! $flashSale
                || ! $flashSale->is_active
                || $flashSale->starts_at->gt($now)
                || $flashSale->ends_at->lte($now)
            ) {
                throw ValidationException::withMessages(['cart' => 'Flash sale yang dipilih sudah berakhir atau tidak tersedia.']);
            }

            if ($flashSaleItem->sold_count + $quantity > $flashSaleItem->stock_limit) {
                throw ValidationException::withMessages(['cart' => 'Stok Flash Sale tidak mencukupi.']);
            }
        });
    }

    private function isPaymentMethodConfigured(PaymentMethod $method): bool
    {
        if (! config("payment.methods.{$method->value}.enabled")
            || ! in_array($method->value, config('payment.active_methods', []), true)) {
            return false;
        }

        return match ($method) {
            PaymentMethod::Cod => true,
            PaymentMethod::BankTransfer => collect(config('payment.methods.bank_transfer.accounts', []))
                ->contains(fn (array $account) => filled($account['number'] ?? null)),
            PaymentMethod::Qris => filled(config('payment.methods.qris.image')),
        };
    }
}