<?php

namespace App\Http\Controllers;

use App\Models\Store;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Str;

class StoreController extends Controller
{
    // Menampilkan formulir pengajuan toko
    public function create()
    {
        $store = Auth::user()->store;

        return view('stores.create', compact('store'));
    }

    // Menyimpan pengajuan toko
    public function store(Request $request)
    {
        $userId = Auth::id();

        // Cegah satu akun mengajukan toko berulang kali
        if (Store::where('user_id', $userId)->exists()) {
            return redirect()
                ->route('seller.dashboard')
                ->with('error', 'Akun ini sudah memiliki toko.');
        }

        $validated = $request->validate([
            'store_name' => ['required', 'string', 'max:100'],
            'description' => ['nullable', 'string', 'max:1000'],
            'category' => ['required', 'string', 'max:100'],
            'phone' => ['required', 'string', 'max:25'],
            'address' => ['required', 'string', 'max:1000'],
        ]);

        $slugBase = Str::slug($validated['store_name']);
        $slug = $slugBase;
        $number = 1;

        while (Store::where('slug', $slug)->exists()) {
            $slug = $slugBase.'-'.$number++;
        }

        Store::create([
            'user_id' => $userId,
            'store_name' => $validated['store_name'],
            'slug' => $slug,
            'description' => $validated['description'] ?? null,
            'category' => $validated['category'],
            'phone' => $validated['phone'],
            'address' => $validated['address'],
            'status' => 'approved',
        ]);

        return redirect()
            ->route('stores.create')
            ->with('success', 'Toko berhasil dibuat dan langsung dikonfirmasi.');
    }

    public function update(Request $request)
    {
        $store = $request->user()->store;
        abort_unless($store, 404);

        $validated = $request->validate([
            'store_name' => ['required', 'string', 'max:100'],
            'description' => ['nullable', 'string', 'max:1000'],
            'category' => ['required', 'string', 'max:100'],
            'phone' => ['required', 'string', 'max:25'],
            'address' => ['required', 'string', 'max:1000'],
        ]);

        $slugBase = Str::slug($validated['store_name']);
        $slug = $slugBase;
        $number = 1;
        while (Store::where('slug', $slug)->where('id', '!=', $store->id)->exists()) {
            $slug = $slugBase.'-'.$number++;
        }

        $store->update([...$validated, 'slug' => $slug]);

        return Redirect::route('seller.settings')->with('success', 'Informasi toko berhasil diperbarui.');
    }
}
