<?php

namespace App\Http\Controllers;

use App\Contracts\PaymentGateway;
use App\Enums\PaymentRecordStatus;
use App\Enums\PaymentStatus;
use App\Models\Order;
use App\Models\Payment;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;

class PaymentController extends Controller
{
    public function show(Order $order): View
    {
        $this->authorize('pay', $order);
        $order->load(['payments' => fn ($query) => $query->latest()]);
        $latestPayment = $order->payments->first();

        return view('payments.instructions', [
            'order' => $order,
            'payment' => $latestPayment,
            'bankAccounts' => config('payment.methods.bank_transfer.accounts', []),
            'qrisImage' => config('payment.methods.qris.image'),
        ]);
    }

    public function uploadProof(Request $request, Order $order, PaymentGateway $paymentGateway): RedirectResponse
    {
        $this->authorize('upload', [Payment::class, $order]);
        $validated = $request->validate([
            'proof' => ['required', 'file', 'mimetypes:image/jpeg,image/png,application/pdf', 'mimes:jpg,jpeg,png,pdf', 'max:2048'],
        ], [
            'proof.required' => 'Pilih file bukti pembayaran.',
            'proof.mimetypes' => 'Bukti pembayaran harus berupa JPG, PNG, atau PDF.',
            'proof.mimes' => 'Bukti pembayaran harus berupa JPG, PNG, atau PDF.',
            'proof.max' => 'Ukuran bukti pembayaran maksimal 2 MB.',
        ]);

        $path = $validated['proof']->store('payment-proofs', config('payment.proof_disk', 'local'));
        try {
            DB::transaction(function () use ($request, $order, $paymentGateway, $path) {
                $lockedOrder = Order::query()->whereKey($order->id)->lockForUpdate()->firstOrFail();
                $this->authorize('upload', [Payment::class, $lockedOrder]);

                $payment = $lockedOrder->payments()->where('status', PaymentRecordStatus::Pending->value)
                    ->latest('id')->lockForUpdate()->first();
                if (! $payment) {
                    $payment = $paymentGateway->createPayment($lockedOrder, $lockedOrder->payment_method);
                }
                if ($payment->proof_path) {
                    Storage::disk(config('payment.proof_disk', 'local'))->delete($payment->proof_path);
                }

                $payment->update(['proof_path' => $path]);
                $lockedOrder->update(['payment_status' => PaymentStatus::WaitingVerification]);
            });
        } catch (\Throwable $exception) {
            Storage::disk(config('payment.proof_disk', 'local'))->delete($path);
            throw $exception;
        }

        return redirect()->route('orders.pay', $order)->with('success', 'Bukti pembayaran berhasil dikirim untuk diverifikasi.');
    }

    public function proof(Payment $payment)
    {
        $this->authorize('view', $payment);
        abort_unless($payment->proof_path, 404);

        return Storage::disk(config('payment.proof_disk', 'local'))->download(
            $payment->proof_path,
            basename($payment->proof_path),
            ['X-Content-Type-Options' => 'nosniff'],
        );
    }

}
