<?php

namespace App\Http\Controllers;

use App\Models\FlashSale;
use Illuminate\View\View;

class FlashSaleController extends Controller
{
    public function index(): View
    {
        $flashSales = FlashSale::query()
            ->with([
                'items' => fn ($items) => $items
                    ->whereColumn('sold_count', '<', 'stock_limit')
                    ->with('product'),
            ])
            ->where('is_active', true)
            ->where('starts_at', '<=', now())
            ->where('ends_at', '>', now())
            ->orderBy('ends_at')
            ->get();

        $products = $flashSales->flatMap(fn (FlashSale $flashSale) => $flashSale->items
            ->filter(fn ($item) => $item->product !== null)
            ->map(function ($item) {
                $product = $item->product;
                $normalPrice = max((int) $product->old_price, (int) $product->price);
                $salePrice = (int) $item->sale_price;
                $discount = $normalPrice > 0
                    ? max(0, (int) round((($normalPrice - $salePrice) / $normalPrice) * 100))
                    : 0;
                $stock = max(0, (int) $item->stock_limit - (int) $item->sold_count);

                return [
                    'flash_sale_item_id' => $item->id,
                    'id' => $product->id,
                    'slug' => $product->slug,
                    'name' => $product->name,
                    'seller' => $product->seller,
                    'location' => $product->location,
                    'image' => $product->image,
                    'normal_price' => $normalPrice,
                    'sale_price' => $salePrice,
                    'discount' => $discount,
                    'rating' => (float) $product->rating,
                    'review_count' => (int) $product->review_count,
                    'sold' => (int) $item->sold_count,
                    'stock' => $stock,
                    'progress' => min(100, (int) round(((int) $item->sold_count / max(1, (int) $item->stock_limit)) * 100)),
                ];
            }));

        return view('flash-sale', compact('products'));
    }
}
