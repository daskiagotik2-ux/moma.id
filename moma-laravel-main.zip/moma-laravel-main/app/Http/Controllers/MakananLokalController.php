<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\View\View;

class MakananLokalController extends Controller
{
    public function index(Request $request): View
    {
        $search = $request->string('search')->trim();
        $location = $request->string('location')->trim();
        $maxPrice = $request->integer('price');
        $minimumRating = (float) $request->input('rating', 0);
        $popular = $request->boolean('popular');

        $products = Product::query()
            ->whereHas('category', fn ($query) => $query->where('slug', 'makanan-minuman'))
            ->where('price', '>', 0)
            ->when($search, function ($query) use ($search) {
                $query->where(function ($query) use ($search) {
                    $query->where('name', 'like', '%'.$search.'%')
                        ->orWhere('description', 'like', '%'.$search.'%')
                        ->orWhere('seller', 'like', '%'.$search.'%')
                        ->orWhere('location', 'like', '%'.$search.'%');
                });
            })
            ->when($location, fn ($query) => $query->where('location', 'like', '%'.$location.'%'))
            ->when($maxPrice > 0, fn ($query) => $query->where('price', '<=', $maxPrice))
            ->when($minimumRating > 0, fn ($query) => $query->where('rating', '>=', $minimumRating))
            ->when($popular, fn ($query) => $query->where('review_count', '>=', 50))
            ->orderByDesc('rating')
            ->limit(12)
            ->get();

        $productCards = $products->map(function (Product $product) {
            return [
                'id' => $product->id,
                'slug' => $product->slug,
                'name' => $product->name,
                'seller' => $product->seller,
                'location' => $product->location,
                'image' => $product->image,
                'price' => (int) $product->price,
                'normal_price' => max((int) $product->old_price, (int) $product->price),
                'rating' => (float) $product->rating,
                'review_count' => (int) $product->review_count,
                'sold' => max(1, (int) $product->review_count * 8 + (int) $product->id * 10),
            ];
        });

        return view('makanan-lokal', compact('productCards'));
    }
}
