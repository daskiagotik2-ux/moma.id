<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\View\View;

class ProdukTerlarisController extends Controller
{
    public function index(Request $request): View
    {
        $filter = $request->string('filter', 'bulan');
        $period = match ($filter) {
            'hari' => 'day',
            'minggu' => 'week',
            default => 'month',
        };

        $products = Product::query()
            ->where(function ($query) use ($period) {
                $date = match ($period) {
                    'day' => Carbon::today(),
                    'week' => Carbon::now()->startOfWeek(),
                    default => Carbon::now()->startOfMonth(),
                };

                $end = match ($period) {
                    'day' => Carbon::today()->endOfDay(),
                    'week' => Carbon::now()->endOfWeek(),
                    default => Carbon::now()->endOfMonth(),
                };

                $query->whereBetween('created_at', [$date, $end]);
            })
            ->orderByDesc('rating')
            ->orderByDesc('review_count')
            ->limit(5)
            ->get();

        $products = $products->map(function (Product $product, $index) {
            return [
                'id' => $product->id,
                'name' => $product->name,
                'seller' => $product->seller,
                'location' => $product->location,
                'price' => $product->price,
                'old_price' => $product->old_price,
                'rating' => $product->rating,
                'review_count' => $product->review_count,
                'image' => $product->image,
                'is_featured' => $product->is_featured,
                'rank' => $index + 1,
                'sold' => max(1, $product->review_count * 10),
            ];
        });

        return view('produk-terlaris', compact('products', 'filter', 'period'));
    }
}
