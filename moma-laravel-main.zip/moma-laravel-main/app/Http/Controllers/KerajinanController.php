<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\View\View;

class KerajinanController extends Controller
{
    public function index(Request $request): View
    {
        $category = trim((string) $request->input('category', ''));
        $maximumPrice = $request->integer('price');
        $minimumRating = (float) $request->input('rating', 0);
        $products = Product::query()
            ->with('category')
            ->whereHas('category', fn ($query) => $query->where('slug', 'kerajinan-tangan'))
            ->where('price', '>', 0)
            ->when($maximumPrice > 0, fn ($query) => $query->where('price', '<=', $maximumPrice))
            ->when($minimumRating > 0, fn ($query) => $query->where('rating', '>=', $minimumRating))
            ->orderByDesc('rating')
            ->get();

        $productCards = $products->map(function (Product $product) {
            return [
                'id' => $product->id,
                'slug' => $product->slug,
                'name' => $product->name,
                'seller' => $product->seller,
                'location' => $product->location,
                'image' => $product->image,
                'price' => (int) $product->price,
                'old_price' => max((int) $product->old_price, (int) $product->price),
                'rating' => (float) $product->rating,
                'review_count' => (int) $product->review_count,
                'sold' => max(1, (int) $product->review_count * 8 + (int) $product->id * 10),
                'category' => $product->category?->name ?? 'Kerajinan Tangan',
                'handmade' => true,
            ];
        });

        $productCards = $productCards->filter(fn ($product) => !$category || strtolower($product['category']) === strtolower($category));

        return view('kerajinan', compact('productCards'));
    }
}
