<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;
use App\Models\Store;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\View\View;

class SellerProductController extends Controller
{
    public function index(Request $request): View
    {
        $store = $this->storeFor($request);
        $products = $store->products()->withoutGlobalScope('marketplace_approved_store')->with('category')->latest()->paginate(15);

        return view('seller.products.index', compact('store', 'products'));
    }

    public function create(Request $request): View
    {
        return view('seller.products.form', [
            'store' => $this->storeFor($request),
            'categories' => Category::orderBy('name')->get(),
            'product' => new Product,
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        $store = $this->storeFor($request);
        $validated = $this->validatedProduct($request, true);
        $image = $validated['image']->store('products', 'public');
        unset($validated['image']);

        $store->products()->create([
            ...$validated,
            'slug' => $this->uniqueSlug($validated['name']),
            'seller' => $store->store_name,
            'location' => Str::limit($store->address, 255, ''),
            'image' => $image,
            'is_featured' => false,
        ]);

        return redirect()->route('seller.products.index')->with('success', 'Produk berhasil ditambahkan.');
    }

    public function edit(Request $request, int $product): View
    {
        $store = $this->storeFor($request);
        $product = $this->ownedProduct($store, $product);

        return view('seller.products.form', [
            'store' => $store,
            'categories' => Category::orderBy('name')->get(),
            'product' => $product,
        ]);
    }

    public function update(Request $request, int $product): RedirectResponse
    {
        $store = $this->storeFor($request);
        $product = $this->ownedProduct($store, $product);
        $validated = $this->validatedProduct($request, false, $product);
        $oldImage = $product->getRawOriginal('image');

        if (! empty($validated['image'])) {
            $validated['image'] = $validated['image']->store('products', 'public');
        } else {
            unset($validated['image']);
        }

        $validated['slug'] = $this->uniqueSlug($validated['name'], $product);
        $validated['seller'] = $store->store_name;
        $validated['location'] = Str::limit($store->address, 255, '');
        $product->update($validated);

        if (isset($validated['image']) && $oldImage && ! preg_match('/^(https?:)?\/\//i', $oldImage)) {
            Storage::disk('public')->delete($oldImage);
        }

        return redirect()->route('seller.products.index')->with('success', 'Produk berhasil diperbarui.');
    }

    public function destroy(Request $request, int $product): RedirectResponse
    {
        $store = $this->storeFor($request);
        $product = $this->ownedProduct($store, $product);
        $image = $product->getRawOriginal('image');
        $product->delete();

        if ($image && ! preg_match('/^(https?:)?\/\//i', $image)) {
            Storage::disk('public')->delete($image);
        }

        return redirect()->route('seller.products.index')->with('success', 'Produk berhasil dihapus.');
    }

    private function storeFor(Request $request): Store
    {
        $store = $request->user()->store;

        if (! $store) {
            abort(404);
        }

        return $store;
    }

    private function ownedProduct(Store $store, int $productId): Product
    {
        return $store->products()->withoutGlobalScope('marketplace_approved_store')->findOrFail($productId);
    }

    private function validatedProduct(Request $request, bool $imageRequired): array
    {
        if ($request->has('price') && is_string($request->input('price'))) {
            $normalizedPrice = preg_replace('/\D+/', '', $request->input('price'));

            if ($normalizedPrice !== '') {
                $request->merge(['price' => (int) $normalizedPrice]);
            }
        }

        return $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'category_id' => ['required', 'integer', 'exists:categories,id'],
            'description' => ['nullable', 'string', 'max:5000'],
            'price' => ['required', 'integer', 'min:1', 'max:999999999'],
            'stock' => ['required', 'integer', 'min:0', 'max:999999'],
            'image' => [$imageRequired ? 'required' : 'nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:5120'],
        ]);
    }

    private function uniqueSlug(string $name, ?Product $product = null): string
    {
        $base = Str::slug($name) ?: 'produk';
        $slug = $base;
        $number = 1;

        while (Product::withoutGlobalScope('marketplace_approved_store')->where('slug', $slug)->when($product, fn ($query) => $query->whereKeyNot($product->id))->exists()) {
            $slug = $base.'-'.$number++;
        }

        return $slug;
    }
}
