<?php

namespace App\Contracts;

use App\Enums\PaymentMethod;
use App\Models\Order;
use App\Models\Payment;

interface PaymentGateway
{
    public function createPayment(Order $order, PaymentMethod $method): Payment;
}
