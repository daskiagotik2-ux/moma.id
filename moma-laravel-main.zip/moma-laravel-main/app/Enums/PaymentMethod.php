<?php

namespace App\Enums;

enum PaymentMethod: string
{
    case Cod = 'cod';
    case BankTransfer = 'bank_transfer';
    case Qris = 'qris';

    public function label(): string
    {
        return match ($this) {
            self::Cod => 'Bayar di Tempat (COD)',
            self::BankTransfer => 'Transfer Bank',
            self::Qris => 'E-wallet / QRIS',
        };
    }

    public function isManual(): bool
    {
        return $this !== self::Cod;
    }
}
