<?php

namespace App\Policies;

use App\Enums\PaymentMethod;
use App\Enums\PaymentStatus;
use App\Models\Order;
use App\Models\Payment;
use App\Models\User;
use Illuminate\Auth\Access\Response;

class PaymentPolicy
{
    public function view(User $user, Payment $payment): bool|Response
    {
        $store = $user->store;
        $sellerOwnsOrderItem = $store && $payment->order?->items()
            ->whereHas('product', fn ($query) => $query
                ->withoutGlobalScope('marketplace_approved_store')
                ->where('store_id', $store->id))
            ->exists();

        return $payment->order?->user_id === $user->id || $sellerOwnsOrderItem
            ? true
            : Response::denyAsNotFound();
    }

    public function upload(User $user, Order $order): bool|Response
    {
        if ($order->user_id !== $user->id) {
            return Response::denyAsNotFound();
        }

        return $order->user_id === $user->id
            && $order->payment_method !== PaymentMethod::Cod
            && in_array($order->payment_status, [PaymentStatus::Unpaid, PaymentStatus::Failed], true)
            && $order->payment_expires_at !== null
            && $order->payment_expires_at->isFuture();
    }

    public function verify(User $user, Payment $payment): bool|Response
    {
        $store = $user->store;
        if (! $store) {
            return Response::denyAsNotFound();
        }

        return $payment->order?->items()
            ->whereHas('product', fn ($query) => $query
                ->withoutGlobalScope('marketplace_approved_store')
                ->where('store_id', $store->id))
            ->exists()
            ? true
            : Response::denyAsNotFound();
    }
}
