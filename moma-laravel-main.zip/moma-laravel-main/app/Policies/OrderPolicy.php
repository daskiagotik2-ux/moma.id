<?php

namespace App\Policies;

use App\Models\Order;
use App\Models\User;
use Illuminate\Auth\Access\Response;

class OrderPolicy
{
    public function view(User $user, Order $order): bool|Response
    {
        return $order->user_id === $user->id
            ? true
            : Response::denyAsNotFound();
    }

    public function pay(User $user, Order $order): bool|Response
    {
        if ($order->user_id !== $user->id) {
            return Response::denyAsNotFound();
        }

        return $order->payment_method !== \App\Enums\PaymentMethod::Cod;
    }

    public function approve(User $user, Order $order): bool|Response
    {
        $store = $user->store;
        if (! $store) {
            return Response::denyAsNotFound();
        }

        $ownsOrderItem = $order->items()
            ->whereHas('product', fn ($query) => $query
                ->withoutGlobalScope('marketplace_approved_store')
                ->where('store_id', $store->id))
            ->exists();

        return $ownsOrderItem ? true : Response::denyAsNotFound();
    }
}
