<?php

namespace App\Console\Commands;

use App\Enums\PaymentMethod;
use App\Enums\PaymentRecordStatus;
use App\Enums\PaymentStatus;
use App\Models\FlashSaleItem;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;
use App\Models\Voucher;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class ExpireUnpaidOrders extends Command
{
    protected $signature = 'payments:expire';

    protected $description = 'Cancel expired manual-payment orders and restore their reserved stock.';

    public function handle(): int
    {
        $orderIds = Order::query()
            ->where('payment_method', '!=', PaymentMethod::Cod->value)
            ->whereIn('payment_status', [PaymentStatus::Unpaid->value, PaymentStatus::Failed->value, PaymentStatus::WaitingVerification->value])
            ->where('payment_expires_at', '<=', now())
            ->orderBy('id')
            ->pluck('id');

        $expiredCount = 0;
        foreach ($orderIds as $orderId) {
            $expired = DB::transaction(function () use ($orderId) {
                $order = Order::query()->whereKey($orderId)->lockForUpdate()->first();
                if (
                    ! $order
                    || $order->payment_method === PaymentMethod::Cod
                    || ! in_array($order->payment_status, [PaymentStatus::Unpaid, PaymentStatus::Failed, PaymentStatus::WaitingVerification], true)
                    || ! $order->payment_expires_at
                    || $order->payment_expires_at->isFuture()
                ) {
                    return false;
                }

                $items = OrderItem::query()->where('order_id', $order->id)->orderBy('id')->lockForUpdate()->get();
                foreach ($items as $item) {
                    if ($item->product_id !== null) {
                        $product = Product::withoutGlobalScope('marketplace_approved_store')
                            ->whereKey($item->product_id)->lockForUpdate()->first();
                        if ($product && $product->stock !== null) {
                            $product->increment('stock', $item->quantity);
                        }
                    }

                    if ($item->flash_sale_item_id !== null) {
                        $flashSaleItem = FlashSaleItem::query()->whereKey($item->flash_sale_item_id)->lockForUpdate()->first();
                        if ($flashSaleItem) {
                            $flashSaleItem->update([
                                'sold_count' => max(0, $flashSaleItem->sold_count - $item->quantity),
                            ]);
                        }
                    }
                }

                $order->payments()
                    ->where('status', PaymentRecordStatus::Pending->value)
                    ->update([
                        'status' => PaymentRecordStatus::Rejected->value,
                        'verified_at' => now(),
                        'note' => 'Pembayaran kedaluwarsa.',
                    ]);
                if ($order->voucher_code) {
                    $voucher = Voucher::query()->where('code', $order->voucher_code)->lockForUpdate()->first();
                    if ($voucher && $voucher->used_count > 0) {
                        $voucher->decrement('used_count');
                    }
                }
                $order->update([
                    'status' => 'cancelled',
                    'payment_status' => PaymentStatus::Expired,
                ]);

                return true;
            });

            $expiredCount += (int) $expired;
        }

        $this->info("{$expiredCount} pesanan pembayaran kedaluwarsa diproses.");

        return self::SUCCESS;
    }
}
