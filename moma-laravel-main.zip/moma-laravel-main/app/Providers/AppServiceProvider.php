<?php

namespace App\Providers;

use App\Contracts\PaymentGateway;
use App\Services\ManualPayment;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->bind(PaymentGateway::class, ManualPayment::class);
    }
    public function boot(): void {}
}