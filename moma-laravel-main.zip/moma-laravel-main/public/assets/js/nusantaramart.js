document.addEventListener('DOMContentLoaded', () => {
    updateCartCount();
    loadWishlist();

    document.querySelectorAll('.tabs button').forEach(tab => {
        tab.addEventListener('click', () => {
            document.querySelectorAll('.tabs button').forEach(x => x.classList.remove('selected'));
            tab.classList.add('selected');
        });
    });

    document.querySelectorAll('.slider-arrow').forEach(button => {
        button.addEventListener('click', () => {
            const dots = [...document.querySelectorAll('.dots i')];
            if (!dots.length) return;
            let current = dots.findIndex(dot => dot.classList.contains('active'));
            current = button.classList.contains('right') ? (current + 1) % dots.length : (current - 1 + dots.length) % dots.length;
            dots.forEach(dot => dot.classList.remove('active'));
            dots[current].classList.add('active');
        });
    });
});

function toggleWish(button, id) {
    const wishes = JSON.parse(localStorage.getItem('nusantaramart_wishlist') || '[]');
    const exists = wishes.includes(String(id));

    if (exists) {
        localStorage.setItem('nusantaramart_wishlist', JSON.stringify(wishes.filter(x => x !== String(id))));
        button.classList.remove('liked');
        button.textContent = '♡';
    } else {
        wishes.push(String(id));
        localStorage.setItem('nusantaramart_wishlist', JSON.stringify(wishes));
        button.classList.add('liked');
        button.textContent = '♥';
    }
}

function loadWishlist() {
    const wishes = JSON.parse(localStorage.getItem('nusantaramart_wishlist') || '[]');
    document.querySelectorAll('.wishlist').forEach(button => {
        const onclick = button.getAttribute('onclick') || '';
        const match = onclick.match(/'([^']+)'/);
        if (match && wishes.includes(match[1])) {
            button.classList.add('liked');
            button.textContent = '♥';
        }
    });
}

function addToCart(id) {
    const cart = JSON.parse(localStorage.getItem('nusantaramart_cart') || '[]');
    cart.push(String(id));
    localStorage.setItem('nusantaramart_cart', JSON.stringify(cart));
    updateCartCount();

    const count = document.getElementById('cartCount');
    if (count) {
        count.animate([{transform:'scale(1)'},{transform:'scale(1.5)'},{transform:'scale(1)'}], {duration:350});
    }
}

function updateCartCount() {
    const cart = JSON.parse(localStorage.getItem('nusantaramart_cart') || '[]');
    const count = document.getElementById('cartCount');
    if (count) count.textContent = cart.length;
}

function subscribeNewsletter(event) {
    event.preventDefault();
    alert('Terima kasih! Email kamu berhasil didaftarkan.');
    event.target.reset();
    return false;
}