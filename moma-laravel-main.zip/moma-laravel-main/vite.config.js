import { defineConfig } from 'vite';
import laravel from 'laravel-vite-plugin';

export default defineConfig({
    plugins: [
        laravel({
            input: ['resources/css/app.css', 'resources/css/marketplace-sidebar.css', 'resources/css/seller.css', 'resources/css/voucher.css', 'resources/css/kategori.css', 'resources/js/app.js'],
            refresh: true,
        }),
    ],
});
