import defaultTheme from 'tailwindcss/defaultTheme';
import forms from '@tailwindcss/forms';

/** @type {import('tailwindcss').Config} */
export default {
    content: [
        './vendor/laravel/framework/src/Illuminate/Pagination/resources/views/*.blade.php',
        './resources/views/**/*.blade.php',
        './resources/js/**/*.js',
    ],
    theme: {
        extend: {
            colors: {
                brand: {
                    50: '#FFF4F1',
                    100: '#FFF4F1',
                    200: '#F3F0EF',
                    300: '#B91C2B',
                    400: '#B91C2B',
                    500: '#B91C2B',
                    600: '#B91C2B',
                    700: '#4A171D',
                    800: '#4A171D',
                    900: '#4A171D',
                },
                marketplace: {
                    50: '#FFF4F1',
                    100: '#FFF4F1',
                    500: '#B91C2B',
                    600: '#B91C2B',
                    700: '#4A171D',
                },
                accent: '#B91C2B',
            },
            fontFamily: {
                sans: ['Figtree', ...defaultTheme.fontFamily.sans],
            },
        },
    },
    plugins: [forms],
};