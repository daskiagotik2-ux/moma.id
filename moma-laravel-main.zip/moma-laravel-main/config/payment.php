<?php

return [
    'expiration_hours' => (int) env('PAYMENT_EXPIRATION_HOURS', 24),
    'proof_disk' => 'local',
    'active_methods' => ['cod', 'bank_transfer', 'qris'],
    'methods' => [
        'cod' => [
            'enabled' => true,
            'description' => 'Bayar tunai kepada kurir saat pesanan diterima.',
        ],
        'bank_transfer' => [
            'enabled' => true,
            'description' => 'Transfer manual ke rekening MoMa.id, lalu unggah bukti.',
            'accounts' => [
                'BCA' => [
                    'number' => env('PAYMENT_BCA_NUMBER', ''),
                    'name' => env('PAYMENT_BCA_NAME', 'MoMa.id'),
                ],
                'BRI' => [
                    'number' => env('PAYMENT_BRI_NUMBER', ''),
                    'name' => env('PAYMENT_BRI_NAME', 'MoMa.id'),
                ],
                'Mandiri' => [
                    'number' => env('PAYMENT_MANDIRI_NUMBER', ''),
                    'name' => env('PAYMENT_MANDIRI_NAME', 'MoMa.id'),
                ],
            ],
        ],
        'qris' => [
            'enabled' => true,
            'description' => 'Bayar melalui e-wallet atau aplikasi bank menggunakan QRIS.',
            'image' => env('PAYMENT_QRIS_IMAGE', ''),
        ],
    ],
];
